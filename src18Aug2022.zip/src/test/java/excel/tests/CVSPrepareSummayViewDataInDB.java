package excel.tests;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CVSPrepareSummayViewDataInDB {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub

		
		String weeklyDigitalExtractHeadCountQuery ="Insert into SummaryViewData values (SELECT  count(ColleagueID),SVP, Date() AS CurrentDate  FROM DigitalRosterExtract_07132022 GROUP BY SVP)";

		
		// variables
				Connection connection = null;
				// Statement statement = null;
				ResultSet resultSet = null;

				// Step 1: Loading or registering Oracle JDBC driver class
				try {

					Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				} catch (ClassNotFoundException cnfex) {

					System.out.println("Problem in loading or " + "registering MS Access JDBC driver");
					cnfex.printStackTrace();
				}

				// Step 2: Opening database connection
				try {

					String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
					String dbURL = "jdbc:ucanaccess://" + msAccDB;

					// Step 2.A: Create and get connection using DriverManager class
					connection = DriverManager.getConnection(dbURL);
				} catch (Exception ex) {

					System.out.println("DriverManager.getConnection(dbURL) failed");
					System.out.println();
					ex.printStackTrace();

				}
		//create the diff table
		   if (connection != null) {
	           Statement st3 = null;
	           try {
	               st3 = (Statement) connection.createStatement();
	           } catch (SQLException ex) {
	               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
	           }
	           
	        
	           //String createDiffTableQuery= CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("createDigitalExtractDiffTableQuery");
	           //   ResultSet rs3 = null;
	           try { 
	                st3.execute(weeklyDigitalExtractHeadCountQuery);
	           } catch (SQLException ex) {
	               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
	           }
	       }
	       
		   System.out.println("Data Pushed to DB Table");
	        //resultSet = statement1.execute(createTableQuery);
	        connection.commit();
	        
	        connection.close();
		//CVSCompareDatabaseTablesTest.copyResultsetToTable(weeklyDigitalExtractHeadCountQuery, digitalRosterAttritionTableName.trim()+"_"+newTableName, connection, connection);
		
		
		
	}

}
