package excel.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
 
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 

public class WriteFormulaForAColumn {
 
    public static void main(String[] args) throws IOException {
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet sheet = workbook.createSheet("TestSheetWithFormula");
        String[] columns = {"Amount1", "Amount2", "Amount3", "Total"};
        int rowCount = 0;
        
        
        // Create a Font for styling header cells
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 14);
        headerFont.setColor(IndexedColors.RED.getIndex());

        // Create a CellStyle with the font
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFont(headerFont);
        
        // Create a Row
        Row headerRow = sheet.createRow(0);

        // Create cells
        for(int i = 0; i < columns.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
            cell.setCellStyle(headerCellStyle);
        }

         
            Row row = sheet.createRow(1);
            row.createCell(0).setCellValue(10);
            row.createCell(1).setCellValue(20);
            row.createCell(2).setCellValue(30);
            row.createCell(3).setCellFormula("A2+B2+C2");
            
   

       
            
            File file = new File(".\\resources\\ExcelWoBWithFormula.xlsx");
            if (file.canRead()) {
             file.delete();
            }
         
        try (FileOutputStream outputStream = new FileOutputStream(".\\resources\\ExcelWoBWithFormula.xlsx")) {
            workbook.write(outputStream);
            outputStream.close();
        }
    }
 
}