package excel.tests;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections4.MultiMap;
import org.apache.commons.collections4.map.MultiValueMap;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.excel.lib.util.Xls_Reader;

import io.github.bonigarcia.wdm.WebDriverManager;

public class EmployessPerSVPBackup {

	public static void main(String[] args) {

		
				
		Xls_Reader reader = new Xls_Reader("./resources/ROV_Digital_Roster_Opens_Visibility_07_20_OZone.xlsx");
		String sheetName = "Digital Roster Extract";
		MultiMap multiMap = new MultiValueMap();
		int rowCount = reader.getRowCount(sheetName);

		for(int rowNum=2; rowNum<=rowCount; rowNum++){
			String svpName = reader.getCellData(sheetName, "Senior Leader", rowNum);
			String empType = reader.getCellData(sheetName, "Type", rowNum);

			//System.out.println(AdmissionType + " " + caseId);
			
			  

			        	multiMap.put(svpName,empType);
			        
			       
		}
		int fteCount=0;
		int contractorCount =0;
		// get all the set of keys
        Set<String> keys = multiMap.keySet();
         System.out.println(keys);
        // iterate through the key set and display key and values
        for (String key : keys) {
            System.out.println("Key = " + key);
            System.out.println("\n");

           String s= multiMap.get(key).toString();
           String[] ls = s.split(",");
           for(int i=0;i<ls.length;i++)
           {
        	   if(ls[i].contains("FTE"))
        	   {
        		   fteCount++;
        	   }
        	   if(ls[i].contains("Contractor"))
        	   {
        		   contractorCount++;
        	   }
           }
           System.out.println(fteCount);
           System.out.println(contractorCount);
            fteCount=0;
   		   contractorCount =0;
            System.out.println("Values = " + multiMap.get(key) + "\n");
        }
     
		
		
	}

}
