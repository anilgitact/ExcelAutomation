package excel.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections4.MultiMap;
import org.apache.commons.collections4.map.MultiValueMap;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.BorderStyle;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTAutoFilter;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTFilter;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTFilterColumn;

import com.excel.lib.util.Xls_Reader;

import io.github.bonigarcia.wdm.WebDriverManager;



public class LeaversPerSVP {

	private static String[] columns = {"SVP","FTELeavers","ContractorLeavers","Senior Leader", "FTECount", "ContractorCount", "TotalLeavers"};
	
	public static int finalRowNum;
	public static int globalFTECount=0;
	public static int globalContractorCount=0;
	
		public static boolean createAttritionSummaryView(String svp,  Workbook workbook, Sheet sheet, String DateOfSheetAttritionFound) throws IOException
		{
		
       ; // new HSSFWorkbook() for generating `.xls` file

        
        CreationHelper createHelper = workbook.getCreationHelper();

        // Create a Sheet
        sheet = workbook.getSheet("Leavers_"+DateOfSheetAttritionFound);

        // Create a Font for styling header cells
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 12);
        headerFont.setColor(IndexedColors.WHITE.getIndex());

        // Create a CellStyle with the font
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFillForegroundColor(IndexedColors.DARK_BLUE.getIndex());
        headerCellStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        headerCellStyle.setFont(headerFont);

        // Create a Row
        Row headerRow = sheet.createRow(0);

        // Create cells
        for(int i = 0; i < columns.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
            cell.setCellStyle(headerCellStyle);
        }

		
        CellStyle style = workbook.createCellStyle();//Create style
        Font font = workbook.createFont();//Create font
        font.setBold(true);//Make font bold
        style.setFont(font);//set it to bold
		
				
		Xls_Reader reader = new Xls_Reader("./resources/attrition/FinalRoster_"+svp+".xlsx");
		String sheetName = "Leavers_"+DateOfSheetAttritionFound;
	
		
		 
         //Get first/desired sheet from the workbook
         //XSSFSheet sh = wb.getSheet("sheet1");
		
		MultiMap multiMapLeader = new MultiValueMap();
		MultiMap multiMapSVP = new MultiValueMap();
		int rowCount = reader.getRowCount(sheetName);

			
	
		for(int rowNum=2; rowNum<=rowCount; rowNum++){
			String leaderName = reader.getCellData(sheetName, "SeniorLeader", rowNum);
			String empType = reader.getCellData(sheetName, "Type", rowNum);

			        	multiMapLeader.put(leaderName,empType);
		}
		
		
		Xls_Reader svpReader = new Xls_Reader("./resources/attrition/Attrition_"+DateOfSheetAttritionFound+".xlsx");
		String svpSheetName = "Leavers_"+DateOfSheetAttritionFound;
		int svpRowCount = svpReader.getRowCount(svpSheetName);
		for(int rowNum=2; rowNum<=svpRowCount; rowNum++){
			String svpName = svpReader.getCellData(svpSheetName, "SVP", rowNum);
			String svpEmpType = svpReader.getCellData(svpSheetName, "Type", rowNum);

			        	multiMapSVP.put(svpName,svpEmpType);
		}
		
		//store employee count for SVP in sheet
		int fteCount=0;
		int contractorCount =0;
		int fteCountPerLeader=0;
		int contractorCountPerLeader =0;
		int rowNum = finalRowNum+1;
		Row row = null;
		// get all the set of keys
        Set<String> keys = multiMapSVP.keySet();
         System.out.println(keys);
        // iterate through the key set and display key and values
        for (String key : keys) {
        
        	if(key.contains(svp))
        	{
            System.out.println("Key = " + key);
            System.out.println("\n");

           String s= multiMapSVP.get(svp).toString();
           String[] ls = s.split(",");
           for(int i=0;i<ls.length;i++)
           {
        	   if(ls[i].contains("FTE"))
        	   {
        		   fteCount++;
        	   }
        	   if(ls[i].contains("Contractor"))
        	   {
        		   contractorCount++;
        	   }
           }
           globalFTECount=globalFTECount+fteCount;
           globalContractorCount = globalContractorCount+contractorCount;
           System.out.println(fteCount);
           System.out.println(contractorCount);
        
            System.out.println("Values = " + multiMapSVP.get(svp) + "\n");
            
            // Create Other rows and cells with employees data
            
                row = sheet.createRow(rowNum++);
               
                
                row.createCell(0)
                     .setCellValue(key);
                row.getCell(0).setCellStyle(style);
                
                row.createCell(1)
                        .setCellValue(fteCount);

                row.createCell(2)
                        .setCellValue(contractorCount);
                
                row.createCell(6)
                .setCellValue(fteCount+contractorCount);
                row.getCell(6).setCellStyle(style);
            
                Set<String> leaderkeys = multiMapLeader.keySet();
                System.out.println(leaderkeys);
               // iterate through the key set and display key and values
               for (String leaderkey : leaderkeys) {
                   System.out.println("Key = " + leaderkey);
                   System.out.println("\n");

                  String s1= multiMapLeader.get(leaderkey).toString();
                  String[] ls1 = s1.split(",");
                  for(int i=0;i<ls1.length;i++)
                  {
               	   if(ls1[i].contains("FTE"))
               	   {
               		fteCountPerLeader++;
               	   }
               	   if(ls1[i].contains("Contractor"))
               	   {
               		contractorCountPerLeader++;
               	   }
                  }
                  globalFTECount=globalFTECount+fteCountPerLeader;
                  globalContractorCount = globalContractorCount+contractorCountPerLeader;
                  System.out.println("globalFTECount:"+globalFTECount);
                  System.out.println("globalContractorCount:"+globalContractorCount);
                  
               
                   System.out.println("Values = " + multiMapLeader.get(leaderkey) + "\n");
                   
                   // Create Other rows and cells with employees data
                   
              
                       row = sheet.createRow(rowNum++);
                       CellStyle style1 = workbook.createCellStyle();
                       // Styling border of cell.  
                       style.setBorderBottom(BorderStyle.NONE);  
                        
                       row.createCell(3)
                               .setCellValue(leaderkey);
                       row.getCell(3).setCellStyle(style1);
                       
                       row.createCell(4)
                               .setCellValue(fteCountPerLeader);
                       row.getCell(4).setCellStyle(style1);
                       
                       row.createCell(5)
                       .setCellValue(contractorCountPerLeader);
                       row.getCell(5).setCellStyle(style1);
                       
                       row.createCell(6)
                       .setCellValue(fteCountPerLeader+contractorCountPerLeader);
                
                
                       
                       fteCountPerLeader=0;
     		   contractorCountPerLeader =0;
     			                fteCount=0;
     			        contractorCount =0;
     			        
            }
        finalRowNum = rowNum;
         
		   
		            }
		}
        /*row = sheet.createRow(finalRowNum++);
        row.createCell(0)
        .setCellValue(globalFTECount);
        row.createCell(1)
        .setCellValue(globalFTECount);
        row.createCell(2)
        .setCellValue(globalContractorCount);*/

    		// Resize all columns to fit the content size
            for(int i = 0; i < columns.length; i++) {
                sheet.autoSizeColumn(i);
            }

            
           
		
		 return true;
     
	}
}
	

		
	


