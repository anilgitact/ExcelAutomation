package excel.tests;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.testng.annotations.Test;

public class CVSPushSummayViewDataInDB {

	public static void main(String[] args) throws SQLException, IOException {
		// TODO Auto-generated method stub
	}
		
	@Test
		public static void pushWeeklySummaryDataToDBForSVPWiseSummaryReport() throws IOException, SQLException, ParseException
		{
			
			try
			{
		File directoryPath = new File("./resources/process/");
		// List of all files and directories
		String fileNames[] = directoryPath.list();
		String weeklyDigitalExtractHeadCountQuery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("WeeklySummaryViewDataCountJoinersLeaversQuery");
		String FirstSheetHeadCountJoinerLeaversQuery ="";
		String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
		if(firstReportWorkBook.contains("true"))
		{
			FirstSheetHeadCountJoinerLeaversQuery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("FirstSheetHeadCountJoinerLeaversQuery");
			FirstSheetHeadCountJoinerLeaversQuery = FirstSheetHeadCountJoinerLeaversQuery.replaceAll("ROVWeekDate", fileNames[0].split("_")[1].replaceAll("-", ""));
		}
		else
		{
		weeklyDigitalExtractHeadCountQuery = weeklyDigitalExtractHeadCountQuery.replaceAll("ROVWeekDate",fileNames[0].split("_")[1].replaceAll("-", ""));
		}
		// variables
				Connection connection = null;
				// Statement statement = null;
				ResultSet resultSet = null;

				// Step 1: Loading or registering Oracle JDBC driver class
				try {

					Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				} catch (ClassNotFoundException cnfex) {

					System.out.println("Problem in loading or " + "registering MS Access JDBC driver");
					cnfex.printStackTrace();
				}

				// Step 2: Opening database connection
				try {

					String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
					String dbURL = "jdbc:ucanaccess://" + msAccDB;

					// Step 2.A: Create and get connection using DriverManager class
					connection = DriverManager.getConnection(dbURL);
				} catch (Exception ex) {

					System.out.println("DriverManager.getConnection(dbURL) failed");
					System.out.println();
					ex.printStackTrace();

				}
		//create the diff table
		   if (connection != null) {
	           Statement st3 = null;
	           try {
	               st3 = (Statement) connection.createStatement();
	           } catch (SQLException ex) {
	               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
	           }
	           
	        
	           //String createDiffTableQuery= CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("createDigitalExtractDiffTableQuery");
	           //   ResultSet rs3 = null;
	           try { 
	                //st3.execute(weeklyDigitalExtractHeadCountQuery);
	                CVSCompareDatabaseTablesTest.copyResultsetToTable(weeklyDigitalExtractHeadCountQuery, "SummaryViewData".trim(), connection, connection);
	                System.out.println("Summary View Data for week "+fileNames[0].split("_")[1].replaceAll("-", "")+" pushed to DB");
	           } catch (Exception  ex) {
	        	   
	        	  if (ex.getMessage().contains("object not found:"))
	        			  {
	        			  System.out.println("DIGITALROSTERATTRITION_mmddyyyy table not present in DB for  week "+fileNames[0].split("_")[1]+"-Hence DB-SummaryViewData table will have 0 values");
	        			  }
	        	  
	        	 
	               //Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
	           }
	           finally {
	        	   if(firstReportWorkBook.contains("true"))
	       		{
	        	   CVSCompareDatabaseTablesTest.copyResultsetToTable(FirstSheetHeadCountJoinerLeaversQuery, "SummaryViewData".trim(), connection, connection);
	        	   //CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
	                System.out.println("Summary View Data for week "+fileNames[0].split("_")[1].replaceAll("-", "")+" pushed to DB");
	       		}
	        	  }
	       }
	       
			 } catch (SQLException ex) {
	               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
	               System.out.println("some issues pushing the sumary view resultset to DB table: SummaryViewDate");
	           }
		
	}
		
	}

