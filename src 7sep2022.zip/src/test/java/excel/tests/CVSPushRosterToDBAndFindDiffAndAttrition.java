package excel.tests;

import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.testng.annotations.Test;

public class CVSPushRosterToDBAndFindDiffAndAttrition {
	

	
	static ArrayList<String> TrainRosterExtractTableNameDates = new ArrayList<String>();
	static ArrayList<String> DigitalRosterExtractTableNameDates = new ArrayList<String>();
	static Connection connection = null;
	static String[] fileNames = null;
	static String NewSheetPathAndName ="";
	static String excelFilePath ="";
	static String createTableQuery="";
	static ArrayList<String> listofTable = null;
	static boolean digitalrosterextractdiffTable_flag=false;

	@Test(priority = 1)
	public static void createRosterSheet() throws IOException {
		
		File directoryPath = new File("./resources/process");
		String fileNames[] = directoryPath.list();
		String TargetSheetPathAndName = "./resources/process/"+fileNames[0];

		// String TargetSheetPathAndName = "./resources/sheetWithEmptyColumnData.xlsx";
        if(getPropertyValueFromPropertyFile("RosterExtractName").contains("TrainRosterExtract"))
        {
		 NewSheetPathAndName = "./resources/trainRosters/trainRoster_"+fileNames[0].split("_")[1]+".xlsx";
        }
        else
        	 if(getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
             {
     		 NewSheetPathAndName = "./resources/DigitalRosters/digitalRoster_"+fileNames[0].split("_")[1].replaceAll("-", "")+".xlsx";
             }	
		if (TargetSheetPathAndName != null && !"".equals(TargetSheetPathAndName.trim())) {

			try {

				File targetFile = new File(TargetSheetPathAndName.trim());

				FileInputStream inputStream = new FileInputStream(targetFile);

				XSSFWorkbook inputWorkbook = new XSSFWorkbook(inputStream);

				int targetSheetCount = inputWorkbook.getNumberOfSheets();

				System.out.println("Total no. of sheet(s) in the Target Workbook: " + targetSheetCount);

				File outputFile = new File(NewSheetPathAndName.trim());

				FileOutputStream outputStream = new FileOutputStream(outputFile);

				XSSFWorkbook outputWorkbook = new XSSFWorkbook();

// Step #2 : Creating sheets with the same name as appearing in target workbook.

				for (int i = 0; i < targetSheetCount; i++) {

					XSSFSheet targetSheet = inputWorkbook.getSheetAt(i);

					String inputSheetName = inputWorkbook.getSheetName(i);
					if (inputSheetName.equals("Train Roster Extract") && getPropertyValueFromPropertyFile("RosterExtractName").contains("TrainRosterExtract"))
			         {

						XSSFSheet outputSheet = outputWorkbook.createSheet(inputSheetName);

						copyExcelWB(targetSheet, outputSheet);
					}
					if (inputSheetName.equals("Digital Roster Extract") && getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
			         {

						XSSFSheet outputSheet = outputWorkbook.createSheet(inputSheetName);

						copyExcelWB(targetSheet, outputSheet);
					}

				}

// Step #4 : Write all the sheets in the new Workbook using FileOutStream Object

				outputWorkbook.write(outputStream);

				outputStream.close();

			}

			catch (Exception ex) {

				System.out.println("Please check the target sheet given path and name: " + TargetSheetPathAndName);

				System.out.println();

				ex.printStackTrace();

			}
		}
	}
	
	
	
	@Test(priority = 2)

	public static void PushRosterDataToDBAndFindDiff() throws IOException, ParseException {

// Step #1 : Locate path and file name of target and output excel.
		
		// variables
		connection = null;
		// Statement statement = null;
		ResultSet resultSet = null;

		// Step 1: Loading or registering Oracle JDBC driver class
		try {

			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		} catch (ClassNotFoundException cnfex) {

			System.out.println("Problem in loading or " + "registering MS Access JDBC driver");
			cnfex.printStackTrace();
		}

		// Step 2: Opening database connection
		try {

			String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
			String dbURL = "jdbc:ucanaccess://" + msAccDB;

			// Step 2.A: Create and get connection using DriverManager class
			connection = DriverManager.getConnection(dbURL);

			// Step 2.B: Creating JDBC Statement
			// statement = connection.createStatement();
			long start = System.currentTimeMillis();

		

			File directoryPath = new File("./resources/process/");
			// List of all files and directories
			fileNames = directoryPath.list();
			//createRosterSheet();
			//ArrayList<String> TrainRosterExtractTableNames = new ArrayList<String>();
			

			listofTable = new ArrayList<String>();

			DatabaseMetaData md = connection.getMetaData();

			ResultSet rs1 = md.getTables(null, null, "%", null);
			while (rs1.next()) {
				if (rs1.getString(4).equalsIgnoreCase("TABLE")) {
					listofTable.add(rs1.getString(3));
				}
			}
			 if(getPropertyValueFromPropertyFile("RosterExtractName").contains("TrainRosterExtract"))
		        {
			for (int k = 0; k < listofTable.size(); k++) {

				if (listofTable.get(k).contains("TrainRosterExtract_")) {
					TrainRosterExtractTableNameDates.add(listofTable.get(k).split("_")[1]);

				}
			}

			// sort the table names
            if(!TrainRosterExtractTableNameDates.isEmpty())
            {
			Collections.sort(TrainRosterExtractTableNameDates, Collections.reverseOrder());
			//System.out.println(TrainRosterExtractTableNameDates.get(0).substring(0,2)+"-"+TrainRosterExtractTableNameDates.get(0).substring(2,4)+"-"+TrainRosterExtractTableNameDates.get(0).substring(4,8));
			// comapre the new ROV file date is after the date of the last pushed to DB ROV
			// file
			
			
			if (fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "").contains(TrainRosterExtractTableNameDates.get(0))) 
			{
                 System.out.println("The new file data already exists in DB and had been processed");
			} 
			
			else 
			
			{
				if (new SimpleDateFormat("MM/dd/yyyy").parse(fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "/"))
						.after(new SimpleDateFormat("MM/dd/yyyy").parse(TrainRosterExtractTableNameDates.get(0).substring(0,2)+"/"+TrainRosterExtractTableNameDates.get(0).substring(2,4)+"/"+TrainRosterExtractTableNameDates.get(0).substring(4,8)))) 
				
				{
					// push the data to DB with file date
					CVSRosterExcel2DatabaseTest.pushDataToDB(
							fileNames[0].split(".xlsx")[0].split("_")[1].toString());
					//CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
				}
				
			}
			}
            
            else
				if(TrainRosterExtractTableNameDates.isEmpty())
				{
					// push the data to DB with file date
					CVSRosterExcel2DatabaseTest.pushDataToDB(
							fileNames[0].split(".xlsx")[0].split("_")[1].toString());
					//CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
				}
		}
			 else
				 if(getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
			        {
				for (int k = 0; k < listofTable.size(); k++) {

					if (listofTable.get(k).contains("DigitalRosterExtract_")) {
						DigitalRosterExtractTableNameDates.add(listofTable.get(k).split("_")[1]);

					}
				}

				// sort the table names
	            if(!DigitalRosterExtractTableNameDates.isEmpty())
	            {
				Collections.sort(DigitalRosterExtractTableNameDates, Collections.reverseOrder());
				//System.out.println(DigitalRosterExtractTableNameDates.get(0).substring(0,2)+"-"+DigitalRosterExtractTableNameDates.get(0).substring(2,4)+"-"+DigitalRosterExtractTableNameDates.get(0).substring(4,8));
				// comapre the new ROV file date is after the date of the last pushed to DB ROV
				// file
				
				
				if (fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "").contains(DigitalRosterExtractTableNameDates.get(0))) 
				{
	                 System.out.println("The new file data already exists in DB and had been processed");
				} 
				
				else 
				
				{
					if (new SimpleDateFormat("MM/dd/yyyy").parse(fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "/"))
							.after(new SimpleDateFormat("MM/dd/yyyy").parse(DigitalRosterExtractTableNameDates.get(0).substring(0,2)+"/"+DigitalRosterExtractTableNameDates.get(0).substring(2,4)+"/"+DigitalRosterExtractTableNameDates.get(0).substring(4,8)))) 
					
					{
						// push the data to DB with file date
						CVSRosterExcel2DatabaseTest.pushDataToDB(
								fileNames[0].split(".xlsx")[0].split("_")[1].toString());
						//CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
					}
					
				}
				}
	            
	            else
					if(DigitalRosterExtractTableNameDates.isEmpty())
					{
						// push the data to DB with file date
						CVSRosterExcel2DatabaseTest.pushDataToDB(
								fileNames[0].split(".xlsx")[0].split("_")[1].toString());
						//CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
					}
			 
			        }
		} catch (Exception ex) {

			System.out.println("Some issues while pushing data to DB");

			System.out.println();

			ex.printStackTrace();

		}

	}


	public static void copyExcelWB(XSSFSheet targetSheet, XSSFSheet outputSheet) {
		DataFormatter formatter = new DataFormatter();
		int rowCount = targetSheet.getLastRowNum();

		System.out.println("There are " + rowCount + " rows in the Target workbook with sheet name -" + "'"
				+ targetSheet.getSheetName() + "‘");

		int currentRowIndex = 0;
		System.out.println(targetSheet.getPhysicalNumberOfRows());
		for (int i = 0; i < targetSheet.getPhysicalNumberOfRows(); i++) {
			final Row row = targetSheet.getRow(i);
			//if (!row.getZeroHeight()) {
// while (rowIterator.hasNext()) {

				int currentCellIndex = 0;

				for (int j = 0; j < row.getPhysicalNumberOfCells(); j++) {
					final Cell cell = row.getCell(j);

// Step #3: Creating new Row, Cell and Input value in the newly created sheet.

///String cellData = cell.getStringCellValue();

					String cellData = formatter.formatCellValue(cell).toString();
					if (currentCellIndex == 0)

						outputSheet.createRow(currentRowIndex).createCell(currentCellIndex).setCellValue(cellData);

					else

					if (cellData.isEmpty()) {
						outputSheet.getRow(currentRowIndex).createCell(currentCellIndex).setCellValue(" ");

					} else {

						outputSheet.getRow(currentRowIndex).createCell(currentCellIndex).setCellValue(cellData);
					}

					currentCellIndex++;

				}
				currentRowIndex++;

			//}
		}

		//System.out.println("Total " + (currentRowIndex - 1) + " rows are Copied in the new Workbook with sheet name- "
		//		+ "'" + outputSheet.getSheetName() + "'");

	}

	
	
	@Test (priority = 3)
	public static void compareAndFindAttritionAgainstExistingRosterTable() throws IOException, SQLException {
		
		if(!DigitalRosterExtractTableNameDates.isEmpty())
		{
		//CVSTrainRosterExcel2DatabaseTest.main();
		
			//select * from  DigitalRosterExtract_07132022 WHERE  ColleagueID NOT IN (SELECT ColleagueID FROM DigitalRosterExtract_07202022)
		String DigitalRosterExtractVsExistingDigitalRosterExtractAttritionQuery = getPropertyValueFromPropertyFile("DigitalRosterExtractVsExistingDigitalRosterExtractAttritionQuery");
		String digitalRosterAttritionTableName = getPropertyValueFromPropertyFile("digitalRosterAttritionTableName");
		String RosterExtractName = getPropertyValueFromPropertyFile("RosterExtractName");
		
			if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
 	         {
				
				String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
				if(firstReportWorkBook.contains("true"))
				{
					System.out.println("Since this is the first sheet - there are no leavers");
				}
				else
				{
				CalculateWeeklyAttrition(DigitalRosterExtractVsExistingDigitalRosterExtractAttritionQuery,
						digitalRosterAttritionTableName,DigitalRosterExtractTableNameDates.get(0), fileNames[0].split(".xlsx")[0].split("_")[1].toString().replaceAll("-", ""), RosterExtractName);
				}
				}
		}
		
		else
		{
			String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
			if(firstReportWorkBook.contains("true"))
			{
				System.out.println("Since this is the first sheet - there are no leavers");
			}
			
		}
	}
	
	
	
	public static void CalculateWeeklyAttrition(String weeklyAttritionQuery,String digitalRosterAttritionTableName, String existingDBTable, String newTableName, String rosterExtractName) throws SQLException, IOException
	{
		weeklyAttritionQuery = weeklyAttritionQuery.replaceAll("existingTable",rosterExtractName+"_"+existingDBTable);		       
		weeklyAttritionQuery = weeklyAttritionQuery.replaceAll("newlyCreatedTable",rosterExtractName+"_"+newTableName);
          
		ResultSet rs = connection.createStatement().executeQuery(weeklyAttritionQuery);
		String createAttritionTableQuery =  getPropertyValueFromPropertyFile("createAttritionTableQuery");
		createNewTableInDB(fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", ""), createAttritionTableQuery);
		PushRecordSetToExcel(weeklyAttritionQuery,"Attrition_"+newTableName,connection,"Leavers");
		CVSCompareDatabaseTablesTest.copyResultsetToTable(weeklyAttritionQuery, digitalRosterAttritionTableName.trim()+"_"+newTableName, connection, connection);
		
	}
	
	@Test (priority = 4)
	public static void compareAndFindJoinersAgainstExistingRosterTable() throws IOException, SQLException {
		
		if(!DigitalRosterExtractTableNameDates.isEmpty())
		{
		//CVSTrainRosterExcel2DatabaseTest.main();
		
		String DigitalRosterExtractVsExistingDigitalRosterExtractJoinersQuery = getPropertyValueFromPropertyFile("DigitalRosterExtractVsExistingDigitalRosterExtractJoinersQuery");
		String digitalRosterJoinersTableName = getPropertyValueFromPropertyFile("digitalRosterJoinersTableName");
		String RosterExtractName = getPropertyValueFromPropertyFile("RosterExtractName");
		
			if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
 	         {
				
				String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
				if(firstReportWorkBook.contains("true"))
				{
					System.out.println("Since this is the first sheet - there are no joiners");
				}
				else
				{
				
				CalculateWeeklyJoiners(DigitalRosterExtractVsExistingDigitalRosterExtractJoinersQuery,
						digitalRosterJoinersTableName,DigitalRosterExtractTableNameDates.get(0), fileNames[0].split(".xlsx")[0].split("_")[1].toString().replaceAll("-", ""), RosterExtractName);
				}
				}
		}
		
		else
		{
			String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
			if(firstReportWorkBook.contains("true"))
			{
				System.out.println("Since this is the first sheet - there are no joiners");
			}
		}
	}
	
	
	
	
	public static void CalculateWeeklyJoiners(String weeklyJoinersQuery,String digitalRosterJoinersTableName, String existingDBTable, String newTableName, String rosterExtractName) throws SQLException, IOException
	{
		weeklyJoinersQuery = weeklyJoinersQuery.replaceAll("existingTable",rosterExtractName+"_"+existingDBTable);		       
		weeklyJoinersQuery = weeklyJoinersQuery.replaceAll("newlyCreatedTable",rosterExtractName+"_"+newTableName);
          
		ResultSet rs = connection.createStatement().executeQuery(weeklyJoinersQuery);
		String createJoinersTableQuery =  getPropertyValueFromPropertyFile("createJoinersTableQuery");
		createNewTableInDB(fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", ""), createJoinersTableQuery);
		PushRecordSetToExcel(weeklyJoinersQuery,"Joiners_"+newTableName,connection, "Joiners");
		CVSCompareDatabaseTablesTest.copyResultsetToTable(weeklyJoinersQuery, digitalRosterJoinersTableName.trim()+"_"+newTableName, connection, connection);
		
	}
	
	@Test (priority = 5, enabled=true)
	public static void compareAndFindDiffAgainstExistingRosterTable() throws IOException, SQLException {
		
		
		
		String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
		if(!TrainRosterExtractTableNameDates.isEmpty() || !DigitalRosterExtractTableNameDates.isEmpty())
		{
		//CVSTrainRosterExcel2DatabaseTest.main();
		
		String TrainRosterExtractVsExistingTrainRosterExtractDiffQuery = getPropertyValueFromPropertyFile("TrainRosterExtractVsExistingTrainRosterExtractDiffQuery");
		String DigitalRosterExtractVsExistingDigitalRosterExtractDiffQuery = getPropertyValueFromPropertyFile("DigitalRosterExtractVsExistingDigitalRosterExtractDiffQuery");
		String trainRosterDiffTableName = getPropertyValueFromPropertyFile("trainRosterDiffTableName");
		String digitalRosterDiffTableName = getPropertyValueFromPropertyFile("DigitalRosterDiffTableName");
		String rosterExtractName = getPropertyValueFromPropertyFile("RosterExtractName");
		if (getPropertyValueFromPropertyFile("RosterExtractName").contains("TrainRosterExtract"))
	         {
		CVSCompareDatabaseTablesTest.CompareTablesAndFindDiff(TrainRosterExtractVsExistingTrainRosterExtractDiffQuery,
				trainRosterDiffTableName, TrainRosterExtractTableNameDates.get(0),fileNames[0].split(".xlsx")[0].split("_")[1].toString().replaceAll("-", ""),rosterExtractName);
	         }
		else
			if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
 	         {
				//create the diff table if not present
				for (int k = 0; k < listofTable.size(); k++) {

					if (listofTable.get(k).contains("digitalrosterextractdiff")) {
						digitalrosterextractdiffTable_flag = true;
						break;

					}
				}
				if(digitalrosterextractdiffTable_flag==false)
				{
					
					  String newFileDate = fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "");
					//create the diff table
					   if (connection != null) {
				           Statement st3 = null;
				           try {
				               st3 = (Statement) connection.createStatement();
				           } catch (SQLException ex) {
				               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
				           }
				           
				        
				           String createDiffTableQuery= CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("createDigitalExtractDiffTableQuery");
				        System.out.println("createDiffTableQuery:"+createDiffTableQuery);
				           //   ResultSet rs3 = null;
				           try { 
				                st3.execute(createDiffTableQuery);
				           } catch (SQLException ex) {
				               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
				           }
				       }
				       
				       
				        //resultSet = statement1.execute(createTableQuery);
				        connection.commit();
				        
				        connection.close();
				}
				
				if(firstReportWorkBook.contains("true"))
				{
					System.out.println("This is the first file - so diff can be evaluated");
				}
				else
				{
				CVSCompareDatabaseTablesTest.CompareTablesAndFindDiff(DigitalRosterExtractVsExistingDigitalRosterExtractDiffQuery,
						digitalRosterDiffTableName, DigitalRosterExtractTableNameDates.get(0),fileNames[0].split(".xlsx")[0].split("_")[1].toString().replaceAll("-", ""),rosterExtractName);
				}
				}
				
		}
	}
	
	public static String getPropertyValueFromPropertyFile(String propertKey) throws IOException
	{
		FileReader reader = new FileReader("./resources/cvsReportsProperties.properties");
		Properties p = new Properties();
		p.load(reader);
		return p.getProperty(propertKey);
	}
	
	
	public static void setPropertyValueInPropertyFile(String propertyKey, String propertyValue) throws IOException
	{
		FileReader reader = new FileReader("./resources/cvsReportsProperties.properties");
		Properties p = new Properties();
		p.load(reader);
		p.getProperty(propertyKey);
		p.setProperty(propertyKey, propertyValue);
		  File file = new File("./resources/cvsReportsProperties.properties");
	        FileOutputStream fOut = new FileOutputStream(file);
	        p.store(fOut, "updated the properties file");
	        fOut.close();
	}
	
	public static void createNewTableInDB(String fileDate, String createTableQuery) throws IOException
	{
		
	int batchSize = 20;
	  // variables
    Connection connection = null;
    //Statement statement = null;
    boolean resultSet = false;
    Statement statement1 = null;

    // Step 1: Loading or registering Oracle JDBC driver class
    try {

        Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
    }
    catch(ClassNotFoundException cnfex) {

        System.out.println("Problem in loading or "
                + "registering MS Access JDBC driver");
        cnfex.printStackTrace();
    }

    // Step 2: Opening database connection
    try {

        String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
        String dbURL = "jdbc:ucanaccess://" + msAccDB; 

        // Step 2.A: Create and get connection using DriverManager class
        connection = DriverManager.getConnection(dbURL); 

        // Step 2.B: Creating JDBC Statement 
        //statement = connection.createStatement();
       long start = System.currentTimeMillis();
         
        connection = DriverManager.getConnection(dbURL);
        connection.setAutoCommit(false);
        
        
       PreparedStatement statement = null; 
       String newFileDate = fileDate.replaceAll("-", "");
       
       if (connection != null) {
           Statement st3 = null;
           try {
               st3 = (Statement) connection.createStatement();
           } catch (SQLException ex) {
               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
           }
           
        
           createTableQuery= createTableQuery.replace("newFileDate", newFileDate);
           //   ResultSet rs3 = null;
           try { 
                st3.execute(createTableQuery);
           } catch (SQLException ex) {
               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
           }
       }
       
       
        //resultSet = statement1.execute(createTableQuery);
        connection.commit();
        
        connection.close();

	} catch (SQLException ex2) {
    System.out.println("Database error");
    ex2.printStackTrace();
}
	}
	
	
	
	public static void PushRecordSetToExcel(String weeklyAttritionQuery,String AttritionJoinersNewTableName,Connection connection, String LeaversOrJoiners)
	{
		List<String> headerValues=new ArrayList<String>();
		
	    XSSFWorkbook workbook = new XSSFWorkbook();
	    try {

	    	XSSFSheet spreadsheet=null;
	    Statement statement = connection.createStatement();
	    if(AttritionJoinersNewTableName.contains("_"))
	    {
	    spreadsheet = workbook.createSheet(LeaversOrJoiners+"_"+AttritionJoinersNewTableName.split("_")[1].trim());
	    }
	    else
	    {
	    spreadsheet = workbook.createSheet(LeaversOrJoiners+"_"+AttritionJoinersNewTableName.trim());	
	    }
	    //PreparedStatement preparedStatement = connection.prepareStatement(weeklyAttritionQuery);  
	     ResultSet resultSet = statement.executeQuery(weeklyAttritionQuery);


	      XSSFRow row = spreadsheet.createRow(0);
	      XSSFCell cell;
	      int cc=resultSet.getMetaData().getColumnCount();
	      for(int i=1;i<=cc;i++)
	      {
	          String headerVal=resultSet.getMetaData().getColumnName(i);
	          headerValues.add(headerVal);
	          cell = row.createCell(i-1);
	          cell.setCellValue(resultSet.getMetaData().getColumnName(i));
	      }
	      System.out.println(headerValues);

	      int i = 1;
	      while (resultSet.next())
	      {  

	          XSSFRow row1 = spreadsheet.createRow((short) i);
	          for(int p=0;p<headerValues.size();p++)
	          {
	          row1.createCell(p).setCellValue(resultSet.getString(headerValues.get(p)).toString());
	          }
	          i++;
	      } 
	      FileOutputStream out =null;
	      if(LeaversOrJoiners=="Leavers")
	      {
	      out = new FileOutputStream(new File("./resources/Attrition/"+AttritionJoinersNewTableName+".xlsx"));
	      }
	      else
	      if(LeaversOrJoiners=="Joiners")
	      {
	      out = new FileOutputStream(new File("./resources/Joiners/"+AttritionJoinersNewTableName+".xlsx"));
	      }
	      else
	      {
	      out = new FileOutputStream(new File("./resources/SummaryDetails/MonthWiseSummaryReports/"+AttritionJoinersNewTableName+"_"+LeaversOrJoiners+".xlsx"));
	      }
	      workbook.write(out);
	      out.close();  
	      workbook.close();
	      System.out.println("Data from DB written successfully to excel");

	}catch(Exception e){
		 e.printStackTrace();
	}
	}
	

	
	
}
