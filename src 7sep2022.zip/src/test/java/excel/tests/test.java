package excel.tests;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

public class test {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		
		//connect to DB
		
		
		// variables
		Connection connection = null;
		// Statement statement = null;
		ResultSet resultSet = null;

		// Step 1: Loading or registering Oracle JDBC driver class
		try {

			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		} catch (ClassNotFoundException cnfex) {

			System.out.println("Problem in loading or " + "registering MS Access JDBC driver");
			cnfex.printStackTrace();
		}

		// Step 2: Opening database connection
		try {

			String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
			String dbURL = "jdbc:ucanaccess://" + msAccDB;

			// Step 2.A: Create and get connection using DriverManager class
			connection = DriverManager.getConnection(dbURL);
		} catch (Exception ex) {

			System.out.println("DriverManager.getConnection(dbURL) failed");
			System.out.println();
			ex.printStackTrace();

		}



   

	  //generate the final report
		 String datetime ="";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Calendar calendar = Calendar.getInstance();
		try {
		     //calendar.setTime(simpleDateFormat.parse("11/20/2014 8:10:00 AM"));

		     String str3 = String.valueOf(calendar.get(Calendar.DAY_OF_MONTH));
		     datetime = String.valueOf(calendar.get(Calendar.DAY_OF_MONTH))+String.valueOf(calendar.get(Calendar.MONTH))+String.valueOf(calendar.get(Calendar.YEAR))+String.valueOf(calendar.get(Calendar.HOUR))+String.valueOf(calendar.get(Calendar.MINUTE));

		} catch (Exception e) {
		   e.printStackTrace();
		}
		String DigitalRosterExtractMonthwiseFinalReportQuery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("DigitalRosterExtractMonthwiseFinalReportQuery");
		CVSPushRosterToDBAndFindDiffAndAttrition.PushRecordSetToExcel(DigitalRosterExtractMonthwiseFinalReportQuery,"FinalReport",connection,datetime);
	}

}
