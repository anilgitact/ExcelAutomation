package excel.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections4.MultiMap;
import org.apache.commons.collections4.map.MultiValueMap;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTAutoFilter;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTFilter;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTFilterColumn;

import com.excel.lib.util.Xls_Reader;

import io.github.bonigarcia.wdm.WebDriverManager;



public class EmployessPerSVP {

	private static String[] columns = {"SVP","FTECount","ContractorCount","Senior Leader", "FTECount", "ContractorCount"};
	public static void main(String[] args) throws IOException, InvalidFormatException {

		
		
		
        Workbook workbook = new XSSFWorkbook(); // new HSSFWorkbook() for generating `.xls` file

        
        CreationHelper createHelper = workbook.getCreationHelper();

        // Create a Sheet
        Sheet sheet = workbook.createSheet("Employee");

        // Create a Font for styling header cells
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 14);
        headerFont.setColor(IndexedColors.RED.getIndex());

        // Create a CellStyle with the font
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFont(headerFont);

        // Create a Row
        Row headerRow = sheet.createRow(0);

        // Create cells
        for(int i = 0; i < columns.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
            cell.setCellStyle(headerCellStyle);
        }

		
		
		
				
		Xls_Reader reader = new Xls_Reader("./resources/ROV - Digital Roster-Opens Visibility 07-20 OZone.xlsx");
		String sheetName = "Digital Roster Extract";
		ZipSecureFile.setMinInflateRatio(0);
		XSSFWorkbook wb =null;
		File fp = new File("./resources/AutoFilterSetTest.xlsx");
		FileInputStream fpis = new FileInputStream(fp);
		try {
			wb = (XSSFWorkbook) WorkbookFactory.create(fpis);
		} finally {
		    fpis.close();
		}
		
		 //XSSFWorkbook wb = new XSSFWorkbook(new File("./resources/AutoFilterSetTest.xlsx"));
		 
         //Get first/desired sheet from the workbook
         XSSFSheet sh = wb.getSheet("sheet1");
		
		MultiMap multiMapLeader = new MultiValueMap();
		MultiMap multiMapSVP = new MultiValueMap();
		int rowCount = reader.getRowCount(sheetName);

			
	
		for(int rowNum=2; rowNum<=rowCount; rowNum++){
			String leaderName = reader.getCellData(sheetName, "Senior Leader", rowNum);
			String empType = reader.getCellData(sheetName, "Type", rowNum);

			        	multiMapLeader.put(leaderName,empType);
		}
		
		for(int rowNum=2; rowNum<=rowCount; rowNum++){
			String svpName = reader.getCellData(sheetName, "SVP", rowNum);
			String empType = reader.getCellData(sheetName, "Type", rowNum);

			        	multiMapSVP.put(svpName,empType);
		}
		
		//store employee count for SVP in sheet
		int fteCount=0;
		int contractorCount =0;
		int rowNum = 1;
		Row row = null;
		// get all the set of keys
        Set<String> keys = multiMapSVP.keySet();
         System.out.println(keys);
        // iterate through the key set and display key and values
        for (String key : keys) {
            System.out.println("Key = " + key);
            System.out.println("\n");

           String s= multiMapSVP.get(key).toString();
           String[] ls = s.split(",");
           for(int i=0;i<ls.length;i++)
           {
        	   if(ls[i].contains("FTE"))
        	   {
        		   fteCount++;
        	   }
        	   if(ls[i].contains("Contractor"))
        	   {
        		   contractorCount++;
        	   }
           }
           System.out.println(fteCount);
           System.out.println(contractorCount);
        
            System.out.println("Values = " + multiMapSVP.get(key) + "\n");
            
            // Create Other rows and cells with employees data
            
       
                row = sheet.createRow(rowNum++);
                row.createCell(0)
                     .setCellValue(key);
                
                row.createCell(1)
                        .setCellValue(fteCount);

                row.createCell(2)
                        .setCellValue(contractorCount);
                
            
                Set<String> leaderkeys = multiMapLeader.keySet();
                System.out.println(leaderkeys);
               // iterate through the key set and display key and values
               for (String leaderkey : leaderkeys) {
                   System.out.println("Key = " + leaderkey);
                   System.out.println("\n");

                  String s1= multiMapLeader.get(leaderkey).toString();
                  String[] ls1 = s1.split(",");
                  for(int i=0;i<ls1.length;i++)
                  {
               	   if(ls1[i].contains("FTE"))
               	   {
               		   fteCount++;
               	   }
               	   if(ls1[i].contains("Contractor"))
               	   {
               		   contractorCount++;
               	   }
                  }
                  System.out.println(fteCount);
                  System.out.println(contractorCount);
               
                   System.out.println("Values = " + multiMapLeader.get(leaderkey) + "\n");
                   
                   // Create Other rows and cells with employees data
                   
              
                       row = sheet.createRow(rowNum++);
              
                       
                       row.createCell(3)
                               .setCellValue(leaderkey);

                       row.createCell(4)
                               .setCellValue(fteCount);
                       
                       row.createCell(5)
                       .setCellValue(contractorCount);
                
                
                       
                fteCount=0;
     		   contractorCount =0;
            }
        
         
		   
		            } 
        
        

    		// Resize all columns to fit the content size
            for(int i = 0; i < columns.length; i++) {
                sheet.autoSizeColumn(i);
            }

            // Write the output to a file
            FileOutputStream fileOut = new FileOutputStream(".\\resources\\SummaryDetails.xlsx");
            workbook.write(fileOut);
            fileOut.close();

            // Closing the workbook
            workbook.close();
        }
     
		
	
	
	static void setAutoFilter(final XSSFSheet sheet, final int column, final String value) {
	    sheet.setAutoFilter(CellRangeAddress.valueOf("A1:Z1"));

	    final CTAutoFilter sheetFilter = sheet.getCTWorksheet().getAutoFilter();
	    final CTFilterColumn filterColumn = sheetFilter.addNewFilterColumn();
	    filterColumn.setColId(column);
	    final CTFilter filter = filterColumn.addNewFilters().insertNewFilter(0);
	    filter.setVal(value);

	    // We have to apply the filter ourselves by hiding the rows: 
	    for (final Row row : sheet) {
	        for (final Cell c : row) {
	            if (c.getColumnIndex() == column && !c.getStringCellValue().equals(value)) {
	                final XSSFRow r1 = (XSSFRow) c.getRow();
	                if (r1.getRowNum() != 0) { // skip header
	                    r1.getCTRow().setHidden(true);
	                }
	            }
	        }
	    }
	}
	
	
	
	
	public void ApplyFilterInExcelUsingJava(XSSFSheet my_sheet) {
		
		 /* Auto filter for xlsx workbooks */
        XSSFWorkbook my_workbook = new XSSFWorkbook();
        XSSFSheet my_sheet = my_workbook.createSheet("Autofilter");
        
        my_sheet.setAutoFilter(CellRangeAddress.valueOf("A1:C5"));
        /* Write changes to the workbook */
        FileOutputStream out = new FileOutputStream(new File("C:\\auto_filter_output.xlsx"));
        my_workbook.write(out);
        out.close();
		
		
		
	}
	
	
		
	}


