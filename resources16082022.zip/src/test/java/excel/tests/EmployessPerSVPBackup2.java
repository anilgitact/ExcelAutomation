package excel.tests;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections4.MultiMap;
import org.apache.commons.collections4.map.MultiValueMap;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CreationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.excel.lib.util.Xls_Reader;

import io.github.bonigarcia.wdm.WebDriverManager;

public class EmployessPerSVPBackup2 {

	private static String[] columns = {"SVP","FTECount","ContractorCount","Senior Leader", "FTECount", "ContractorCount"};
	public static void main(String[] args) throws IOException {

		
		
		
        Workbook workbook = new XSSFWorkbook(); // new HSSFWorkbook() for generating `.xls` file

        
        CreationHelper createHelper = workbook.getCreationHelper();

        // Create a Sheet
        Sheet sheet = workbook.createSheet("Employee");

        // Create a Font for styling header cells
        Font headerFont = workbook.createFont();
        headerFont.setBold(true);
        headerFont.setFontHeightInPoints((short) 14);
        headerFont.setColor(IndexedColors.RED.getIndex());

        // Create a CellStyle with the font
        CellStyle headerCellStyle = workbook.createCellStyle();
        headerCellStyle.setFont(headerFont);

        // Create a Row
        Row headerRow = sheet.createRow(0);

        // Create cells
        for(int i = 0; i < columns.length; i++) {
            Cell cell = headerRow.createCell(i);
            cell.setCellValue(columns[i]);
            cell.setCellStyle(headerCellStyle);
        }

		
		
		
				
		Xls_Reader reader = new Xls_Reader("./resources/ROV_Digital_Roster_Opens_Visibility_07_20_OZone.xlsx");
		String sheetName = "Digital Roster Extract";
		
		MultiMap multiMapLeader = new MultiValueMap();
		MultiMap multiMapSVP = new MultiValueMap();
		int rowCount = reader.getRowCount(sheetName);

		for(int rowNum=2; rowNum<=rowCount; rowNum++){
			String leaderName = reader.getCellData(sheetName, "Senior Leader", rowNum);
			String empType = reader.getCellData(sheetName, "Type", rowNum);

			        	multiMapLeader.put(leaderName,empType);
		}
		
		for(int rowNum=2; rowNum<=rowCount; rowNum++){
			String svpName = reader.getCellData(sheetName, "SVP", rowNum);
			String empType = reader.getCellData(sheetName, "Type", rowNum);

			        	multiMapSVP.put(svpName,empType);
		}
		
		//store employee count for SVP in sheet
		int fteCount=0;
		int contractorCount =0;
		int rowNum = 1;
		Row row = null;
		// get all the set of keys
        Set<String> keys = multiMapSVP.keySet();
         System.out.println(keys);
        // iterate through the key set and display key and values
        for (String key : keys) {
            System.out.println("Key = " + key);
            System.out.println("\n");

           String s= multiMapSVP.get(key).toString();
           String[] ls = s.split(",");
           for(int i=0;i<ls.length;i++)
           {
        	   if(ls[i].contains("FTE"))
        	   {
        		   fteCount++;
        	   }
        	   if(ls[i].contains("Contractor"))
        	   {
        		   contractorCount++;
        	   }
           }
           System.out.println(fteCount);
           System.out.println(contractorCount);
        
            System.out.println("Values = " + multiMapSVP.get(key) + "\n");
            
            // Create Other rows and cells with employees data
            
       
                row = sheet.createRow(rowNum++);
                row.createCell(0)
                     .setCellValue(key);
                
                row.createCell(1)
                        .setCellValue(fteCount);

                row.createCell(2)
                        .setCellValue(contractorCount);
                
            
                fteCount=0;
     		   contractorCount =0;
            }
        
         
		   rowNum =0;
		//store employee count for senior leader in sheet
		// get all the set of keys
        Set<String> leaderkeys = multiMapLeader.keySet();
         System.out.println(leaderkeys);
        // iterate through the key set and display key and values
        for (String key : leaderkeys) {
            System.out.println("Key = " + key);
            System.out.println("\n");

           String s= multiMapLeader.get(key).toString();
           String[] ls = s.split(",");
           for(int i=0;i<ls.length;i++)
           {
        	   if(ls[i].contains("FTE"))
        	   {
        		   fteCount++;
        	   }
        	   if(ls[i].contains("Contractor"))
        	   {
        		   contractorCount++;
        	   }
           }
           System.out.println(fteCount);
           System.out.println(contractorCount);
        
            System.out.println("Values = " + multiMapLeader.get(key) + "\n");
            
            // Create Other rows and cells with employees data
            
       
                //Row row = sheet.createRow(rowNum++);
       
                
                row.createCell(3)
                        .setCellValue(key);

                row.createCell(4)
                        .setCellValue(fteCount);
                
                row.createCell(5)
                .setCellValue(contractorCount);
                fteCount=0;
     		   contractorCount =0;
            } 
        
        

    		// Resize all columns to fit the content size
            for(int i = 0; i < columns.length; i++) {
                sheet.autoSizeColumn(i);
            }

            // Write the output to a file
            FileOutputStream fileOut = new FileOutputStream(".\\resources\\SummaryDetails.xlsx");
            workbook.write(fileOut);
            fileOut.close();

            // Closing the workbook
            workbook.close();
        }
     
		
		
	}


