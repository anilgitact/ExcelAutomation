package excel.tests;

import org.apache.commons.io.FileUtils;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.*;
import org.apache.poi.xssf.usermodel.*;

import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTAutoFilter;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTFilterColumn;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTFilters;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTCustomFilters;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTCustomFilter;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.STFilterOperator;

import com.excel.lib.util.Xls_Reader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.util.HashSet;
import java.util.Set;

class filterTestForAttrition {
	static String[] processFileNames = null;
	static String[] attritionFileNames = null;
	static String targetAttritionFileName = "";
 
 private static void setCriteriaFilter(XSSFSheet sheet, int colId, int firstRow, int lastRow, String[] criteria) throws Exception {
  CTAutoFilter ctAutoFilter = sheet.getCTWorksheet().getAutoFilter();
  CTFilterColumn ctFilterColumn = null;
  for (CTFilterColumn filterColumn : ctAutoFilter.getFilterColumnList()) {
   if (filterColumn.getColId() == colId) ctFilterColumn = filterColumn;
  }
  if (ctFilterColumn == null) ctFilterColumn = ctAutoFilter.addNewFilterColumn();
  ctFilterColumn.setColId(colId);
  if (ctFilterColumn.isSetFilters()) ctFilterColumn.unsetFilters();

  CTFilters ctFilters = ctFilterColumn.addNewFilters();
  for (int i = 0; i < criteria.length; i++) {
   ctFilters.addNewFilter().setVal(criteria[i]);
  }

  //hiding the rows not matching the criterias
  DataFormatter dataformatter = new DataFormatter();
  for (int r = firstRow; r <= lastRow; r++) {
   XSSFRow row = sheet.getRow(r);
   boolean hidden = true;
   for (int i = 0; i < criteria.length; i++) {
    String cellValue = dataformatter.formatCellValue(row.getCell(colId));
    if (criteria[i].equals(cellValue)) hidden = false;
   }
   if (hidden) {
    row.getCTRow().setHidden(hidden);
   } else {
    if (row.getCTRow().getHidden()) row.getCTRow().unsetHidden();
   }
  }
 }

 public static void main(String[] args) throws Exception {

	 

		File processDirectoryPath = new File("./resources/process/");
		processFileNames = processDirectoryPath.list();
		String mainInputFile = processFileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "");
		// List of all files and directories
		File attritionDirectoryPath = new File("./resources/attrition/");
		attritionFileNames = attritionDirectoryPath.list();
		for(int i=0;i<attritionFileNames.length;i++)
		{
			if(attritionFileNames[i].contains(mainInputFile))
					{
				  targetAttritionFileName = attritionFileNames[i];
						  break;
					}
		}
		
	 Workbook workbook = new XSSFWorkbook();
	 Sheet sheet1 = workbook.createSheet("Leavers Per SVP");
	 FileOutputStream fileOut = null;
	 
  Xls_Reader reader = new Xls_Reader("./resources/attrition/"+targetAttritionFileName);
  XSSFWorkbook wb = new XSSFWorkbook(new File("./resources/attrition/"+targetAttritionFileName));
	String sheetName = "Leavers_"+mainInputFile;

	
	Set<String> hash_Set = new HashSet<String>();
	
	for(int rowNum=2; rowNum<=wb.getSheet("Leavers_"+mainInputFile).getLastRowNum(); rowNum++){
		String svpNames = reader.getCellData(sheetName, "SVP", rowNum);

		hash_Set.add(svpNames);
	}
	 for (int c = 0; c < 28; c++) wb.getSheet("Leavers_"+mainInputFile).autoSizeColumn(c);
	 for (String svpValue : hash_Set)
	 {
		 wb = new XSSFWorkbook(new File("./resources/attrition/"+targetAttritionFileName));
		 XSSFSheet sheet = wb.getSheet("Leavers_"+mainInputFile);
  //create rows of data
  //setCellData(sheet)
		 //wb.createSheet(svpValue);
 

  int lastRow = sheet.getLastRowNum();
  XSSFAutoFilter autofilter = sheet.setAutoFilter(new CellRangeAddress(0, lastRow, 0, 28));
  //XSSFAutoFilter is useless until now

  //set filter criteria 
  setCriteriaFilter(sheet, 19, 1, lastRow, new String[]{svpValue});

  //get only visible rows after filtering
  XSSFRow row = null;
  for (int r = 1; r <= lastRow; r++) {
   row = sheet.getRow(r);
   if (row.getCTRow().getHidden()) continue;
			
			 /* for (int c = 0; c < 3; c++) { 
				  System.out.print(row.getCell(c) + "\t"); 
				  }*/
			 
   System.out.println();
  }
	 
  FileOutputStream finalout = new FileOutputStream("./resources/Attrition/filteredRoster_"+svpValue+".xlsx");
  wb.write(finalout);
  finalout.close();
  wb.close();
  
  
  
	String TargetSheetPathAndName = "./resources/attrition/filteredRoster_"+svpValue+".xlsx";

String NewSheetPathAndName = "./resources/attrition/FinalRoster_"+svpValue+".xlsx";

if (TargetSheetPathAndName != null && !"".equals(TargetSheetPathAndName.trim())) {

try {

File targetFile = new File(TargetSheetPathAndName.trim());

FileInputStream inputStream = new FileInputStream(targetFile);

XSSFWorkbook inputWorkbook = new XSSFWorkbook(inputStream);

int targetSheetCount = inputWorkbook.getNumberOfSheets();

System.out.println("Total no. of sheet(s) in the Target Workbook: " + targetSheetCount);

File outputFile = new File(NewSheetPathAndName.trim());

FileOutputStream outputStream = new FileOutputStream(outputFile);

XSSFWorkbook outputWorkbook = new XSSFWorkbook();

//Step #2 : Creating sheets with the same name as appearing in target workbook.

for (int i = 0; i < targetSheetCount; i++) {

XSSFSheet targetSheet = inputWorkbook.getSheetAt(i);

String inputSheetName = inputWorkbook.getSheetName(i);
if(inputSheetName.equals("Leavers_"+mainInputFile))
{

XSSFSheet outputSheet = outputWorkbook.createSheet(inputSheetName);


CopyFilteredExcel.copyExcelWB(targetSheet, outputSheet);
}

}

//Step #4 : Write all the sheets in the new Workbook using FileOutStream Object (Step 3 is mentioned below)

outputWorkbook.write(outputStream);
outputStream.close();
outputWorkbook.close();


LeaversPerSVP.createAttritionSummaryView(svpValue, workbook, sheet1, mainInputFile);



}

catch (Exception ex) {

System.out.println("Please check the target sheet given path and name: " + TargetSheetPathAndName);

System.out.println();

ex.printStackTrace();

}

//Write the output to a file



fileOut = new FileOutputStream(".\\resources\\attrition\\AttritionSummary_"+mainInputFile+".xlsx");
workbook.write(fileOut);


}
}
	 
	 fileOut.close();

	// Closing the workbook
	workbook.close();
	
	String destinationFolderPath = ".\\resources\\attrition\\AttritionSummaries";
	copyFileToAnotherFolder(destinationFolderPath, ".\\resources\\attrition\\Attrition_"+mainInputFile+".xlsx");	
	copyFileToAnotherFolder(destinationFolderPath,  ".\\resources\\attrition\\AttritionSummary_"+mainInputFile+".xlsx");	
	try {
		CopySheetFromOneWorkBookToAnother.mergeExcelFiles(new File(".\\resources\\attrition\\AttritionSummaries\\AttritionSummaryFinal_"+mainInputFile+".xlsx") , destinationFolderPath);
	} catch (IOException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
}
 
 
 
 
 public static void copyFileToAnotherFolder(String destFolderPath, String sourceFilePath) throws IOException
 {
	 
     String fileName = sourceFilePath.split("\\\\")[3];
     File f = new File(destFolderPath);
     if(f.mkdir()){
         System.out.println("Directory created!!!!");
     }
     else {
         System.out.println("Directory Exists!!!!");
     }
		/*
		 * f= new File(destFolderPath,fileName); if(f.createNewFile()) {
		 * 
		 * System.out.println("File Created!!!!"); } else {
		 * System.out.println("File exists!!!!"); }
		 */

     Files.copy(Paths.get(sourceFilePath), Paths.get(destFolderPath, fileName));
     System.out.println("Copy done!!!!!!!!!!!!!!");
 }
}