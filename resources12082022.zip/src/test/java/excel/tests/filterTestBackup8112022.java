package excel.tests;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.*;
import org.apache.poi.xssf.usermodel.*;

import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTAutoFilter;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTFilterColumn;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTFilters;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTCustomFilters;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTCustomFilter;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.STFilterOperator;

import com.excel.lib.util.Xls_Reader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.HashSet;
import java.util.Set;

class filterTestBackup8112022 {

 private static void setCellData(Sheet sheet) {

  Object[][] data = new Object[][] {
   new Object[] {"First name", "Last name", "Age"},
   new Object[] {"John", "Doe", 25},
   new Object[] {"Foo", "Bar", 20},
   new Object[] {"Jane", "Doe", 22},
   new Object[] {"Ruth", "Moss", 42},
   new Object[] {"Manuel", "Doe", 32},
   new Object[] {"Axel", "Richter", 56},
  };

  Row row = null;
  Cell cell = null;
  int r = 0;
  int c = 0;
  for (Object[] dataRow : data) {
   row = sheet.createRow(r);
   c = 0;
   for (Object dataValue : dataRow) {
    cell = row.createCell(c);
    if (dataValue instanceof String) {
     cell.setCellValue((String)dataValue);
    } else if (dataValue instanceof Number) {
     cell.setCellValue(((Number)dataValue).doubleValue());
    }
    c++;
   }
   r++;
  }
 }

 private static void setCriteriaFilter(XSSFSheet sheet, int colId, int firstRow, int lastRow, String[] criteria) throws Exception {
  CTAutoFilter ctAutoFilter = sheet.getCTWorksheet().getAutoFilter();
  CTFilterColumn ctFilterColumn = null;
  for (CTFilterColumn filterColumn : ctAutoFilter.getFilterColumnList()) {
   if (filterColumn.getColId() == colId) ctFilterColumn = filterColumn;
  }
  if (ctFilterColumn == null) ctFilterColumn = ctAutoFilter.addNewFilterColumn();
  ctFilterColumn.setColId(colId);
  if (ctFilterColumn.isSetFilters()) ctFilterColumn.unsetFilters();

  CTFilters ctFilters = ctFilterColumn.addNewFilters();
  for (int i = 0; i < criteria.length; i++) {
   ctFilters.addNewFilter().setVal(criteria[i]);
  }

  //hiding the rows not matching the criterias
  DataFormatter dataformatter = new DataFormatter();
  for (int r = firstRow; r <= lastRow; r++) {
   XSSFRow row = sheet.getRow(r);
   boolean hidden = true;
   for (int i = 0; i < criteria.length; i++) {
    String cellValue = dataformatter.formatCellValue(row.getCell(colId));
    if (criteria[i].equals(cellValue)) hidden = false;
   }
   if (hidden) {
    row.getCTRow().setHidden(hidden);
   } else {
    if (row.getCTRow().getHidden()) row.getCTRow().unsetHidden();
   }
  }
 }

 public static void main(String[] args) throws Exception {

	 Workbook workbook = new XSSFWorkbook();
	 Sheet sheet1 = workbook.createSheet("Employees Per SVP");
	 FileOutputStream fileOut = null;
  Xls_Reader reader = new Xls_Reader("./resources/roster.xlsx");
  XSSFWorkbook wb = new XSSFWorkbook(new File("./resources/roster.xlsx"));
	String sheetName = "Digital Roster Extract";

	
	Set<String> hash_Set = new HashSet<String>();
	
	for(int rowNum=2; rowNum<=wb.getSheet("Digital Roster Extract").getLastRowNum(); rowNum++){
		String svpNames = reader.getCellData(sheetName, "SVP", rowNum);

		hash_Set.add(svpNames);
	}
	 for (int c = 0; c < 28; c++) wb.getSheet("Digital Roster Extract").autoSizeColumn(c);
	 for (String svpValue : hash_Set)
	 {
		 wb = new XSSFWorkbook(new File("./resources/roster.xlsx"));
		 XSSFSheet sheet = wb.getSheet("Digital Roster Extract");
  //create rows of data
  //setCellData(sheet)
		 //wb.createSheet(svpValue);
 

  int lastRow = sheet.getLastRowNum();
  XSSFAutoFilter autofilter = sheet.setAutoFilter(new CellRangeAddress(0, lastRow, 0, 28));
  //XSSFAutoFilter is useless until now

  //set filter criteria 
  setCriteriaFilter(sheet, 18, 1, lastRow, new String[]{svpValue});

  //get only visible rows after filtering
  XSSFRow row = null;
  for (int r = 1; r <= lastRow; r++) {
   row = sheet.getRow(r);
   if (row.getCTRow().getHidden()) continue;
			
			 /* for (int c = 0; c < 3; c++) { 
				  System.out.print(row.getCell(c) + "\t"); 
				  }*/
			 
   System.out.println();
  }
	 
  FileOutputStream finalout = new FileOutputStream("./resources/filteredRoster_"+svpValue+".xlsx");
  wb.write(finalout);
  finalout.close();
  wb.close();
  
  
  
	String TargetSheetPathAndName = "./resources/filteredRoster_"+svpValue+".xlsx";

String NewSheetPathAndName = "./resources/FinalRoster_"+svpValue+".xlsx";

if (TargetSheetPathAndName != null && !"".equals(TargetSheetPathAndName.trim())) {

try {

File targetFile = new File(TargetSheetPathAndName.trim());

FileInputStream inputStream = new FileInputStream(targetFile);

XSSFWorkbook inputWorkbook = new XSSFWorkbook(inputStream);

int targetSheetCount = inputWorkbook.getNumberOfSheets();

System.out.println("Total no. of sheet(s) in the Target Workbook: " + targetSheetCount);

File outputFile = new File(NewSheetPathAndName.trim());

FileOutputStream outputStream = new FileOutputStream(outputFile);

XSSFWorkbook outputWorkbook = new XSSFWorkbook();

//Step #2 : Creating sheets with the same name as appearing in target workbook.

for (int i = 0; i < targetSheetCount; i++) {

XSSFSheet targetSheet = inputWorkbook.getSheetAt(i);

String inputSheetName = inputWorkbook.getSheetName(i);
if(inputSheetName.equals("Digital Roster Extract"))
{

XSSFSheet outputSheet = outputWorkbook.createSheet(inputSheetName);


CopyFilteredExcel.copyExcelWB(targetSheet, outputSheet);
}

}

//Step #4 : Write all the sheets in the new Workbook using FileOutStream Object (Step 3 is mentioned below)

outputWorkbook.write(outputStream);
outputStream.close();
outputWorkbook.close();


EmployessPerSVP.createSummaryView(svpValue, workbook, sheet1);


}

catch (Exception ex) {

System.out.println("Please check the target sheet given path and name: " + TargetSheetPathAndName);

System.out.println();

ex.printStackTrace();

}

//Write the output to a file



fileOut = new FileOutputStream(".\\resources\\SummaryDetails.xlsx");
workbook.write(fileOut);


}
}
	 
	 fileOut.close();

	// Closing the workbook
	workbook.close();
}
}