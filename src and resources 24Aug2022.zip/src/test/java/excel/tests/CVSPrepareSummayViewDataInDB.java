package excel.tests;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.testng.annotations.Test;

public class CVSPrepareSummayViewDataInDB {

	public static void main(String[] args) throws SQLException, IOException {
		// TODO Auto-generated method stub
	}
		
	@Test
		public static void pushWeeklySummaryDataToDB() throws IOException, SQLException
		{
			
			
			try
			{
		File directoryPath = new File("./resources/process/");
		// List of all files and directories
		String fileNames[] = directoryPath.list();
		String weeklyDigitalExtractHeadCountQuery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("WeeklySummaryViewDataCountJoinersLeaversQuery");
		String ROVWeekDateDigitalExtractHeadCountQuery ="";
		String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
		if(firstReportWorkBook=="true")
		{
			ROVWeekDateDigitalExtractHeadCountQuery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("ROVWeekDate");
			ROVWeekDateDigitalExtractHeadCountQuery = ROVWeekDateDigitalExtractHeadCountQuery.replaceAll("ROVWeekDate", fileNames[0].split("_")[1].replaceAll("-", ""));
		}
		else
		{
		weeklyDigitalExtractHeadCountQuery = weeklyDigitalExtractHeadCountQuery.replaceAll("ROVWeekDate",fileNames[0].split("_")[1].replaceAll("-", ""));
		}
		// variables
				Connection connection = null;
				// Statement statement = null;
				ResultSet resultSet = null;

				// Step 1: Loading or registering Oracle JDBC driver class
				try {

					Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				} catch (ClassNotFoundException cnfex) {

					System.out.println("Problem in loading or " + "registering MS Access JDBC driver");
					cnfex.printStackTrace();
				}

				// Step 2: Opening database connection
				try {

					String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
					String dbURL = "jdbc:ucanaccess://" + msAccDB;

					// Step 2.A: Create and get connection using DriverManager class
					connection = DriverManager.getConnection(dbURL);
				} catch (Exception ex) {

					System.out.println("DriverManager.getConnection(dbURL) failed");
					System.out.println();
					ex.printStackTrace();

				}
		//create the diff table
		   if (connection != null) {
	           Statement st3 = null;
	           try {
	               st3 = (Statement) connection.createStatement();
	           } catch (SQLException ex) {
	               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
	           }
	           
	        
	           //String createDiffTableQuery= CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("createDigitalExtractDiffTableQuery");
	           //   ResultSet rs3 = null;
	           try { 
	                //st3.execute(weeklyDigitalExtractHeadCountQuery);
	                CVSCompareDatabaseTablesTest.copyResultsetToTable(weeklyDigitalExtractHeadCountQuery, "SummaryViewData".trim(), connection, connection);
	                System.out.println("Summary View Data for week "+fileNames[0].split("_")[1].replaceAll("-", "")+" pushed to DB");
	           } catch (Exception  ex) {
	        	   
	        	  if (ex.getMessage().contains("object not found:"))
	        			  {
	        			  System.out.println("DIGITALROSTERATTRITION_mmddyyyy table not present in DB for  week "+fileNames[0].split("_")[1].replaceAll("-", ""));
	        			  }
	        	  
	        	 
	               //Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
	           }
	           finally {
	        	   if(firstReportWorkBook.contains("true"))
	       		{
	        	   CVSCompareDatabaseTablesTest.copyResultsetToTable(ROVWeekDateDigitalExtractHeadCountQuery, "SummaryViewData".trim(), connection, connection);
	                System.out.println("Summary View Data for week "+fileNames[0].split("_")[1].replaceAll("-", "")+" pushed to DB");
	       		}
	        	  }
	       }
	       
		  
	        //resultSet = statement1.execute(createTableQuery);
	        connection.commit();
	        
	        connection.close();
		
			 } catch (SQLException ex) {
	               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
	               System.out.println("some issues pushing the sumary view resultset to DB table: SummaryViewDate");
	           }
		
	}
		
	}

