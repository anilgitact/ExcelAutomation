package main.java;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.IsoFields;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class commonUtilityFunctions {
	
	
	
	public static void copyFile(File src, File dst) throws IOException {
	    InputStream in = new FileInputStream(src);
	    try {
	        OutputStream out = new FileOutputStream(dst);
	        try {
	            // Transfer bytes from in to out
	            byte[] buf = new byte[1024];
	            int len;
	            while ((len = in.read(buf)) > 0) {
	                out.write(buf, 0, len);
	            }
	        } finally {
	            out.close();
	        }
	    } finally {
	        in.close();
	    }
	}
	
	
	
	
public static void cleanFolder(String folderPath)
{
	File file = new File(folderPath);      
	String[] myFiles;    
	if (file.isDirectory()) {
	    myFiles = file.list();
	    for (int i = 0; i < myFiles.length; i++) {
	        File myFile = new File(file, myFiles[i]); 
	        myFile.delete();
	    }
	}
}



public static Connection connectToPostgresDB(String user, String password)
{
	
	
	//connect to DB
	
	String url = "jdbc:postgresql://localhost/postgres";
    /**
     * Connect to the PostgreSQL database
     */
  
        Connection conn = null;
        try {
            conn = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to the PostgreSQL server successfully.");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
return conn;
	
}




public static LocalDate getCurrentQuarterStartDay(LocalDate date) {
    return date.with(IsoFields.DAY_OF_QUARTER, 1L);
}

public static LocalDate getCurrentQuarterEndDate(LocalDate date) {
    return date.with(IsoFields.DAY_OF_QUARTER, 92L);
}

public static int getQuaterForCurrentDate()
{
//LocalDate currentDate = LocalDate.now();
//System.out.println("Current Date = "+currentDate);
Calendar cal = Calendar.getInstance(Locale.US);
int month = cal.get(Calendar.MONTH);
int quarter = (month / 3) + 1;
return quarter;

}

}
