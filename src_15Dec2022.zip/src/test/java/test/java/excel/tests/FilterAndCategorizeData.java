package test.java.excel.tests;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections4.MultiMap;
import org.apache.commons.collections4.map.MultiValueMap;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.excel.lib.util.Xls_Reader;

import io.github.bonigarcia.wdm.WebDriverManager;

public class FilterAndCategorizeData {

	public static void main(String[] args) {

		
		/*
		 * WebDriverManager.chromedriver().setup(); WebDriver driver = new
		 * ChromeDriver(); driver.get("https://pce100.myabilitynetwork.com/Auth/");
		 * driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		 * 
		 * WebElement userName = driver.findElement(By.name("username")); WebElement pwd
		 * = driver.findElement(By.name("password"));
		 */
		
		Xls_Reader reader = new Xls_Reader("./resources/test_data.xlsx");
		String sheetName = "test_data";
		MultiMap multiMap = new MultiValueMap();
		int rowCount = reader.getRowCount(sheetName);

		for(int rowNum=2; rowNum<=rowCount; rowNum++){
			String AdmissionType = reader.getCellData(sheetName, "Type of Admission", rowNum);
			String caseId = reader.getCellData(sheetName, "case_id", rowNum);

			//System.out.println(AdmissionType + " " + caseId);
			
			  

			        	multiMap.put(AdmissionType,caseId);
			        
			       
		}
		// get all the set of keys
        Set<String> keys = multiMap.keySet();
         System.out.println(keys);
        // iterate through the key set and display key and values
        for (String key : keys) {
            System.out.println("Key = " + key);
            System.out.println("\n");
            System.out.println("Values = " + multiMap.get(key) + "\n");
        }
		
		
	}

}
