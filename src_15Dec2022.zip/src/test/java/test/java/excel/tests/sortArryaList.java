package test.java.excel.tests;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class sortArryaList {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
	

		List<Integer> l = new ArrayList<>();

        l.add(222);
        l.add(100);
        l.add(45);
        l.add(415);
        l.add(311);

        System.out.println(l.get(0));
}
}
	