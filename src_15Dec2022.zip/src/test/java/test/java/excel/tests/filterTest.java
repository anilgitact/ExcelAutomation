package test.java.excel.tests;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.*;
import org.apache.poi.xssf.usermodel.*;

import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTAutoFilter;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTFilterColumn;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTFilters;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTCustomFilters;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.CTCustomFilter;
import org.openxmlformats.schemas.spreadsheetml.x2006.main.STFilterOperator;

import com.excel.lib.util.Xls_Reader;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

class filterTest {

	
 static	String receivedROVWorkbookDate = "";
 static boolean firstWorkBook = true;
 static XSSFWorkbook workbook = null;
 static Sheet sheet1 = null;
 static FileOutputStream fileOut = null;
 static int existingheaderRowColumnCount =0;
 
 private static void setCriteriaFilter(XSSFSheet sheet, int colId, int firstRow, int lastRow, String[] criteria) throws Exception {
  CTAutoFilter ctAutoFilter = sheet.getCTWorksheet().getAutoFilter();
  CTFilterColumn ctFilterColumn = null;
  for (CTFilterColumn filterColumn : ctAutoFilter.getFilterColumnList()) {
   if (filterColumn.getColId() == colId) ctFilterColumn = filterColumn;
  }
  if (ctFilterColumn == null) ctFilterColumn = ctAutoFilter.addNewFilterColumn();
  ctFilterColumn.setColId(colId);
  if (ctFilterColumn.isSetFilters()) ctFilterColumn.unsetFilters();

  CTFilters ctFilters = ctFilterColumn.addNewFilters();
  for (int i = 0; i < criteria.length; i++) {
   ctFilters.addNewFilter().setVal(criteria[i]);
  }

  //hiding the rows not matching the criterias
  DataFormatter dataformatter = new DataFormatter();
  for (int r = firstRow; r <= lastRow; r++) {
   XSSFRow row = sheet.getRow(r);
   boolean hidden = true;
   for (int i = 0; i < criteria.length; i++) {
    String cellValue = dataformatter.formatCellValue(row.getCell(colId));
    if (criteria[i].equals(cellValue)) hidden = false;
   }
   if (hidden) {
    row.getCTRow().setHidden(hidden);
   } else {
    if (row.getCTRow().getHidden()) row.getCTRow().unsetHidden();
   }
  }
 }

 public static void main(String[] args) throws Exception {

	 
		File directoryPath = new File("./resources/process/");
		// List of all files and directories
		String fileNames[] = directoryPath.list();
		//createRosterSheet();
	//Create an object of File class to open xlsx file
		
		FileReader propertiesReader = new FileReader("./resources/cvsReportsProperties.properties");
		Properties p = new Properties();
		p.load(propertiesReader);
		String firstReportWorkBook = p.getProperty("firstReportWorkBook");
		
		if(p.getProperty("lastProcessedFileDate").isEmpty())
		{
			File file =    new File("./resources/summaryDetails/SummaryDetails_"+fileNames[0].split("_")[1].replaceAll("-", "").replaceAll(" ", "")+".xlsx");
	    //file.createNewFile();
	      workbook = new XSSFWorkbook();
		 sheet1 = workbook.createSheet("Employees Per SVP");
	   
		}
		else
			
		{
		String lastProcessedFileDate= CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("lastProcessedFileDate");
		File file =    new File("./resources/summaryDetails/SummaryDetails_"+lastProcessedFileDate.replaceAll(" ", "")+".xlsx");
		    //Create an object of FileInputStream class to read excel file
		//file.createNewFile();
	 
		 FileInputStream fis = new FileInputStream(file);

		 workbook = new XSSFWorkbook(fis);
		 sheet1 = workbook.getSheet("Employees Per SVP");
		 FileOutputStream fileOut = null;
		
		}
  Xls_Reader reader = new Xls_Reader("./resources/digitalRosters/digitalRoster_"+fileNames[0].split("_")[1].replaceAll("-", "")+".xlsx");
  XSSFWorkbook wb = new XSSFWorkbook(new File("./resources/digitalRosters/digitalRoster_"+fileNames[0].split("_")[1].replaceAll("-", "")+".xlsx"));
	String sheetName = "Digital Roster Extract";

	
	Set<String> hash_Set = new HashSet<String>();
	
	for(int rowNum=2; rowNum<=wb.getSheet("Digital Roster Extract").getLastRowNum(); rowNum++){
		String svpNames = reader.getCellData(sheetName, "SVP", rowNum);

		hash_Set.add(svpNames);
	}
	 for (int c = 0; c < 28; c++) wb.getSheet("Digital Roster Extract").autoSizeColumn(c);
	 int svpCount=0;
	 for (String svpValue : hash_Set)
	 {
	
		 
		 wb = new XSSFWorkbook(new File("./resources/digitalRosters/digitalRoster_"+fileNames[0].split("_")[1].replaceAll("-", "")+".xlsx"));
		 XSSFSheet sheet = wb.getSheet("Digital Roster Extract");
  //create rows of data
  //setCellData(sheet)
		 //wb.createSheet(svpValue);
 

  int lastRow = sheet.getLastRowNum();
  XSSFAutoFilter autofilter = sheet.setAutoFilter(new CellRangeAddress(0, lastRow, 0, 28));
  //XSSFAutoFilter is useless until now

  //set filter criteria 
  setCriteriaFilter(sheet, 18, 1, lastRow, new String[]{svpValue});

  //get only visible rows after filtering
  XSSFRow row = null;
  for (int r = 1; r <= lastRow; r++) {
   row = sheet.getRow(r);
   if (row.getCTRow().getHidden()) continue;
			
			 /* for (int c = 0; c < 3; c++) { 
				  System.out.print(row.getCell(c) + "\t"); 
				  }*/
			 
   System.out.println();
  }
	 
  FileOutputStream finalout = new FileOutputStream("./resources/digitalRosters/filteredRoster_"+svpValue+".xlsx");
  wb.write(finalout);
  finalout.close();
  wb.close();
  
  
  
	String TargetSheetPathAndName = "./resources/digitalRosters/filteredRoster_"+svpValue+".xlsx";

String NewSheetPathAndName = "./resources/digitalRosters/FinalRoster_"+svpValue+".xlsx";

if (TargetSheetPathAndName != null && !"".equals(TargetSheetPathAndName.trim())) {

try {

File targetFile = new File(TargetSheetPathAndName.trim());

FileInputStream inputStream = new FileInputStream(targetFile);

XSSFWorkbook inputWorkbook = new XSSFWorkbook(inputStream);

int targetSheetCount = inputWorkbook.getNumberOfSheets();

System.out.println("Total no. of sheet(s) in the Target Workbook: " + targetSheetCount);

File outputFile = new File(NewSheetPathAndName.trim());

FileOutputStream outputStream = new FileOutputStream(outputFile);

XSSFWorkbook outputWorkbook = new XSSFWorkbook();

//Step #2 : Creating sheets with the same name as appearing in target workbook.

for (int i = 0; i < targetSheetCount; i++) {

XSSFSheet targetSheet = inputWorkbook.getSheetAt(i);

String inputSheetName = inputWorkbook.getSheetName(i);
if(inputSheetName.equals("Digital Roster Extract"))
{

XSSFSheet outputSheet = outputWorkbook.createSheet(inputSheetName);


CopyFilteredExcel.copyExcelWB(targetSheet, outputSheet);
}

}

//Step #4 : Write all the sheets in the new Workbook using FileOutStream Object (Step 3 is mentioned below)

outputWorkbook.write(outputStream);
outputStream.close();
outputWorkbook.close();

//File directoryPath = new File("./resources/process");
//String fileNames[] = directoryPath.list();
String mainROVFileName = "./resources/process/"+fileNames[0];
receivedROVWorkbookDate = mainROVFileName.split(".xlsx")[0].split("_")[1].replaceAll("-", "");
if(!p.getProperty("lastProcessedFileDate").isEmpty())
{
	
	File file =    new File("./resources/summaryDetails/SummaryDetails_"+fileNames[0].split("_")[1].replaceAll("-", "").replaceAll(" ", "")+".xlsx");
	if(file.exists())
	{
    //Create an object of FileInputStream class to read excel file
//file.createNewFile();

 FileInputStream fis = new FileInputStream(file);

 workbook = new XSSFWorkbook(fis);
 XSSFSheet summarySheet = workbook.getSheet("Employees Per SVP");
Row existingheaderRow = sheet1.getRow(0);
existingheaderRowColumnCount = existingheaderRow.getPhysicalNumberOfCells();
	}
	else
	{
		File file1 =    new File("./resources/summaryDetails/SummaryDetails_"+p.getProperty("lastProcessedFileDate").replaceAll(" ", "")+".xlsx");
	    //Create an object of FileInputStream class to read excel file
	//file.createNewFile();
 
	 FileInputStream fis1 = new FileInputStream(file1);

	 workbook = new XSSFWorkbook(fis1);
	 sheet1 = workbook.getSheet("Employees Per SVP");
	 existingheaderRowColumnCount = sheet1.getRow(0).getPhysicalNumberOfCells();
	}
}
else
{
	existingheaderRowColumnCount=0;
}
System.out.println("existingheaderRowColumnCount: "+existingheaderRowColumnCount);
CVSEmployessPerSVP.createSummaryView(svpValue, workbook, sheet1,receivedROVWorkbookDate , existingheaderRowColumnCount, firstReportWorkBook, svpCount);
svpCount++;
CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("lastProcessedFileDate",fileNames[0].split("_")[1].replaceAll("-", ""));

}

catch (Exception ex) {

System.out.println("Please check the target sheet given path and name: " + TargetSheetPathAndName);

System.out.println();

ex.printStackTrace();

}

//Write the output to a file



fileOut = new FileOutputStream(".\\resources\\summaryDetails\\SummaryDetails_"+receivedROVWorkbookDate+".xlsx");
workbook.write(fileOut);



}
}
	 
	 fileOut.close();

	// Closing the workbook
	workbook.close();
	
}
 
 
 
 
}