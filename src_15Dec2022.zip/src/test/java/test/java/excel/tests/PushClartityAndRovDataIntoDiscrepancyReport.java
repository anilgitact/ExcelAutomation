package test.java.excel.tests;


/**
 *  code that pushes data to DB table after comparing clarity data vs ROV data
 *
 * @author Anil
 *
 */

import java.io.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.ss.usermodel.CellType;

import main.java.commonUtilityFunctions;

public class PushClartityAndRovDataIntoDiscrepancyReport {
 
	
	
	static String createClarityVsROVsTableQuery="";
	static String insertQuery ="";
	static int count = 0;
    public static void main(String[] args) {
    	
    }
    //empid, empNameInRov, employeeFullNameInClarity, managerNameInRov, employeeManagerFullNameInClarity, RovDate, lastDateInClarity, employeeStatus
    @SuppressWarnings("null")
	public static void pushClarityVsROVsDataToDB(String empid, String empNameInRov, String employeeFullNameInClarity, String employeeManagerNameInRov, String employeeManagerFullNameInClarity, String RovDate, String lastDateInClarity, String employeeStatus, Connection connection) throws IOException
	{
		
    	 int batchSize = 20;
    	 Statement st3 = null;
         ResultSet resultSet = null;
    			
 
        try {
 
       
            //st3.execute("truncate  public.ClarityVsROVsExtract");
           
            if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
	         {
       	   insertQuery = "INSERT INTO ClarityVsROVsExtract (PSEMPLOYEEID,EMPLOYEENAMEINROV, EMPLOYEENAMEINCLARITY, EMPMANAGERINROV, EMPMANAGERINCLARITY, ROVDATE ,CLARITYLASTPAYMENTDATE , EMPLOYEESTATUS) VALUES (?, ?, ?,?, ?, ?,?, ?)";
	         }
           

            PreparedStatement statement = connection.prepareStatement(insertQuery);
 
               
                for(int j=0;j<8;j++)
                {
                
                
                switch (j) {
                
                case 0:
                	
                    statement.setString(1, empid);
                     
                    break;
                case 1:
                	
                    statement.setString(2, empNameInRov);
                     
                    break;
                case 2:
                	
                    statement.setString(3, employeeFullNameInClarity);
                    
                    break;
                case 3:
                	
                    statement.setString(4, employeeManagerNameInRov);
                    
                    break;
                case 4:
                	
                    statement.setString(5, employeeManagerFullNameInClarity);
                    
                    break;
                case 5:
                	
                    statement.setString(6, RovDate);
                    
                    break;
                case 6:
                	
                    statement.setString(7, lastDateInClarity);
                    
                    break;
                case 7:
                	
                    statement.setString(8, employeeStatus);
                    
                    break;
               
                
                                                      
                }
                
                }
                statement.addBatch();
 
                if (count % batchSize == 0) {
                    statement.executeBatch();
                }
 
            System.out.println("data from csv/excel ingested into database");
 
            // execute the remaining queries
            statement.executeBatch();
 
            connection.commit();
            
 
        } catch (IOException ex) {
            System.err.println(ex);
        } catch (SQLException ex) {
            ex.printStackTrace();
 
            try {
                connection.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
 
 
}
 }

