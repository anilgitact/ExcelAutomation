package test.java.excel.tests;

import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import org.testng.annotations.Test;

import main.java.commonUtilityFunctions;

public class CVSPushRosterToDBAndFindDiffAndAttrition {
	

	
	static ArrayList<String> TrainRosterExtractTableNameDates = new ArrayList<String>();
	static ArrayList<String> DigitalRosterExtractTableNameDates = new ArrayList<String>();
	static Connection connection = null;
	static String[] fileNames = null;
	static String NewSheetPathAndName ="";
	static String excelFilePath ="";
	static String createTableQuery="";
	static ArrayList<String> listofTable = null;
	static boolean digitalrosterextractdiffTable_flag=false;
	static ArrayList<String> listofDigitalExtractTable = null;
	static ArrayList<String> listofTrainRosterTable = null;	

	

	@Test(priority = 1)
	public static void createRosterSheet() throws IOException {
		
		File directoryPath = new File("./resources/process");
		String fileNames[] = directoryPath.list();
		String TargetSheetPathAndName = "./resources/process/"+fileNames[0];

		// String TargetSheetPathAndName = "./resources/sheetWithEmptyColumnData.xlsx";
        if(getPropertyValueFromPropertyFile("RosterExtractName").contains("TrainRosterExtract"))
        {
		 NewSheetPathAndName = "./resources/trainRosters/trainRoster_"+fileNames[0].split("_")[1]+".xlsx";
        }
        else
        	 if(getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
             {
     		 NewSheetPathAndName = "./resources/DigitalRosters/digitalRoster_"+fileNames[0].split("_")[1].replaceAll("-", "")+".xlsx";
             }	
		if (TargetSheetPathAndName != null && !"".equals(TargetSheetPathAndName.trim())) {

			try {

				File targetFile = new File(TargetSheetPathAndName.trim());

				FileInputStream inputStream = new FileInputStream(targetFile);

				XSSFWorkbook inputWorkbook = new XSSFWorkbook(inputStream);

				int targetSheetCount = inputWorkbook.getNumberOfSheets();

				System.out.println("Total no. of sheet(s) in the Target Workbook: " + targetSheetCount);

				File outputFile = new File(NewSheetPathAndName.trim());

				FileOutputStream outputStream = new FileOutputStream(outputFile);

				XSSFWorkbook outputWorkbook = new XSSFWorkbook();

              // Step #2 : Creating sheets with the same name as appearing in target workbook.

				for (int i = 0; i < targetSheetCount; i++) {

					XSSFSheet targetSheet = inputWorkbook.getSheetAt(i);

					String inputSheetName = inputWorkbook.getSheetName(i);
					if (inputSheetName.equals("Train Roster Extract") && getPropertyValueFromPropertyFile("RosterExtractName").contains("TrainRosterExtract"))
			         {

						XSSFSheet outputSheet = outputWorkbook.createSheet(inputSheetName);

						copyExcelWB(targetSheet, outputSheet);
					}
					if (inputSheetName.equals("Digital Roster Extract") && getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
			         {

						XSSFSheet outputSheet = outputWorkbook.createSheet(inputSheetName);

						
						copyExcelWB(targetSheet, outputSheet);
					}

				}

// Step #4 : Write all the sheets in the new Workbook using FileOutStream Object

				outputWorkbook.write(outputStream);

				outputStream.close();

			}

			catch (Exception ex) {

				System.out.println("Please check the target sheet given path and name: " + TargetSheetPathAndName);

				System.out.println();

				ex.printStackTrace();

			}
		}
	}
	
	
	
	@Test(priority = 2)

	public static void PushRosterDataToDBAndFindDiff(Connection connection) throws IOException, ParseException {

// Step #1 : Locate path and file name of target and output excel.
		
		/*// variables
		connection = null;
		// Statement statement = null;
		ResultSet resultSet = null;
		  String user = "postgres";
		    String password = "postgres"; */
		/*
		 * // Step 1: Loading or registering Oracle JDBC driver class try {
		 * 
		 * Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); } catch
		 * (ClassNotFoundException cnfex) {
		 * 
		 * System.out.println("Problem in loading or " +
		 * "registering MS Access JDBC driver"); cnfex.printStackTrace(); }
		 */
		// Step 2: Opening database connection
		try {

			/*
			 * String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
			 * String dbURL = "jdbc:ucanaccess://" + msAccDB;
			 * 
			 * // Step 2.A: Create and get connection using DriverManager class connection =
			 * DriverManager.getConnection(dbURL);
			 */

			//Connection connection = commonUtilityFunctions.connectToPostgresDB(user,password);
			// Step 2.B: Creating JDBC Statement
			// statement = connection.createStatement();
			//long start = System.currentTimeMillis();

		

			File directoryPath = new File("./resources/process/");
			// List of all files and directories
			fileNames = directoryPath.list();
			//createRosterSheet();
			//ArrayList<String> TrainRosterExtractTableNames = new ArrayList<String>();
			
			
			listofTable = new ArrayList<String>();

			/*
			 * DatabaseMetaData md = connection.getMetaData();
			 * 
			 * ResultSet rs1 = md.getTables(null, null, "%", null); while (rs1.next()) { if
			 * (rs1.getString(2).equalsIgnoreCase("TABLE")) {
			 * listofTable.add(rs1.getString(3)); } }
			 */
			
			DatabaseMetaData dbmd = connection.getMetaData();
			try (ResultSet tables = dbmd.getTables(null, null, "%", new String[] { "TABLE" })) {
			    while (tables.next()) {
			    	listofTable.add(tables.getString("TABLE_NAME"));
			        System.out.println(tables.getString("TABLE_NAME"));
			    }
			}
			 if(getPropertyValueFromPropertyFile("RosterExtractName").contains("TrainRosterExtract"))
		        {
			for (int k = 0; k < listofTable.size(); k++) {

				if (listofTable.get(k).contains("TrainRosterExtract_")) {
					TrainRosterExtractTableNameDates.add(listofTable.get(k).split("_")[1]);

				}
			}

			// sort the table names
            if(!TrainRosterExtractTableNameDates.isEmpty())
            {
			Collections.sort(TrainRosterExtractTableNameDates, Collections.reverseOrder());
			//System.out.println(TrainRosterExtractTableNameDates.get(0).substring(0,2)+"-"+TrainRosterExtractTableNameDates.get(0).substring(2,4)+"-"+TrainRosterExtractTableNameDates.get(0).substring(4,8));
			// comapre the new ROV file date is after the date of the last pushed to DB ROV
			// file
			
			
			if (fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "").contains(TrainRosterExtractTableNameDates.get(0))) 
			{
                 System.out.println("The new file data already exists in DB and had been processed");
			} 
			
			else 
			
			{
				if (new SimpleDateFormat("MM/dd/yyyy").parse(fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "/"))
						.after(new SimpleDateFormat("MM/dd/yyyy").parse(TrainRosterExtractTableNameDates.get(0).substring(0,2)+"/"+TrainRosterExtractTableNameDates.get(0).substring(2,4)+"/"+TrainRosterExtractTableNameDates.get(0).substring(4,8)))) 
				
				{
					// push the data to DB with file date
					CVSRosterExcel2DatabaseTest.pushDataToDB(
							fileNames[0].split(".xlsx")[0].split("_")[1].toString());
					//CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
				}
				
			}
			}
            
            else
				if(TrainRosterExtractTableNameDates.isEmpty())
				{
					// push the data to DB with file date
					CVSRosterExcel2DatabaseTest.pushDataToDB(
							fileNames[0].split(".xlsx")[0].split("_")[1].toString());
					//CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
				}
		}
			 else
				 if(getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
			        {
				for (int k = 0; k < listofTable.size(); k++) {

					if (listofTable.get(k).contains("digitalrosterextract_")) {
						DigitalRosterExtractTableNameDates.add(listofTable.get(k).split("_")[1]);

					}
				}

				// sort the table names
	            if(!DigitalRosterExtractTableNameDates.isEmpty())
	            {
				Collections.sort(DigitalRosterExtractTableNameDates, Collections.reverseOrder());
				//System.out.println(DigitalRosterExtractTableNameDates.get(0).substring(0,2)+"-"+DigitalRosterExtractTableNameDates.get(0).substring(2,4)+"-"+DigitalRosterExtractTableNameDates.get(0).substring(4,8));
				// comapre the new ROV file date is after the date of the last pushed to DB ROV
				// file
				
				
				if (fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "").contains(DigitalRosterExtractTableNameDates.get(0))) 
				{
	                 System.out.println("The new file data already exists in DB and had been processed");
				} 
				
				else 
				
				{
					if (new SimpleDateFormat("MM/dd/yyyy").parse(fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "/"))
							.after(new SimpleDateFormat("MM/dd/yyyy").parse(DigitalRosterExtractTableNameDates.get(0).substring(0,2)+"/"+DigitalRosterExtractTableNameDates.get(0).substring(2,4)+"/"+DigitalRosterExtractTableNameDates.get(0).substring(4,8)))) 
					
					{
						// push the data to DB with file date
						CVSRosterExcel2DatabaseTest.pushDataToDB(
								fileNames[0].split(".xlsx")[0].split("_")[1].toString());
						//CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
					}
					
				}
				}
	            
	            else
					if(DigitalRosterExtractTableNameDates.isEmpty())
					{
						// push the data to DB with file date
						CVSRosterExcel2DatabaseTest.pushDataToDB(
								fileNames[0].split(".xlsx")[0].split("_")[1].toString());
						//CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
					}
			 
			        }
		} catch (Exception ex) {

			System.out.println("Some issues while pushing data to DB");

			System.out.println();

			ex.printStackTrace();

		}

	}


	public static void copyExcelWB(XSSFSheet targetSheet, XSSFSheet outputSheet) {
		DataFormatter formatter = new DataFormatter();
		int rowCount = targetSheet.getLastRowNum();

		System.out.println("There are " + rowCount + " rows in the Target workbook with sheet name -" + "'"
				+ targetSheet.getSheetName() + "‘");

		int currentRowIndex = 0;
		//System.out.println(targetSheet.getPhysicalNumberOfRows());
		for (int i = 0; i < targetSheet.getPhysicalNumberOfRows(); i++) {
			final Row row = targetSheet.getRow(i);
			//if (!row.getZeroHeight()) {
// while (rowIterator.hasNext()) {

				int currentCellIndex = 0;

				for (int j = 0; j < row.getPhysicalNumberOfCells(); j++) {
					final Cell cell = row.getCell(j);

// Step #3: Creating new Row, Cell and Input value in the newly created sheet.

///String cellData = cell.getStringCellValue();

					String cellData = formatter.formatCellValue(cell).toString();
					if (currentCellIndex == 0)

						outputSheet.createRow(currentRowIndex).createCell(currentCellIndex).setCellValue(cellData);

					else

					if (cellData.isEmpty()) {
						outputSheet.getRow(currentRowIndex).createCell(currentCellIndex).setCellValue(" ");

					} else {

						outputSheet.getRow(currentRowIndex).createCell(currentCellIndex).setCellValue(cellData);
					}

					currentCellIndex++;

				}
				currentRowIndex++;

			//}
		}

		//System.out.println("Total " + (currentRowIndex - 1) + " rows are Copied in the new Workbook with sheet name- "
		//		+ "'" + outputSheet.getSheetName() + "'");

	}

	
	
	@Test (priority = 3)
	public static void compareAndFindAttritionAgainstExistingRosterTable(Connection connection) throws IOException, SQLException {
		
		/*String user = "postgres";
		 String password = "postgres";
		 Connection connection = commonUtilityFunctions.connectToPostgresDB(user,password);*/
		 
		if(!DigitalRosterExtractTableNameDates.isEmpty())
		{
		//CVSTrainRosterExcel2DatabaseTest.main();
		
			//select * from  DigitalRosterExtract_07132022 WHERE  ColleagueID NOT IN (SELECT ColleagueID FROM DigitalRosterExtract_07202022)
		String DigitalRosterExtractVsExistingDigitalRosterExtractAttritionQuery = getPropertyValueFromPropertyFile("DigitalRosterExtractVsExistingDigitalRosterExtractAttritionQuery");
		String digitalRosterAttritionTableName = getPropertyValueFromPropertyFile("digitalRosterAttritionTableName");
		String RosterExtractName = getPropertyValueFromPropertyFile("RosterExtractName");
		
			if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
 	         {
				
				String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
				if(firstReportWorkBook.contains("true"))
				{
					System.out.println("Since this is the first sheet - there are no leavers");
				}
				else
				{
				CalculateWeeklyAttrition(DigitalRosterExtractVsExistingDigitalRosterExtractAttritionQuery,
						digitalRosterAttritionTableName,DigitalRosterExtractTableNameDates.get(0), fileNames[0].split(".xlsx")[0].split("_")[1].toString().replaceAll("-", ""), RosterExtractName, connection);
				}
				}
		}
		
		else
		{
			String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
			if(firstReportWorkBook.contains("true"))
			{
				System.out.println("Since this is the first sheet - there are no leavers");
			}
			
		}
	}
	
	
	
	public static void CalculateWeeklyAttrition(String weeklyAttritionQuery,String digitalRosterAttritionTableName, String existingDBTable, String newTableName, String rosterExtractName, Connection connection) throws SQLException, IOException
	{
		
		 
			
		 if(newTableName.contains("08072022"))
		 {
			 System.out.println("we are at 0807 rov");
		 }
		weeklyAttritionQuery = weeklyAttritionQuery.replaceAll("existingTable",rosterExtractName+"_"+existingDBTable);		       
		weeklyAttritionQuery = weeklyAttritionQuery.replaceAll("newlyCreatedTable",rosterExtractName+"_"+newTableName);
		ResultSet rs_forcount = connection.createStatement().executeQuery(weeklyAttritionQuery);
		int record_count = 0;
		while(rs_forcount.next())
		{
			record_count++;
		}
		rs_forcount.close();
		System.out.println("total record count ****************"+record_count);
		ResultSet rs = connection.createStatement().executeQuery(weeklyAttritionQuery);
		
		String createAttritionTableQuery =  getPropertyValueFromPropertyFile("createAttritionTableQuery");
		createNewTableInDB(fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", ""), createAttritionTableQuery, connection);
		ResultSet cocoExactMatchResultSet = null;
		ResultSet cocoNearMatcgResultSet = null;
	
		
        //String createDiffTableQuery= CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("createDigitalExtractDiffTableQuery");
        //   ResultSet rs3 = null;
        try { 
		
        	int count =0;
        	
        	 
        	
     	    while(rs.next())
     	    {
     	    	count++;
     	    	System.out.println("current record count ***********************************************************"+count);
     	    	if(newTableName.contains("0807") && count ==70)
     	    	{
     	    		System.out.println(" record approaching");
     	    	}
     	    	if(rs.getString(5).contains("KhanB")||rs.getString(5).contains("khanb")||rs.getString(5).contains("Khanb"))
     	    	{
     	    		System.out.println("khan bilal found in "+newTableName);
     	    		
     	    		
     	    	}
     	    	
     	    	if(rs.getString(2).contains("Contractor"))
     	    	{
     	    	System.out.println("emailaddress"+rs.getString(5));
     	    	String COCOQueryExactMatch = getPropertyValueFromPropertyFile("COCOQueryExactMatch");
     	    	
     	    	COCOQueryExactMatch = COCOQueryExactMatch.replaceAll("newlyCreatedTable",rosterExtractName+"_"+newTableName);
     	    	COCOQueryExactMatch = COCOQueryExactMatch.replaceAll("emailaddressvalue", rs.getString(5));
     	    	COCOQueryExactMatch = COCOQueryExactMatch.replaceAll("colleaguenamevalue", rs.getString(4));
    			COCOQueryExactMatch = COCOQueryExactMatch.replaceAll("locationvalue", rs.getString(12));
    			COCOQueryExactMatch = COCOQueryExactMatch.replaceAll("svpvalue", rs.getString(20));
    			COCOQueryExactMatch = COCOQueryExactMatch.replaceAll("managernamevalue", rs.getString(13));
    			COCOQueryExactMatch = COCOQueryExactMatch.replaceAll("seniorleadervalue", rs.getString(19));
    			COCOQueryExactMatch = COCOQueryExactMatch.replaceAll("supervisor6value", rs.getString(18));
		        	
    			
    		    cocoExactMatchResultSet = connection.createStatement().executeQuery(COCOQueryExactMatch);
    			
    			cocoExactMatchResultSet.next();
    			System.out.println(cocoExactMatchResultSet.getInt(1));
	    		//Statement st = connection.createStatement();
    			if(cocoExactMatchResultSet.getInt(1)==1)
    			{
    				
    				String matchType = "exact match";
    				
    	    		
    	    		String insertIntoCOCOTableQuery = "insert into public.cocoemployees values ('"+rs.getString(2)+"','"+rs.getString(3).replaceAll("'", "")+"','"+rs.getString(4).replaceAll("'", "")+"','"+rs.getString(5)+"','"+rs.getString(6)+"','"+rs.getString(7)+"','"+rs.getString(8)+"','"+rs.getString(9)+"','"+rs.getString(10)+"','"+rs.getString(11)+"','"+rs.getString(12).replaceAll("'", "")+"','"+rs.getString(13).replaceAll("'", "")+"','"+rs.getString(14).replaceAll("'", "")+"','"+rs.getString(15).replaceAll("'", "")+"','"+rs.getString(16).replaceAll("'", "")+"','"+rs.getString(17).replaceAll("'", "")+"','"+rs.getString(18).replaceAll("'", "")+"','"+rs.getString(19).replaceAll("'", "")+"','"+rs.getString(20)+"','"+rs.getString(21)+"','"+rs.getString(22)+"','"+rs.getString(23)+"','"+rs.getString(24).replaceAll("'", "")+"','"+rs.getString(25).replaceAll("'", "")+"','"+rs.getString(26)+"','"+rs.getString(27)+"','"+newTableName+"','"+matchType+"')";
    	    		
    	    		
    	    		
    	    		connection.createStatement().execute(insertIntoCOCOTableQuery);
    	    		matchType = "";
    				
    			}
    			else
    			{
    				String COCONearMatchQuery = getPropertyValueFromPropertyFile("COCONearMatchQuery");
         	    	
    				COCONearMatchQuery= COCONearMatchQuery.replaceAll("newlyCreatedTable",rosterExtractName+"_"+newTableName);
    				COCONearMatchQuery = COCONearMatchQuery.replaceAll("emailaddressvalue", rs.getString(5).split("@")[0].replaceAll(" ",""));
    				COCONearMatchQuery = COCONearMatchQuery.replaceAll("colleaguenamevalue", rs.getString(4).replaceAll(" ",""));
    				COCONearMatchQuery = COCONearMatchQuery.replaceAll("locationvalue", rs.getString(12));
    				COCONearMatchQuery = COCONearMatchQuery.replaceAll("svpvalue", rs.getString(20));
        			COCONearMatchQuery = COCONearMatchQuery.replaceAll("managernamevalue", rs.getString(13));
        			COCONearMatchQuery = COCONearMatchQuery.replaceAll("seniorleadervalue", rs.getString(19));
    		        	
        			
        		    cocoNearMatcgResultSet = connection.createStatement().executeQuery(COCONearMatchQuery);
        			
        			cocoNearMatcgResultSet.next();
        			System.out.println(cocoNearMatcgResultSet.getInt(1));
    	    		//Statement st = connection.createStatement();
        			if(cocoNearMatcgResultSet.getInt(1)==1)
        			{
        				
        				String matchType = "near match";
        				
        	    		
        	    		String insertIntoCOCOTableQuery = "insert into public.cocoemployees values ('"+rs.getString(2)+"','"+rs.getString(3).replaceAll("'", "")+"','"+rs.getString(4).replaceAll("'", "")+"','"+rs.getString(5)+"','"+rs.getString(6)+"','"+rs.getString(7)+"','"+rs.getString(8)+"','"+rs.getString(9)+"','"+rs.getString(10)+"','"+rs.getString(11)+"','"+rs.getString(12).replaceAll("'", "")+"','"+rs.getString(13).replaceAll("'", "")+"','"+rs.getString(14).replaceAll("'", "")+"','"+rs.getString(15).replaceAll("'", "")+"','"+rs.getString(16).replaceAll("'", "")+"','"+rs.getString(17).replaceAll("'", "")+"','"+rs.getString(18).replaceAll("'", "")+"','"+rs.getString(19).replaceAll("'", "")+"','"+rs.getString(20)+"','"+rs.getString(21)+"','"+rs.getString(22)+"','"+rs.getString(23)+"','"+rs.getString(24).replaceAll("'", "")+"','"+rs.getString(25).replaceAll("'", "")+"','"+rs.getString(26)+"','"+rs.getString(27)+"','"+newTableName+"','"+matchType+"')";
        	    		connection.createStatement().execute(insertIntoCOCOTableQuery);	
        	    		matchType = "";
        				
        			}
    			}
    			
    			
    				if(cocoExactMatchResultSet.getInt(1)==0 || cocoNearMatcgResultSet.getInt(1)==0)
    				
        			{
    				 if(newTableName.contains("08072022"))
    				 {
    					 System.out.println("we are at 0807 rov");
    				 }
    				
    				String insertIntoAttirtionTableQuery = "insert into "+digitalRosterAttritionTableName.trim()+"_"+newTableName+" values ('"+rs.getString(1)+"','"+rs.getString(2)+"','"+rs.getString(3).replaceAll("'", "")+"','"+rs.getString(4).replaceAll("'", "")+"','"+rs.getString(5)+"','"+rs.getString(6)+"','"+rs.getString(7)+"','"+rs.getString(8)+"','"+rs.getString(9)+"','"+rs.getString(10)+"','"+rs.getString(11)+"','"+rs.getString(12).replaceAll("'", "")+"','"+rs.getString(13).replaceAll("'", "")+"','"+rs.getString(14).replaceAll("'", "")+"','"+rs.getString(15).replaceAll("'", "")+"','"+rs.getString(16).replaceAll("'", "")+"','"+rs.getString(17).replaceAll("'", "")+"','"+rs.getString(18).replaceAll("'", "")+"','"+rs.getString(19).replaceAll("'", "")+"','"+rs.getString(20)+"','"+rs.getString(21)+"','"+rs.getString(22)+"','"+rs.getString(23)+"','"+rs.getString(24).replaceAll("'", "")+"','"+rs.getString(25).replaceAll("'", "")+"','"+rs.getString(26)+"')" ;
    				System.out.println("insertIntoAttirtionTableQuery:"+insertIntoAttirtionTableQuery);
    				connection.createStatement().execute(insertIntoAttirtionTableQuery);
    				//PushRecordSetToExcel(insertIntoAttirtionTableQuery,"Attrition_"+newTableName,connection,"Leavers");
    			}
     	    } 		
     	    	else
     	    	{
     	    		String insertIntoAttirtionTableQuery = "insert into "+digitalRosterAttritionTableName.trim()+"_"+newTableName+" values ('"+rs.getString(1)+"','"+rs.getString(2)+"','"+rs.getString(3).replaceAll("'", "")+"','"+rs.getString(4).replaceAll("'", "")+"','"+rs.getString(5)+"','"+rs.getString(6)+"','"+rs.getString(7)+"','"+rs.getString(8)+"','"+rs.getString(9)+"','"+rs.getString(10)+"','"+rs.getString(11)+"','"+rs.getString(12).replaceAll("'", "")+"','"+rs.getString(13).replaceAll("'", "")+"','"+rs.getString(14).replaceAll("'", "")+"','"+rs.getString(15).replaceAll("'", "")+"','"+rs.getString(16).replaceAll("'", "")+"','"+rs.getString(17).replaceAll("'", "")+"','"+rs.getString(18).replaceAll("'", "")+"','"+rs.getString(19).replaceAll("'", "")+"','"+rs.getString(20)+"','"+rs.getString(21)+"','"+rs.getString(22)+"','"+rs.getString(23)+"','"+rs.getString(24).replaceAll("'", "")+"','"+rs.getString(25).replaceAll("'", "")+"','"+rs.getString(26)+"')" ;
    				System.out.println("insertIntoAttirtionTableQuery:"+insertIntoAttirtionTableQuery);
    				connection.createStatement().execute(insertIntoAttirtionTableQuery);
     	    	}
     	    }
     	    System.out.println("HeadCountColleagueIds for all records in SummaryViewData table  pushed to DB");
             //connection.close();
     	   } catch (Exception  ex) {
     	   
     	  if (ex.getMessage().contains("object not found:") || ex.getMessage().contains("does not exist"))
     			  {
     			  System.out.println("DIGITALROSTERATTRITION_mmddyyyy table not present in DB for  week "+rs.getString(8)+"-Hence DB-SummaryViewData table will have 0 values");
     			  }
     	  
     	 
            //Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
        }
		
		
		//CVSCompareDatabaseTablesTest.copyResultsetToTable(weeklyAttritionQuery, digitalRosterAttritionTableName.trim()+"_"+newTableName, connection, connection);
		
	}
	
	@Test (priority = 4)
	public static void compareAndFindJoinersAgainstExistingRosterTable(Connection connection) throws IOException, SQLException {
		
		if(!DigitalRosterExtractTableNameDates.isEmpty())
		{
		//CVSTrainRosterExcel2DatabaseTest.main();
		
		String DigitalRosterExtractVsExistingDigitalRosterExtractJoinersQuery = getPropertyValueFromPropertyFile("DigitalRosterExtractVsExistingDigitalRosterExtractJoinersQuery");
		String digitalRosterJoinersTableName = getPropertyValueFromPropertyFile("digitalRosterJoinersTableName");
		String RosterExtractName = getPropertyValueFromPropertyFile("RosterExtractName");
		
			if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
 	         {
				
				String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
				if(firstReportWorkBook.contains("true"))
				{
					System.out.println("Since this is the first sheet - there are no joiners");
				}
				else
				{
				
				CalculateWeeklyJoiners(DigitalRosterExtractVsExistingDigitalRosterExtractJoinersQuery,
						digitalRosterJoinersTableName,DigitalRosterExtractTableNameDates.get(0), fileNames[0].split(".xlsx")[0].split("_")[1].toString().replaceAll("-", ""), RosterExtractName,connection);
				}
				}
		}
		
		else
		{
			String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
			if(firstReportWorkBook.contains("true"))
			{
				System.out.println("Since this is the first sheet - there are no joiners");
			}
		}
	}
	
	
	
	
	public static void CalculateWeeklyJoiners(String weeklyJoinersQuery,String digitalRosterJoinersTableName, String existingDBTable, String newTableName, String rosterExtractName, Connection connection) throws SQLException, IOException
	{
		
		weeklyJoinersQuery = weeklyJoinersQuery.replaceAll("existingTable",rosterExtractName+"_"+existingDBTable);		       
		weeklyJoinersQuery = weeklyJoinersQuery.replaceAll("newlyCreatedTable",rosterExtractName+"_"+newTableName);
          
		System.out.println("weeklyJoinersQuery:"+weeklyJoinersQuery);
		ResultSet rs = connection.createStatement().executeQuery(weeklyJoinersQuery);
		String createJoinersTableQuery =  getPropertyValueFromPropertyFile("createJoinersTableQuery");
		createNewTableInDB(fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", ""), createJoinersTableQuery, connection);
		PushRecordSetToExcel(weeklyJoinersQuery,"Joiners_"+newTableName,connection, "Joiners");
		CVSCompareDatabaseTablesTest.copyResultsetToTable(weeklyJoinersQuery, digitalRosterJoinersTableName.trim()+"_"+newTableName, connection, connection);
		
	}
	
	@Test (priority = 5, enabled=true)
	public static void compareAndFindDiffAgainstExistingRosterTable() throws IOException, SQLException {
		
		
		
		String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
		if(!TrainRosterExtractTableNameDates.isEmpty() || !DigitalRosterExtractTableNameDates.isEmpty())
		{
		//CVSTrainRosterExcel2DatabaseTest.main();
		
		String TrainRosterExtractVsExistingTrainRosterExtractDiffQuery = getPropertyValueFromPropertyFile("TrainRosterExtractVsExistingTrainRosterExtractDiffQuery");
		String DigitalRosterExtractVsExistingDigitalRosterExtractDiffQuery = getPropertyValueFromPropertyFile("DigitalRosterExtractVsExistingDigitalRosterExtractDiffQuery");
		String trainRosterDiffTableName = getPropertyValueFromPropertyFile("trainRosterDiffTableName");
		String digitalRosterDiffTableName = getPropertyValueFromPropertyFile("DigitalRosterDiffTableName");
		String rosterExtractName = getPropertyValueFromPropertyFile("RosterExtractName");
		if (getPropertyValueFromPropertyFile("RosterExtractName").contains("TrainRosterExtract"))
	         {
		CVSCompareDatabaseTablesTest.CompareTablesAndFindDiff(TrainRosterExtractVsExistingTrainRosterExtractDiffQuery,
				trainRosterDiffTableName, TrainRosterExtractTableNameDates.get(0),fileNames[0].split(".xlsx")[0].split("_")[1].toString().replaceAll("-", ""),rosterExtractName);
	         }
		else
			if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
 	         {
				//create the diff table if not present
				for (int k = 0; k < listofTable.size(); k++) {

					if (listofTable.get(k).contains("digitalrosterextractdiff")) {
						digitalrosterextractdiffTable_flag = true;
						break;

					}
				}
				if(digitalrosterextractdiffTable_flag==false)
				{
					
					  String newFileDate = fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "");
					//create the diff table
					   if (connection != null) {
				           Statement st3 = null;
				           try {
				               st3 = (Statement) connection.createStatement();
				           } catch (SQLException ex) {
				               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
				           }
				           
				        
				           String createDiffTableQuery= CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("createDigitalExtractDiffTableQuery");
				        System.out.println("createDiffTableQuery:"+createDiffTableQuery);
				           //   ResultSet rs3 = null;
				           try { 
				                st3.execute(createDiffTableQuery);
				           } catch (SQLException ex) {
				               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
				           }
				       }
				       
				       
				        //resultSet = statement1.execute(createTableQuery);
				        connection.commit();
				        
				        //connection.close();
				}
				
				if(firstReportWorkBook.contains("true"))
				{
					System.out.println("This is the first file - so diff can be evaluated");
				}
				else
				{
				CVSCompareDatabaseTablesTest.CompareTablesAndFindDiff(DigitalRosterExtractVsExistingDigitalRosterExtractDiffQuery,
						digitalRosterDiffTableName, DigitalRosterExtractTableNameDates.get(0),fileNames[0].split(".xlsx")[0].split("_")[1].toString().replaceAll("-", ""),rosterExtractName);
				}
				}
				
		}
	}
	
	public static String getPropertyValueFromPropertyFile(String propertKey) throws IOException
	{
		FileReader reader = new FileReader("./resources/cvsReportsProperties.properties");
		Properties p = new Properties();
		p.load(reader);
		return p.getProperty(propertKey);
	}
	
	
	public static void setPropertyValueInPropertyFile(String propertyKey, String propertyValue) throws IOException
	{
		FileReader reader = new FileReader("./resources/cvsReportsProperties.properties");
		Properties p = new Properties();
		p.load(reader);
		p.getProperty(propertyKey);
		p.setProperty(propertyKey, propertyValue);
		  File file = new File("./resources/cvsReportsProperties.properties");
	        FileOutputStream fOut = new FileOutputStream(file);
	        p.store(fOut, "updated the properties file");
	        fOut.close();
	}
	
	public static void createNewTableInDB(String fileDate, String createTableQuery, Connection connection) throws IOException
	{
		
	int batchSize = 20;
	
	
	
	try
	{
	
        connection.setAutoCommit(false);
        
        
       PreparedStatement statement = null; 
       String newFileDate = fileDate.replaceAll("-", "");
       
       if (connection != null) {
           Statement st3 = null;
           try {
               st3 = (Statement) connection.createStatement();
           } catch (SQLException ex) {
               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
           }
           
        
           createTableQuery= createTableQuery.replace("newFileDate", newFileDate);
           //   ResultSet rs3 = null;
           try { 
                st3.execute(createTableQuery);
           } catch (SQLException ex) {
               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
           }
       }
       
       
        //resultSet = statement1.execute(createTableQuery);
        connection.commit();
        
        //connection.close();

	} catch (SQLException ex2) {
    System.out.println("Database error");
    ex2.printStackTrace();
}
}
	
	
	
	public static void PushRecordSetToExcel(String weeklyAttritionQuery,String AttritionJoinersNewTableName,Connection connection, String LeaversOrJoiners)
	{
		List<String> headerValues=new ArrayList<String>();
		
	    XSSFWorkbook workbook = new XSSFWorkbook();
	    try {

	    	XSSFSheet spreadsheet=null;
	    Statement statement = connection.createStatement();
	    if(AttritionJoinersNewTableName.contains("_"))
	    {
	    spreadsheet = workbook.createSheet(LeaversOrJoiners+"_"+AttritionJoinersNewTableName.split("_")[1].trim());
	    }
	    else
	    {
	    spreadsheet = workbook.createSheet(LeaversOrJoiners+"_"+AttritionJoinersNewTableName.trim());	
	    }
	    //PreparedStatement preparedStatement = connection.prepareStatement(weeklyAttritionQuery);  
	     ResultSet resultSet = statement.executeQuery(weeklyAttritionQuery);


	      XSSFRow row = spreadsheet.createRow(0);
	      XSSFCell cell;
	      int cc=resultSet.getMetaData().getColumnCount();
	      for(int i=1;i<=cc;i++)
	      {
	          String headerVal=resultSet.getMetaData().getColumnName(i);
	          headerValues.add(headerVal);
	          cell = row.createCell(i-1);
	          cell.setCellValue(resultSet.getMetaData().getColumnName(i));
	      }
	      System.out.println(headerValues);

	      int i = 1;
	      while (resultSet.next())
	      {  

	          XSSFRow row1 = spreadsheet.createRow((short) i);
	          for(int p=0;p<headerValues.size();p++)
	          {
	          row1.createCell(p).setCellValue(resultSet.getString(headerValues.get(p)).toString());
	          }
	          i++;
	      } 
	      FileOutputStream out =null;
	      if(LeaversOrJoiners=="Leavers")
	      {
	      out = new FileOutputStream(new File("./resources/Attrition/"+AttritionJoinersNewTableName+".xlsx"));
	      }
	      else
	      if(LeaversOrJoiners=="Joiners")
	      {
	      out = new FileOutputStream(new File("./resources/Joiners/"+AttritionJoinersNewTableName+".xlsx"));
	      }
	      else
	      {
	      out = new FileOutputStream(new File("./resources/SummaryDetails/MonthWiseSummaryReports/"+AttritionJoinersNewTableName+"_"+LeaversOrJoiners+".xlsx"));
	      }
	      workbook.write(out);
	      out.close();  
	      workbook.close();
	      System.out.println("Data from DB written successfully to excel");

	}catch(Exception e){
		 e.printStackTrace();
	}
	}
	
	
	
	@Test(priority = 7)

	public static void PushDigitalAndTrainRosterDataToDB() throws IOException, ParseException {

// Step #1 : Locate path and file name of target and output excel.
		
		// variables
		connection = null;
		// Statement statement = null;
		ResultSet resultSet = null;
		  String user = "postgres";
		    String password = "postgres";
		
		// Step 2: Opening database connection
		try {

			Connection connection = commonUtilityFunctions.connectToPostgresDB(user,password);
			long start = System.currentTimeMillis();

		

			File directoryPath = new File("./resources/process/");
			// List of all files and directories
			fileNames = directoryPath.list();
			listofTable = new ArrayList<String>();

			
			
			DatabaseMetaData dbmd = connection.getMetaData();
			try (ResultSet tables = dbmd.getTables(null, null, "%", new String[] { "TABLE" })) {
			    while (tables.next()) {
			    	listofTable.add(tables.getString("TABLE_NAME"));
			        System.out.println(tables.getString("TABLE_NAME"));
			    }
			}
			 if(getPropertyValueFromPropertyFile("RosterExtractName").contains("TrainRosterExtract"))
		        {
			for (int k = 0; k < listofTable.size(); k++) {

				if (listofTable.get(k).contains("TrainRosterExtract_")) {
					TrainRosterExtractTableNameDates.add(listofTable.get(k).split("_")[1]);

				}
			}

			// sort the table names
            if(!TrainRosterExtractTableNameDates.isEmpty())
            {
			Collections.sort(TrainRosterExtractTableNameDates, Collections.reverseOrder());
			//System.out.println(TrainRosterExtractTableNameDates.get(0).substring(0,2)+"-"+TrainRosterExtractTableNameDates.get(0).substring(2,4)+"-"+TrainRosterExtractTableNameDates.get(0).substring(4,8));
			// comapre the new ROV file date is after the date of the last pushed to DB ROV
			
			
			if (fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "").contains(TrainRosterExtractTableNameDates.get(0))) 
			{
                 System.out.println("The new file data already exists in DB and had been processed");
			} 
			
			else 
			
			{
				if (new SimpleDateFormat("MM/dd/yyyy").parse(fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "/"))
						.after(new SimpleDateFormat("MM/dd/yyyy").parse(TrainRosterExtractTableNameDates.get(0).substring(0,2)+"/"+TrainRosterExtractTableNameDates.get(0).substring(2,4)+"/"+TrainRosterExtractTableNameDates.get(0).substring(4,8)))) 
				
				{
					// push the data to DB with file date
					CVSRosterExcel2DatabaseTest.pushDataToDB(
							fileNames[0].split(".xlsx")[0].split("_")[1].toString());
					//CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
				}
				
			}
			}
            
            else
				if(TrainRosterExtractTableNameDates.isEmpty())
				{
					// push the data to DB with file date
					CVSRosterExcel2DatabaseTest.pushDataToDB(
							fileNames[0].split(".xlsx")[0].split("_")[1].toString());
					//CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
				}
		}
			 else
				 if(getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
			        {
					 for (int k = 0; k < listofDigitalExtractTable.size(); k++) {

							if (listofDigitalExtractTable.get(k).contains("digitalrosterextract_")) {
								DigitalRosterExtractTableNameDates.add(listofDigitalExtractTable.get(k).split("_")[1]);

							}
						}
						
						for (int k = 0; k < listofTrainRosterTable.size(); k++) {

							if (listofTrainRosterTable.get(k).contains("digitalrosterextract_")) {
								TrainRosterExtractTableNameDates.add(listofTrainRosterTable.get(k).split("_")[1]);

							}
						}


				// sort the table names
	            if(!DigitalRosterExtractTableNameDates.isEmpty())
	            {
				Collections.sort(DigitalRosterExtractTableNameDates, Collections.reverseOrder());
				//System.out.println(DigitalRosterExtractTableNameDates.get(0).substring(0,2)+"-"+DigitalRosterExtractTableNameDates.get(0).substring(2,4)+"-"+DigitalRosterExtractTableNameDates.get(0).substring(4,8));
				// comapre the new ROV file date is after the date of the last pushed to DB ROV
				// file
				
				
				if (fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "").contains(DigitalRosterExtractTableNameDates.get(0))) 
				{
	                 System.out.println("The new file data already exists in DB and had been processed");
				} 
				
				else 
				
				{
					if (new SimpleDateFormat("MM/dd/yyyy").parse(fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "/"))
							.after(new SimpleDateFormat("MM/dd/yyyy").parse(DigitalRosterExtractTableNameDates.get(0).substring(0,2)+"/"+DigitalRosterExtractTableNameDates.get(0).substring(2,4)+"/"+DigitalRosterExtractTableNameDates.get(0).substring(4,8)))) 
					
					{
						// push the data to DB with file date
						CVSRosterExcel2DatabaseTest.pushDataToDB(
								fileNames[0].split(".xlsx")[0].split("_")[1].toString());
						//CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
					}
					
				}
				}
	            
	            else
					if(DigitalRosterExtractTableNameDates.isEmpty())
					{
						// push the data to DB with file date
						CVSRosterExcel2DatabaseTest.pushDataToDB(
								fileNames[0].split(".xlsx")[0].split("_")[1].toString());
						//CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
					}
	            
	            
	            if(!TrainRosterExtractTableNameDates.isEmpty())
	            {
				Collections.sort(TrainRosterExtractTableNameDates, Collections.reverseOrder());
				//System.out.println(DigitalRosterExtractTableNameDates.get(0).substring(0,2)+"-"+DigitalRosterExtractTableNameDates.get(0).substring(2,4)+"-"+DigitalRosterExtractTableNameDates.get(0).substring(4,8));
				// comapre the new ROV file date is after the date of the last pushed to DB ROV
				// file
				
				
				if (fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "").contains(TrainRosterExtractTableNameDates.get(0))) 
				{
	                 System.out.println("The new file data already exists in DB and had been processed");
				} 
				
				else 
				
				{
					if (new SimpleDateFormat("MM/dd/yyyy").parse(fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", "/"))
							.after(new SimpleDateFormat("MM/dd/yyyy").parse(TrainRosterExtractTableNameDates.get(0).substring(0,2)+"/"+TrainRosterExtractTableNameDates.get(0).substring(2,4)+"/"+TrainRosterExtractTableNameDates.get(0).substring(4,8)))) 
					
					{
						// push the data to DB with file date
						CVSRosterExcel2DatabaseTest.pushDataToDB(
								fileNames[0].split(".xlsx")[0].split("_")[1].toString());
						//CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
					}
					
				}
				}
	            
	            else
					if(TrainRosterExtractTableNameDates.isEmpty())
					{
						// push the data to DB with file date
						CVSRosterExcel2DatabaseTest.pushDataToDB(
								fileNames[0].split(".xlsx")[0].split("_")[1].toString());
						//CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
					}
			 
			        }
		} catch (Exception ex) {

			System.out.println("Some issues while pushing data to DB");

			System.out.println();

			ex.printStackTrace();

		}

	}

	
	

	@Test (priority = 8)
	public static void compareDigitalAndTrainRostersAndFindDiff() throws IOException, SQLException {
		
		if(!DigitalRosterExtractTableNameDates.isEmpty())
		{
		//CVSTrainRosterExcel2DatabaseTest.main();
		
			//select * from  DigitalRosterExtract_07132022 WHERE  ColleagueID NOT IN (SELECT ColleagueID FROM DigitalRosterExtract_07202022)
		String DigitalRosterExtractVsTrainExtractDiffQuery = getPropertyValueFromPropertyFile("DigitalRosterExtractVsTrainExtractDiffQuery");
		String digitalRosterVsTrainRosterDiffTableName = getPropertyValueFromPropertyFile("digitalRosterVsTrainRosterDiffTableName");
		String RosterExtractName = getPropertyValueFromPropertyFile("RosterExtractName");
		
			if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
 	         {
				
				String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
				if(firstReportWorkBook.contains("true"))
				{
					System.out.println("Since this is the first sheet - there are nothing to compare against");
				}
				else
				{
					CalculateDiffBetweenDigitalVsTrainRosters(DigitalRosterExtractVsTrainExtractDiffQuery,
							digitalRosterVsTrainRosterDiffTableName,DigitalRosterExtractTableNameDates.get(0), fileNames[0].split(".xlsx")[0].split("_")[1].toString().replaceAll("-", ""), RosterExtractName);
				}
				}
		}
		
		else
		{
			String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
			if(firstReportWorkBook.contains("true"))
			{
				System.out.println("Since this is the first sheet - there are nothing to compare against");
			}
			
		}
	}
	
	
	public static void CalculateDiffBetweenDigitalVsTrainRosters(String DigitalRosterExtractVsTrainExtractDiffQuery,String digitalRosterVsTrainRosterDiffTableName, String existingDBTable, String newTableName, String rosterExtractName) throws SQLException, IOException
	{
		
		 String user = "postgres";
		 String password = "postgres";
		 Connection connection = commonUtilityFunctions.connectToPostgresDB(user,password);
			
		 DigitalRosterExtractVsTrainExtractDiffQuery = DigitalRosterExtractVsTrainExtractDiffQuery.replaceAll("digitalRosterTable",rosterExtractName+"_"+existingDBTable);		       
		 DigitalRosterExtractVsTrainExtractDiffQuery = DigitalRosterExtractVsTrainExtractDiffQuery.replaceAll("trainRosterTable",rosterExtractName+"_"+newTableName);
          
		ResultSet rs = connection.createStatement().executeQuery(DigitalRosterExtractVsTrainExtractDiffQuery);
		String createAttritionTableQuery =  getPropertyValueFromPropertyFile("createAttritionTableQuery");
		createNewTableInDB(fileNames[0].split(".xlsx")[0].split("_")[1].replaceAll("-", ""), createAttritionTableQuery, connection);
		PushRecordSetToExcel(DigitalRosterExtractVsTrainExtractDiffQuery,"Attrition_"+newTableName,connection,"Leavers");
		CVSCompareDatabaseTablesTest.copyResultsetToTable(DigitalRosterExtractVsTrainExtractDiffQuery, digitalRosterVsTrainRosterDiffTableName.trim()+"_"+newTableName, connection, connection);
		
	}
	
	
	@Test(priority = 9)
	public static void createTrainRosterSheet() throws IOException {
		
		File directoryPath = new File("./resources/process");
		String fileNames[] = directoryPath.list();
		String TargetSheetPathAndName = "./resources/process/"+fileNames[0];

		// String TargetSheetPathAndName = "./resources/sheetWithEmptyColumnData.xlsx";
        if(getPropertyValueFromPropertyFile("RosterExtractName").contains("TrainRosterExtract"))
        {
		 NewSheetPathAndName = "./resources/trainRosters/trainRoster_"+fileNames[0].split("_")[1]+".xlsx";
        }
        else
        	 if(getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
             {
     		 NewSheetPathAndName = "./resources/trainRosters/trainRoster_"+fileNames[0].split("_")[1].replaceAll("-", "")+".xlsx";
             }	
		if (TargetSheetPathAndName != null && !"".equals(TargetSheetPathAndName.trim())) {

			try {

				File targetFile = new File(TargetSheetPathAndName.trim());

				FileInputStream inputStream = new FileInputStream(targetFile);

				XSSFWorkbook inputWorkbook = new XSSFWorkbook(inputStream);

				int targetSheetCount = inputWorkbook.getNumberOfSheets();

				System.out.println("Total no. of sheet(s) in the Target Workbook: " + targetSheetCount);

				File outputFile = new File(NewSheetPathAndName.trim());

				FileOutputStream outputStream = new FileOutputStream(outputFile);

				XSSFWorkbook outputWorkbook = new XSSFWorkbook();

// Step #2 : Creating sheets with the same name as appearing in target workbook.

				for (int i = 0; i < targetSheetCount; i++) {

					XSSFSheet targetSheet = inputWorkbook.getSheetAt(i);

					String inputSheetName = inputWorkbook.getSheetName(i);
					if (inputSheetName.equals("Train Roster Extract") && getPropertyValueFromPropertyFile("RosterExtractName").contains("TrainRosterExtract"))
			         {

						XSSFSheet outputSheet = outputWorkbook.createSheet(inputSheetName);

						copyExcelWB(targetSheet, outputSheet);
					}
					if (inputSheetName.equals("Digital Roster Extract") && getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
			         {

						XSSFSheet outputSheet = outputWorkbook.createSheet(inputSheetName);

						copyExcelWB(targetSheet, outputSheet);
					}

				}

// Step #4 : Write all the sheets in the new Workbook using FileOutStream Object

				outputWorkbook.write(outputStream);

				outputStream.close();

			}

			catch (Exception ex) {

				System.out.println("Please check the target sheet given path and name: " + TargetSheetPathAndName);

				System.out.println();

				ex.printStackTrace();

			}
		}
	}
	
	
	
}
