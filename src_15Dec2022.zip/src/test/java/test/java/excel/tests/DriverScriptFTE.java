package test.java.excel.tests;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;

import main.java.commonUtilityFunctions;





public class DriverScriptFTE {

	public static void main(String[] args) throws IOException, ParseException, SQLException {
		// TODO Auto-generated method stub
		
		
		CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","true");
		
		File directoryPath = new File("./resources/dump");
		String fileNames[] = directoryPath.list();
		ArrayList<String> arrayListOfFiles = new ArrayList<String>();
		for (int k = 0; k < fileNames.length; k++) {
             if(fileNames[k].contains(".xlsx"))
             {
			arrayListOfFiles.add(fileNames[k].split("_")[1]);
             }

			}
		Collections.sort(arrayListOfFiles);//, Collections.reverseOrder());
		
		for(int i=0;i<arrayListOfFiles.size();i++)
		{
		for(int x=0;x<fileNames.length;x++)
		{
		
			if(fileNames[x].contains(arrayListOfFiles.get(i)))
			{
				
				if(Files.exists(Paths.get("./resources/process/"+fileNames[x]))) { 
				    // do something
				}
				else
				{
					
					
					//delete all files in process folder and bring in file which needs to be processed
					
	        commonUtilityFunctions.cleanFolder("./resources/process/");
			commonUtilityFunctions.copyFile(new File("./resources/dump/"+fileNames[x]), new File("./resources/process/"+fileNames[x]));
				}
			CVSPushRosterToDBAndFindDiffAndAttrition.createRosterSheet();
			CVSPushRosterToDBAndFindDiffAndAttrition.PushRosterDataToDBAndFindDiff();
			CVSPushRosterToDBAndFindDiffAndAttrition.compareAndFindAttritionAgainstExistingRosterTable();
			CVSPushRosterToDBAndFindDiffAndAttrition.compareAndFindJoinersAgainstExistingRosterTable();
			CVSPushSummayViewDataInDB.pushWeeklySummaryDataToDBForSVPWiseSummaryReport();
			//PrepareSummaryReport.prepareSVPWiseSummaryReportFromDBData();
			CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
			}
			
		}
			
		}
		
		//connect to DB
		
		
		/*// variables
		Connection connection = null;
		// Statement statement = null;
		ResultSet resultSet = null;

		// Step 1: Loading or registering Oracle JDBC driver class
		try {

			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		} catch (ClassNotFoundException cnfex) {

			System.out.println("Problem in loading or " + "registering MS Access JDBC driver");
			cnfex.printStackTrace();
		}

		// Step 2: Opening database connection
		try {

			String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
			String dbURL = "jdbc:ucanaccess://" + msAccDB;

			// Step 2.A: Create and get connection using DriverManager class
			connection = DriverManager.getConnection(dbURL);*/
		// variables
		Connection connection = null;
				// Statement statement = null;
				ResultSet resultSet = null;
				  String user = "postgres";
				    String password = "postgres";
				
				// Step 2: Opening database connection
				try {

					 connection = commonUtilityFunctions.connectToPostgresDB(user,password);

		} catch (Exception ex) {

			System.out.println("DriverManager.getConnection(dbURL) failed");
			System.out.println();
			ex.printStackTrace();

		}



   

	  //populate the internal final report table 
				
				
				
				
				/*String MonthWiseSummaryDataPerSVPInterimTableQuery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("MonthWiseSummaryDataPerSVPInterimTableQuery");
				CVSCompareDatabaseTablesTest.copyResultsetToTable(MonthWiseSummaryDataPerSVPInterimTableQuery, "interimfinalreporttable".trim(), connection, connection);		
		
				//create final report table
				
				String DigitalRosterExtractMonthwiseFinalReportQuery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("DigitalRosterExtractMonthwiseFinalReportQuery");
		        CVSPushRosterToDBAndFindDiffAndAttrition.PushRecordSetToExcel(DigitalRosterExtractMonthwiseFinalReportQuery,"FinalReport",connection,LocalDateTime.now().toString());*/
	}

}
