package test.java.excel.tests;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import main.java.commonUtilityFunctions;

public class PrepareSummaryReport2 {

	public static void main(String[] args) throws SQLException, IOException, ParseException {
		// TODO Auto-generated method stub
	}
	
	public static void prepareSVPWiseSummaryReportFromDBData() throws IOException, SQLException, ParseException
	{
		File directoryPath = new File("./resources/process/");
		// List of all files and directories
		String fileNames[] = directoryPath.list();
		
		/*
		 * // variables Connection connection = null; // Statement statement = null;
		 * ResultSet resultSet = null;
		 * 
		 * // Step 1: Loading or registering Oracle JDBC driver class try {
		 * 
		 * Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); } catch
		 * (ClassNotFoundException cnfex) {
		 * 
		 * System.out.println("Problem in loading or " +
		 * "registering MS Access JDBC driver"); cnfex.printStackTrace(); }
		 * 
		 * // Step 2: Opening database connection try {
		 * 
		 * String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
		 * String dbURL = "jdbc:ucanaccess://" + msAccDB;
		 * 
		 * // Step 2.A: Create and get connection using DriverManager class connection =
		 * DriverManager.getConnection(dbURL);
		 */
		
		// variables
		Connection connection = null;
				// Statement statement = null;
				ResultSet resultSet = null;
				  String user = "postgres";
				    String password = "postgres";
				/*
				 * // Step 1: Loading or registering Oracle JDBC driver class try {
				 * 
				 * Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); } catch
				 * (ClassNotFoundException cnfex) {
				 * 
				 * System.out.println("Problem in loading or " +
				 * "registering MS Access JDBC driver"); cnfex.printStackTrace(); }
				 */
				// Step 2: Opening database connection
				try {

					/*
					 * String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
					 * String dbURL = "jdbc:ucanaccess://" + msAccDB;
					 * 
					 * // Step 2.A: Create and get connection using DriverManager class connection =
					 * DriverManager.getConnection(dbURL);
					 */

					connection = commonUtilityFunctions.connectToPostgresDB(user,password);
					connection.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);

				} catch (Exception ex) {

					System.out.println("DriverManager.getConnection(dbURL) failed");
					System.out.println();
					ex.printStackTrace();

				}

		

		   //Statement stmt= connection.createStatement();
		   

		   String SQLQuery = "SELECT public.SummaryViewData.\"SVP\" from public.SummaryViewData GROUP BY public.SummaryViewData.\"SVP\"";
		   PreparedStatement pst = connection.prepareStatement(SQLQuery);
		   ResultSet rs = pst.executeQuery(); 
		   //ResultSet rs = stmt.executeQuery("select SVP from SummaryViewData group by SVP");
			
			 
		    
		    SimpleDateFormat inputFormat = new SimpleDateFormat("MMddyyyy");
		    SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MMM-YYYY");
		    Date theDate = inputFormat.parse(fileNames[0].split("_")[1].replaceAll("-", ""));
		   String monthName = outputFormat.format(theDate).substring(0,6);
		  while(rs.next())
		  {
			  //resultSet = stmt.executeQuery(MonthWiseSummaryDataPerSVPQuery); 
			  String MonthWiseSummaryDataPerSVPQuery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("MonthWiseSummaryDataPerSVPQuery");
			  MonthWiseSummaryDataPerSVPQuery =  MonthWiseSummaryDataPerSVPQuery.replaceAll("SVPName", rs.getString("SVP"));
			  CVSPushRosterToDBAndFindDiffAndAttrition.PushRecordSetToExcel(MonthWiseSummaryDataPerSVPQuery,rs.getString("SVP"),connection,"Summary_"+monthName.split("-")[1]);
			  MonthWiseSummaryDataPerSVPQuery="";
		  }
		  //filterTestForAttrition.copyFileToAnotherFolder(".\\resources\\SummaryDetails\\MonthWiseSummaryReports\\", ".\\resources\\SummaryDetails\\MonthWiseSummaryReports\\"+monthName.split("-")[1]+".xlsx",3);
		  
		  //CopySheetFromOneWorkBookToAnother.mergeExcelFiles(new File(".\\resources\\SummaryDetails\\MonthWiseSummaryReports\\"+monthName.split("-")[1]+"_Report.xlsx") , ".\\resources\\SummaryDetails\\MonthWiseSummaryReports\\");
	        connection.commit();
	        
	        //connection.close();
	       
	}	
	

}

