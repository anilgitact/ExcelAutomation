package test.java.excel.tests;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import main.java.commonUtilityFunctions;

public class prepareContractorDataForSummaryView {

	public static void main(String[] args) {
		
		
		  Integer lastRovMonthNumber=0;
		  Set<String> svps = new HashSet<String>();
		  ArrayList<String> rovdates_arraylist = new ArrayList<String>();
		  ArrayList<Integer> rov_monthnumbers_arraylist= new ArrayList<Integer>();
		  ArrayList<String> rs_svp_senioleaders_arrayList = new ArrayList<String>();
		  
		  String rovdate1 = "",rovdate2 = "",rovdate3 = "",rovdate4 = "",rovdate5 = "",rovdate6 = "",rovdate7 = "",rovdate8 = "",rovdate9 = "",rovdate10 = "",rovdate11 = "",rovdate12="";
		
		  String jan_Headcount="", jan_totalJoiners="", jan_totalLeavers="" , feb_Headcount="" , feb_totalJoiners="" , feb_totalLeavers="" , mar_Headcount="" , mar_totalJoiners="" , mar_totalLeavers="" , apr_Headcount="" , apr_totalJoiners="" , apr_totalLeavers="" , may_Headcount="" , may_totalJoiners="" , may_totalLeavers="" , jun_Headcount="", jun_totalJoiners="" , jun_totalLeavers="" , jul_Headcount="" , jul_totalJoiners="" , jul_totalLeavers="" , aug_Headcount="" , aug_totalJoiners="" , aug_totalLeavers="" , sep_Headcount="" , sep_totalJoiners="" , sep_totalLeavers="" , oct_Headcount="" , oct_totalJoiners="" , oct_totalLeavers="" , nov_Headcount="" , nov_totalJoiners="" , nov_totalLeavers="" , dec_Headcount="" , dec_totalJoiners="" , dec_totalLeavers="";
		  Connection connection = null;
		// Statement statement = "";
		ResultSet rs = null;
		  String user = "postgres";
		    String password = "postgres";
		
		// Step 2: Opening database connection
		try {
			 connection = commonUtilityFunctions.connectToPostgresDB(user,password);
			 connection.setAutoCommit(false);

			 Statement st = connection.createStatement();
	    		String query1 = "select summaryviewdata.\"SVP\" from summaryviewdata where type='Contractor'";
	    	  rs = st.executeQuery(query1);
	    	  
	    	  while(rs.next())
	    	  {
	    		  svps.add(rs.getString(1));
	    	  }
			 
	    	  Object[] svps_array = svps.toArray();
	    	  
	    	  for(int x=0; x<svps_array.length;x++)
	    	  {
	    		  
	    		  String query2 = "select distinct(summaryviewdata.\"SeniorLeader\") from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and type='Contractor' ";
	    		  ResultSet rs_svp_senioleaders = st.executeQuery(query2);
	    		  
	    		  while(rs_svp_senioleaders.next())
	    		  {
	    			  
	    			  rs_svp_senioleaders_arrayList.add(rs_svp_senioleaders.getString(1));
	    			  
	    		  }
	    		  
	    		  System.out.println("orginal number of SLs:"+rs_svp_senioleaders_arrayList.size());
	    		  for(int y=0; y<rs_svp_senioleaders_arrayList.size();y++)
		    	  {
	    			  
	    			  
	    			  System.out.println("value of y:"+y);  
	    			String query3= "select distinct(summaryviewdata.\"ROVReportDate\")  from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+"' and type='Contractor'";  
	    		  ResultSet rs_svp_rovdates = st.executeQuery(query3);
	    		 
	    		  while(rs_svp_rovdates.next())
	    		  {
	    			  
	    			  rovdates_arraylist.add(rs_svp_rovdates.getString(1));
	    			  
	    		  }
	    		  
	    		  
	    		  System.out.println(rovdates_arraylist);
	    	  
	    	  
	    	  
	    	  for(int l=0;l<rovdates_arraylist.size();l++ )
	    		  
	    	  {
	    		  
	    		  rov_monthnumbers_arraylist.add(Integer.parseInt(rovdates_arraylist.get(l).substring(0,2)));
	    	  }
	    	  Collections.sort(rov_monthnumbers_arraylist);
	    	  
	    	   lastRovMonthNumber = rov_monthnumbers_arraylist.get(rov_monthnumbers_arraylist.size()-1);
	    	  System.out.println(lastRovMonthNumber);
	    	  for(int i=0; i<rovdates_arraylist.size();i++)
	    	  {
	    		  
	    			  
	    			  switch(rovdates_arraylist.get(i).substring(0,2))
	    			  {
	    			  case("01"):
	    			   rovdate1= rovdate1+rovdates_arraylist.get(i)+",";
	    			  break;
	    			  
	    			  case("02"):
	    			   rovdate2 = rovdate2+rovdates_arraylist.get(i)+",";
	    			  break;
	    			  
	    			  case("03"):
	    			   rovdate3 = rovdate3+rovdates_arraylist.get(i)+",";
	    			  break;
	    			  
	    			  case("04"):
	    			   rovdate4 = rovdate4+rovdates_arraylist.get(i)+",";
	    			  break;
	    			  
	    			  case("05"):
	    			   rovdate5 = rovdate5+rovdates_arraylist.get(i)+",";
	    			  break;
	    			  
	    			  case("06"):
	    			   rovdate6 = rovdate6+rovdates_arraylist.get(i)+",";
	    			  break;
	    			  
	    			  case("07"):
	    			   rovdate7 = rovdate7+rovdates_arraylist.get(i)+",";
	    			  break;
	    			  
	    			  case("08"):
	    			   rovdate8 = rovdate8+rovdates_arraylist.get(i)+",";
	    			  break;
	    			  
	    			  case("09"):
	    			   rovdate9 = rovdate9+rovdates_arraylist.get(i)+",";
	    			  break;
	    			  
	    			  case("10"):
	    			   rovdate10 = rovdate10+rovdates_arraylist.get(i)+",";
	    			  break;
	    			  
	    			  case("11"):
	    			   rovdate11 = rovdate11+rovdates_arraylist.get(i)+",";
	    			  break;
	    			  
	    			  case("12"):
	    			   rovdate12 = rovdate12+rovdates_arraylist.get(i)+",";
	    			  break;
	    			  
	    			  
	    		  }
	    	  }
	    	  String rov_date="";
	    	  String query="";
	    	  ResultSet headcount_joiners_leavers_resultset=null;
	    	  for(int a=1;a<=12;a++)
	    	  {
	    		  
	    		  
	    			  
	    		  switch(a)
    			  {
    			  case(1):
    			   rov_date= rovdate1.replaceAll("(,)*$", "");;
    			 
    			   
    			   if(rov_date=="")
    			   {
    				   jan_Headcount = "0";
	    			   jan_totalJoiners = "0";
	    			   jan_totalLeavers = "0";
    			   }
    			  if(rov_date!="")
    			  {
    				  if(!rov_date.contains(","))
        			  {
    			   String query4 = "select * from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ rov_date+"' and type='Contractor'" ;
    			   headcount_joiners_leavers_resultset = st.executeQuery(query4);
	    	  	   
    			   
    			   
	    		  while(headcount_joiners_leavers_resultset.next())
	    		  {
	    			  
	    			   jan_Headcount = headcount_joiners_leavers_resultset.getString(3);
	    			   jan_totalJoiners = headcount_joiners_leavers_resultset.getString(4);
	    			   jan_totalLeavers = headcount_joiners_leavers_resultset.getString(5);
	    			 
	    			  
	    		  }
    			  }
    				  
    				  else
    				  {
    					  
    					  //headcount
    					  String[] rovdates_array= rov_date.split(",");
    					  String headcountDate = rovdates_array[rovdates_array.length-1];
    					  String query5 = "select summaryviewdata.\"HeadCount\" from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ headcountDate+"' and type = 'Contractor'" ;
    	    			   headcount_joiners_leavers_resultset = st.executeQuery(query5);
    		    	  	   
    	    			   
    	    			   
    		    		  while(headcount_joiners_leavers_resultset.next())
    		    		  {
    		    			   jan_Headcount = headcount_joiners_leavers_resultset.getString(1);
    		    			  
    		    		  }
    		    		  
    		    		  //total joiners and leavers
    		    		  String headcountDatesForMultiples = "('";
    		    		  for(int c=0;c<rovdates_array.length;c++)
    		    		  {
    		    		   headcountDatesForMultiples = headcountDatesForMultiples+rovdates_array[c]+"','";
    		    		  }
    		    		  headcountDatesForMultiples = headcountDatesForMultiples.replaceAll(",'+$", ")");
    		    		  
    					  String query6 = "select SUM(summaryviewdata.\"TotalJoiners\"::numeric), SUM(summaryviewdata.\"TotalLeavers\"::numeric) from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" in"+ headcountDatesForMultiples ;
    					  headcount_joiners_leavers_resultset = st.executeQuery(query6);
   		    	  	   
   	    			   
   	    			   
   		    		  while(headcount_joiners_leavers_resultset.next())
   		    		  {
   		    			   jan_totalJoiners = headcount_joiners_leavers_resultset.getString(1);
   		    			   jan_totalLeavers = headcount_joiners_leavers_resultset.getString(2);
   		    			  
   		    		  
    				  }
    			  }
    			  }
    			  break;
    			  
    			  case(2):
    				  
    				  
    				  if(a==lastRovMonthNumber+1)
    				  {  
    					  
    					  feb_Headcount = jan_Headcount.toString();
    					  feb_totalJoiners = "0";
		    			  feb_totalLeavers = "0";
    				  }
    				 
    				 
    				  else
    				  {
    				  rov_date= rovdate2.replaceAll("(,)*$", "");;
    	    			 

       			   if(rov_date=="")
       			   {
       				   feb_Headcount = "0";
   	    			   feb_totalJoiners = "0";
   	    			   feb_totalLeavers = "0";
       			   }
       			   
        			  if(rov_date!="")
        			  {
        				  if(!rov_date.contains(","))
            			  {
        			   query = "select * from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ rov_date+"' and type= 'Contractor'" ;
        			   headcount_joiners_leavers_resultset = st.executeQuery(query);
    	    	  	   
        			   
        			   
    	    		  while(headcount_joiners_leavers_resultset.next())
    	    		  {
    	    			  
    	    			   feb_Headcount = headcount_joiners_leavers_resultset.getString(3);
    	    			   feb_totalJoiners = headcount_joiners_leavers_resultset.getString(4);
    	    			   feb_totalLeavers = headcount_joiners_leavers_resultset.getString(5);
    	    			 
    	    			  
    	    		  }
        			  }
        				  
        				  else
        				  {
        					  
        					  //headcount
        					  String[] rovdates_array= rov_date.split(",");
        					  String headcountDate = rovdates_array[rovdates_array.length-1];
        					  query = "select summaryviewdata.\"HeadCount\" from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ headcountDate+"' and type = 'Contractor'" ;
        	    			   headcount_joiners_leavers_resultset = st.executeQuery(query);
        		    	  	   
        	    			   
        	    			   
        		    		  while(headcount_joiners_leavers_resultset.next())
        		    		  {
        		    			   feb_Headcount = headcount_joiners_leavers_resultset.getString(1);
        		    			  
        		    		  }
        		    		  
        		    		  //total joiners and leavers
        		    		  String headcountDatesForMultiples = "('";
        		    		  for(int c=0;c<rovdates_array.length;c++)
        		    		  {
        		    		   headcountDatesForMultiples = headcountDatesForMultiples+rovdates_array[c]+"','";
        		    		  }
        		    		  headcountDatesForMultiples = headcountDatesForMultiples.replaceAll(",'+$", ")");
        		    		  
        					  query = "select SUM(summaryviewdata.\"TotalJoiners\"::numeric), SUM(summaryviewdata.\"TotalLeavers\"::numeric) from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and type = 'Contractor' and summaryviewdata.\"ROVReportDate\" in"+ headcountDatesForMultiples ;
        					  headcount_joiners_leavers_resultset = st.executeQuery(query);
       		    	  	   
       	    			   
       	    			   
       		    		  while(headcount_joiners_leavers_resultset.next())
       		    		  {
       		    			   feb_totalJoiners = headcount_joiners_leavers_resultset.getString(1);
       		    			   feb_totalLeavers = headcount_joiners_leavers_resultset.getString(2);
       		    			  
       		    		  
        				  }
        			  }
        			  }
    				  }
    			  break;
    			  
    			  case(3):
    				  
    				  if(a==lastRovMonthNumber+1)
    				  {  
    					  Integer mar_average= (Integer.parseInt(jan_Headcount)+Integer.parseInt(feb_Headcount)+Integer.parseInt(mar_Headcount))/3;
    					  
    					  mar_Headcount = mar_average.toString();
    					  mar_totalJoiners = "0";
		    			  mar_totalLeavers = "0";
    				  }
    				  else if(a==lastRovMonthNumber+2)
    				  {
    					  mar_Headcount =  feb_Headcount;
    					  mar_totalJoiners = "0";
		    			  mar_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+3)
    				  {
    					  mar_Headcount =  jan_Headcount;
    					  mar_totalJoiners = "0";
		    			  mar_totalLeavers = "0"; 
    				  }
    				 
    				 
    				  else
    				  {
    					  rovdate3= rovdate3.replaceAll("^,+", "");
        			      rov_date= rovdate3.replaceAll(",+$", "");
    	    			 
    				  

       			   if(rov_date=="")
       			   {
       				   mar_Headcount = "0";
   	    			   mar_totalJoiners = "0";
   	    			   mar_totalLeavers = "0";
       			   }
       			   
       			   
        			  if(rov_date!="")
        			  {
        				  if(!rov_date.contains(","))
            			  {
        			   query = "select * from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ rov_date+"' and type= 'Contractor'" ;
        			   headcount_joiners_leavers_resultset = st.executeQuery(query);
    	    	  	   
        			   
        			   
    	    		  while(headcount_joiners_leavers_resultset.next())
    	    		  {
    	    			  
    	    			   mar_Headcount = headcount_joiners_leavers_resultset.getString(3);
    	    			   mar_totalJoiners = headcount_joiners_leavers_resultset.getString(4);
    	    			   mar_totalLeavers = headcount_joiners_leavers_resultset.getString(5);
    	    			 
    	    			  
    	    		  }
        			  }
        				  
        				  else
        				  {
        					  
        					  //headcount
        					  String[] rovdates_array= rov_date.split(",");
        					  String headcountDate = rovdates_array[rovdates_array.length-1];
        					  query = "select summaryviewdata.\"HeadCount\" from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ headcountDate+"'" ;
        	    			   headcount_joiners_leavers_resultset = st.executeQuery(query);
        		    	  	   
        	    			   
        	    			   
        		    		  while(headcount_joiners_leavers_resultset.next())
        		    		  {
        		    			   mar_Headcount = headcount_joiners_leavers_resultset.getString(1);
        		    			  
        		    		  }
        		    		  
        		    		  //total joiners and leavers
        		    		  String headcountDatesForMultiples = "('";
        		    		  for(int c=0;c<rovdates_array.length;c++)
        		    		  {
        		    		   headcountDatesForMultiples = headcountDatesForMultiples+rovdates_array[c]+"','";
        		    		  }
        		    		  headcountDatesForMultiples = headcountDatesForMultiples.replaceAll(",'+$", ")");
        		    		  
        					  query = "select SUM(summaryviewdata.\"TotalJoiners\"::numeric), SUM(summaryviewdata.\"TotalLeavers\"::numeric) from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" in"+ headcountDatesForMultiples ;
        					  headcount_joiners_leavers_resultset = st.executeQuery(query);
       		    	  	   
       	    			   
       	    			   
       		    		  while(headcount_joiners_leavers_resultset.next())
       		    		  {
       		    			   mar_totalJoiners = headcount_joiners_leavers_resultset.getString(1);
       		    			   mar_totalLeavers = headcount_joiners_leavers_resultset.getString(2);
       		    			  
       		    		  
        				  }
        			  }
        			  }
    				  }
    			  break;
    			  
    			  case(4):
    				  
    				  if(a==lastRovMonthNumber+1)
    				  {  
    					  Integer apr_average= (Integer.parseInt(jan_Headcount)+Integer.parseInt(feb_Headcount)+Integer.parseInt(mar_Headcount))/3;
    					  
    					  apr_Headcount = apr_average.toString();
    					  apr_totalJoiners = "0";
		    			  apr_totalLeavers = "0";
    				  }
    				  else if(a==lastRovMonthNumber+2)
    				  {
    					  apr_Headcount =  mar_Headcount;
    					  apr_totalJoiners = "0";
		    			  apr_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+3)
    				  {
    					  apr_Headcount =  feb_Headcount;
    					  apr_totalJoiners = "0";
		    			  apr_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+4)
    				  {
    					  apr_Headcount =  jan_Headcount;
    					  apr_totalJoiners = "0";
		    			  apr_totalLeavers = "0"; 
    				  }
    				
    				 
    				 
    				  else
    				  {
    				  rovdate4= rovdate4.replaceAll("^,+", "");
    			      rov_date= rovdate4.replaceAll(",+$", "");
    	    			 
    			      

       			   if(rov_date=="")
       			   {
       				   apr_Headcount = "0";
   	    			   apr_totalJoiners = "0";
   	    			   apr_totalLeavers = "0";
       			   }
       			   
       			   
        			  if(rov_date!="")
        			  {
        				  if(!rov_date.contains(","))
            			  {
        			   query = "select * from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ rov_date+"' and type = 'Contractor'" ;
        			   headcount_joiners_leavers_resultset = st.executeQuery(query);
    	    	  	   
        			   
        			   
    	    		  while(headcount_joiners_leavers_resultset.next())
    	    		  {
    	    			  
    	    			   apr_Headcount = headcount_joiners_leavers_resultset.getString(4);
    	    			   apr_totalJoiners = headcount_joiners_leavers_resultset.getString(5);
    	    			   apr_totalLeavers = headcount_joiners_leavers_resultset.getString(6);
    	    			 
    	    			  
    	    		  }
        			  }
        				  
        				  else
        				  {
        					  
        					  //headcount
        					  String[] rovdates_array= rov_date.split(",");
        					  String headcountDate = rovdates_array[rovdates_array.length-1];
        					  query = "select summaryviewdata.\"HeadCount\" from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ headcountDate+"' and type = 'Contractor'" ;
        	    			   headcount_joiners_leavers_resultset = st.executeQuery(query);
        		    	  	   
        	    			   
        	    			   
        		    		  while(headcount_joiners_leavers_resultset.next())
        		    		  {
        		    			   apr_Headcount = headcount_joiners_leavers_resultset.getString(1);
        		    			  
        		    		  }
        		    		  
        		    		  //total joiners and leavers
        		    		  String headcountDatesForMultiples = "('";
        		    		  for(int c=0;c<rovdates_array.length;c++)
        		    		  {
        		    		   headcountDatesForMultiples = headcountDatesForMultiples+rovdates_array[c]+"','";
        		    		  }
        		    		  headcountDatesForMultiples = headcountDatesForMultiples.replaceAll(",'+$", ")");
        		    		  
        					  query = "select SUM(summaryviewdata.\"TotalJoiners\"::numeric), SUM(summaryviewdata.\"TotalLeavers\"::numeric) from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and type='Contractor' and summaryviewdata.\"ROVReportDate\" in"+ headcountDatesForMultiples ;
        					  headcount_joiners_leavers_resultset = st.executeQuery(query);
       		    	  	   
       	    			   
       	    			   
       		    		  while(headcount_joiners_leavers_resultset.next())
       		    		  {
       		    			   apr_totalJoiners = headcount_joiners_leavers_resultset.getString(1);
       		    			   apr_totalLeavers = headcount_joiners_leavers_resultset.getString(2);
       		    			  
       		    		  
        				  }
        			  }
        			  }
    				  }
    			  break;
    			  
    			  case(5):
    				  
    				  if(a==lastRovMonthNumber+1)
    				  {  
    					  Integer may_average= (Integer.parseInt(jan_Headcount)+Integer.parseInt(feb_Headcount)+Integer.parseInt(mar_Headcount)+Integer.parseInt(apr_Headcount))/4;
    					  
    					  may_Headcount = may_average.toString();
    					  may_totalJoiners = "0";
		    			  may_totalLeavers = "0";
    				  }
    				  else if(a==lastRovMonthNumber+2)
    				  {
    					  may_Headcount =  apr_Headcount;
    					  may_totalJoiners = "0";
		    			  may_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+3)
    				  {
    					  may_Headcount =  mar_Headcount;
    					  may_totalJoiners = "0";
		    			  may_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+4)
    				  {
    					  may_Headcount =  feb_Headcount;
    					  may_totalJoiners = "0";
		    			  may_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+5)
    				  {
    					  sep_Headcount =  jan_Headcount;
    					  may_totalJoiners = "0";
		    			  may_totalLeavers = "0"; 
    				  }
    				 
    				 
    				  else
    				  {
    				  rovdate5= rovdate5.replaceAll("^,+", "");
			          rov_date= rovdate5.replaceAll(",+$", "");
    	    			 
			          

	    			   if(rov_date=="")
	    			   {
	    				   may_Headcount = "0";
		    			   may_totalJoiners = "0";
		    			   may_totalLeavers = "0";
	    			   }
	    			   
        			  if(rov_date!="")
        			  {
        				  if(!rov_date.contains(","))
            			  {
        			   query = "select * from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ rov_date+"' and type = 'Contractor'" ;
        			   headcount_joiners_leavers_resultset = st.executeQuery(query);
    	    	  	   
        			   
        			   
    	    		  while(headcount_joiners_leavers_resultset.next())
    	    		  {
    	    			  
    	    			   may_Headcount = headcount_joiners_leavers_resultset.getString(4);
    	    			   may_totalJoiners = headcount_joiners_leavers_resultset.getString(5);
    	    			   may_totalLeavers = headcount_joiners_leavers_resultset.getString(6);
    	    			 
    	    			  
    	    		  }
        			  }
        				  
        				  else
        				  {
        					  
        					  //headcount
        					  String[] rovdates_array= rov_date.split(",");
        					  String headcountDate = rovdates_array[rovdates_array.length-1];
        					  query = "select summaryviewdata.\"HeadCount\" from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ headcountDate+"' and type = 'Contractor'" ;
        	    			   headcount_joiners_leavers_resultset = st.executeQuery(query);
        		    	  	   
        	    			   
        	    			   
        		    		  while(headcount_joiners_leavers_resultset.next())
        		    		  {
        		    			   may_Headcount = headcount_joiners_leavers_resultset.getString(1);
        		    			  
        		    		  }
        		    		  
        		    		  //total joiners and leavers
        		    		  String headcountDatesForMultiples = "('";
        		    		  for(int c=0;c<rovdates_array.length;c++)
        		    		  {
        		    		   headcountDatesForMultiples = headcountDatesForMultiples+rovdates_array[c]+"','";
        		    		  }
        		    		  headcountDatesForMultiples = headcountDatesForMultiples.replaceAll(",'+$", ")");
        		    		  
        					  query = "select SUM(summaryviewdata.\"TotalJoiners\"::numeric), SUM(summaryviewdata.\"TotalLeavers\"::numeric) from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" in"+ headcountDatesForMultiples ;
        					  headcount_joiners_leavers_resultset = st.executeQuery(query);
       		    	  	   
       	    			   
       	    			   
       		    		  while(headcount_joiners_leavers_resultset.next())
       		    		  {
       		    			   may_totalJoiners = headcount_joiners_leavers_resultset.getString(1);
       		    			   may_totalLeavers = headcount_joiners_leavers_resultset.getString(2);
       		    			  
       		    		  
        				  }
        			  }
        			  }
        			  
        	
    				  }	  
        				
    			  break;
    			  
    			  case(6):
    				  
    				  if(a==lastRovMonthNumber+1)
    				  {  
    					  Integer jun_average= (Integer.parseInt(jan_Headcount)+Integer.parseInt(feb_Headcount)+Integer.parseInt(mar_Headcount)+Integer.parseInt(apr_Headcount)+Integer.parseInt(may_Headcount))/5;
    					  
    					  jun_Headcount = jun_average.toString();
    					  jun_totalJoiners = "0";
		    			  jun_totalLeavers = "0";
    				  }
    				  else if(a==lastRovMonthNumber+2)
    				  {
    					  jun_Headcount =  may_Headcount;
    					  jun_totalJoiners = "0";
		    			  jun_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+3)
    				  {
    					  jun_Headcount =  apr_Headcount;
    					  jun_totalJoiners = "0";
		    			  jun_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+4)
    				  {
    					  jun_Headcount =  mar_Headcount;
    					  jun_totalJoiners = "0";
		    			  jun_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+5)
    				  {
    					  sep_Headcount =  feb_Headcount;
    					  jun_totalJoiners = "0";
		    			  jun_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+6)
    				  {
    					  jun_Headcount =  jan_Headcount;
    					  jun_totalJoiners = "0";
		    			  jun_totalLeavers = "0"; 
    				  }
    				 
    				  else
    				  {
    				  rovdate6= rovdate6.replaceAll("^,+", "");
		              rov_date= rovdate6.replaceAll(",+$", "");
    	    			 
		              

	    			   if(rov_date=="")
	    			   {
	    				   jun_Headcount = "0";
		    			   jun_totalJoiners = "0";
		    			   jun_totalLeavers = "0";
	    			   }
	    			   
	    			   
        			  if(rov_date!="")
        			  {
        				  if(!rov_date.contains(","))
            			  {
        			   query = "select * from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ rov_date+"'" ;
        			   headcount_joiners_leavers_resultset = st.executeQuery(query);
    	    	  	   
        			   
        			   
    	    		  while(headcount_joiners_leavers_resultset.next())
    	    		  {
    	    			  
    	    			   jun_Headcount = headcount_joiners_leavers_resultset.getString(3);
    	    			   jun_totalJoiners = headcount_joiners_leavers_resultset.getString(4);
    	    			   jun_totalLeavers = headcount_joiners_leavers_resultset.getString(5);
    	    			 
    	    			  
    	    		  }
        			  }
        				  
        				  else
        				  {
        					  
        					  //headcount
        					  String[] rovdates_array= rov_date.split(",");
        					  String headcountDate = rovdates_array[rovdates_array.length-1];
        					  query = "select summaryviewdata.\"HeadCount\" from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ headcountDate+"' and type = 'Contractor'" ;
        	    			   headcount_joiners_leavers_resultset = st.executeQuery(query);
        		    	  	   
        	    			   
        	    			   
        		    		  while(headcount_joiners_leavers_resultset.next())
        		    		  {
        		    			   jun_Headcount = headcount_joiners_leavers_resultset.getString(1);
        		    			  
        		    		  }
        		    		  
        		    		  //total joiners and leavers
        		    		  String headcountDatesForMultiples = "('";
        		    		  for(int c=0;c<rovdates_array.length;c++)
        		    		  {
        		    		   headcountDatesForMultiples = headcountDatesForMultiples+rovdates_array[c]+"','";
        		    		  }
        		    		  headcountDatesForMultiples = headcountDatesForMultiples.replaceAll(",'+$", ")");
        		    		  
        					  query = "select SUM(summaryviewdata.\"TotalJoiners\"::numeric), SUM(summaryviewdata.\"TotalLeavers\"::numeric) from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" in"+ headcountDatesForMultiples ;
        					  headcount_joiners_leavers_resultset = st.executeQuery(query);
       		    	  	   
       	    			   
       	    			   
       		    		  while(headcount_joiners_leavers_resultset.next())
       		    		  {
       		    			   jun_totalJoiners = headcount_joiners_leavers_resultset.getString(1);
       		    			   jun_totalLeavers = headcount_joiners_leavers_resultset.getString(2);
       		    			  
       		    		  
        				  }
        			  }
        			  }
    				  }
        			  break;
    			  
    			  case(7):
    				  
    				  if(a==lastRovMonthNumber+1)
    				  {  
    					  Integer jul_average= (Integer.parseInt(jan_Headcount)+Integer.parseInt(feb_Headcount)+Integer.parseInt(mar_Headcount)+Integer.parseInt(apr_Headcount)+Integer.parseInt(may_Headcount)+Integer.parseInt(jun_Headcount))/6;
    					  
    					  jul_Headcount = jul_average.toString();
    					  jul_totalJoiners = "0";
		    			  jul_totalLeavers = "0";
    				  }
    				  else if(a==lastRovMonthNumber+2)
    				  {
    					  jul_Headcount =  jun_Headcount;
    					  jul_totalJoiners = "0";
		    			  jul_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+3)
    				  {
    					  jul_Headcount =  may_Headcount;
    					  jul_totalJoiners = "0";
		    			  jul_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+4)
    				  {
    					  jul_Headcount =  apr_Headcount;
    					  jul_totalJoiners = "0";
		    			  jul_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+5)
    				  {
    					  sep_Headcount =  mar_Headcount;
    					  jul_totalJoiners = "0";
		    			  jul_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+6)
    				  {
    					  jul_Headcount =  feb_Headcount;
    					  jul_totalJoiners = "0";
		    			  jul_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+7)
    				  {
    					  jul_Headcount =  jan_Headcount;
    					  jul_totalJoiners = "0";
		    			  jul_totalLeavers = "0"; 
    				  }
    				  else
    				  {
    				  rovdate7= rovdate7.replaceAll("^,+", "");
		              rov_date= rovdate7.replaceAll(",+$", "");
    	    			 
		              

	    			   if(rov_date=="")
	    			   {
	    				   jul_Headcount = "0";
		    			   jul_totalJoiners = "0";
		    			   jul_totalLeavers = "0";
	    			   }
        			  if(rov_date!="")
        			  {
        				  if(!rov_date.contains(","))
            			  {
        			   query = "select * from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ rov_date+"'" ;
        			   headcount_joiners_leavers_resultset = st.executeQuery(query);
    	    	  	   
        			   
        			   
    	    		  while(headcount_joiners_leavers_resultset.next())
    	    		  {
    	    			  
    	    			   jul_Headcount = headcount_joiners_leavers_resultset.getString(3);
    	    			   jul_totalJoiners = headcount_joiners_leavers_resultset.getString(4);
    	    			   jul_totalLeavers = headcount_joiners_leavers_resultset.getString(5);
    	    			 
    	    			  
    	    		  }
        			  }
        				  
        			
        					  
        					  else
            				  {
            					  
            					  //headcount
            					  String[] rovdates_array= rov_date.split(",");
            					  String headcountDate = rovdates_array[rovdates_array.length-1];
            					  query = "select summaryviewdata.\"HeadCount\" from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ headcountDate+"'" ;
            	    			   headcount_joiners_leavers_resultset = st.executeQuery(query);
            		    	  	   
            	    			   
            	    			   
            		    		  while(headcount_joiners_leavers_resultset.next())
            		    		  {
            		    			   jul_Headcount = headcount_joiners_leavers_resultset.getString(1);
            		    			  
            		    		  }
            		    		  
            		    		  //total joiners and leavers
            		    		  String headcountDatesForMultiples = "('";
            		    		  for(int c=0;c<rovdates_array.length;c++)
            		    		  {
            		    		   headcountDatesForMultiples = headcountDatesForMultiples+rovdates_array[c]+"','";
            		    		  }
            		    		  headcountDatesForMultiples = headcountDatesForMultiples.replaceAll(",'+$", ")");
            		    		  
            					  query = "select SUM(summaryviewdata.\"TotalJoiners\"::numeric), SUM(summaryviewdata.\"TotalLeavers\"::numeric) from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and type = 'Contractor' and summaryviewdata.\"ROVReportDate\" in"+ headcountDatesForMultiples ;
            					  System.out.println(query);
            					  headcount_joiners_leavers_resultset = st.executeQuery(query);
           		    	  	   
           	    			   
           	    			   
           		    		  while(headcount_joiners_leavers_resultset.next())
           		    		  {
           		    			   jul_totalJoiners = headcount_joiners_leavers_resultset.getString(1);
           		    			   jul_totalLeavers = headcount_joiners_leavers_resultset.getString(2);
           		    			  
           		    		  
            				  }
            			  }
            			  }
    				  }
    			  break;
    			  
    			  case(8):
    				  
    				  if(a==lastRovMonthNumber+1)
    				  {  
    					  Integer aug_average= (Integer.parseInt(jan_Headcount)+Integer.parseInt(feb_Headcount)+Integer.parseInt(mar_Headcount)+Integer.parseInt(apr_Headcount)+Integer.parseInt(may_Headcount)+Integer.parseInt(jun_Headcount)+Integer.parseInt(jul_Headcount))/7;
    					  
    					  aug_Headcount = aug_average.toString();
    					  aug_totalJoiners = "0";
		    			  aug_totalLeavers = "0";
    				  }
    				  else if(a==lastRovMonthNumber+2)
    				  {
    					  aug_Headcount =  jul_Headcount;
    					  aug_totalJoiners = "0";
		    			  aug_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+3)
    				  {
    					  aug_Headcount =  jun_Headcount;
    					  aug_totalJoiners = "0";
		    			  aug_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+4)
    				  {
    					  aug_Headcount =  may_Headcount;
    					  aug_totalJoiners = "0";
		    			  aug_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+5)
    				  {
    					  sep_Headcount =  apr_Headcount;
    					  aug_totalJoiners = "0";
		    			  aug_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+6)
    				  {
    					  aug_Headcount =  mar_Headcount;
    					  aug_totalJoiners = "0";
		    			  aug_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+7)
    				  {
    					  aug_Headcount =  feb_Headcount;
    					  aug_totalJoiners = "0";
		    			  aug_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+8)
    				  {
    					  aug_Headcount =  jan_Headcount;
    					  aug_totalJoiners = "0";
		    			  aug_totalLeavers = "0"; 
    				  }
    				 
    				  else
    				  {
    				  rovdate8= rovdate8.replaceAll("^,+", "");
		              rov_date= rovdate8.replaceAll(",+$", "");
    	    			 
		              

	    			   if(rov_date=="")
	    			   {
	    				   aug_Headcount = "0";
		    			   aug_totalJoiners = "0";
		    			   aug_totalLeavers = "0";
	    			   }
        			  if(rov_date!="")
        			  {
        				  if(!rov_date.contains(","))
            			  {
        			   query = "select * from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ rov_date+"'" ;
        			   headcount_joiners_leavers_resultset = st.executeQuery(query);
    	    	  	   
        			   
        			   
    	    		  while(headcount_joiners_leavers_resultset.next())
    	    		  {
    	    			  
    	    			   aug_Headcount = headcount_joiners_leavers_resultset.getString(4);
    	    			   aug_totalJoiners = headcount_joiners_leavers_resultset.getString(5);
    	    			   aug_totalLeavers = headcount_joiners_leavers_resultset.getString(6);
    	    			 
    	    			  
    	    		  }
        			  }
        				  
        				  else
        				  {
        					  
        					  //headcount
        					  String[] rovdates_array= rov_date.split(",");
        					  String headcountDate = rovdates_array[rovdates_array.length-1];
        					  query = "select summaryviewdata.\"HeadCount\" from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ headcountDate+"'" ;
        	    			  System.out.println(query);
        					  headcount_joiners_leavers_resultset = st.executeQuery(query);
        		    	  	   
        	    			   
        	    			   
        		    		  while(headcount_joiners_leavers_resultset.next())
        		    		  {
        		    			   aug_Headcount = headcount_joiners_leavers_resultset.getString(1);
        		    			  
        		    		  }
        		    		  
        		    		  //total joiners and leavers
        		    		  String headcountDatesForMultiples = "('";
        		    		  for(int c=0;c<rovdates_array.length;c++)
        		    		  {
        		    		   headcountDatesForMultiples = headcountDatesForMultiples+rovdates_array[c]+"','";
        		    		  }
        		    		  headcountDatesForMultiples = headcountDatesForMultiples.replaceAll(",'+$", ")");
        		    		  
        					  query = "select SUM(summaryviewdata.\"TotalJoiners\"::numeric), SUM(summaryviewdata.\"TotalLeavers\"::numeric) from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" in"+ headcountDatesForMultiples ;
        					  headcount_joiners_leavers_resultset = st.executeQuery(query);
       		    	  	   
       	    			   
       	    			   
       		    		  while(headcount_joiners_leavers_resultset.next())
       		    		  {
       		    			   aug_totalJoiners = headcount_joiners_leavers_resultset.getString(1);
       		    			   aug_totalLeavers = headcount_joiners_leavers_resultset.getString(2);
       		    			  
       		    		  
        				  }
        			  }
        			  }
    				  }
    			  break;
    			  
    			  case(9):
    				  
    				  if(a==lastRovMonthNumber+1)
    				  {  
    					  Integer sep_average= (Integer.parseInt(jan_Headcount)+Integer.parseInt(feb_Headcount)+Integer.parseInt(mar_Headcount)+Integer.parseInt(apr_Headcount)+Integer.parseInt(may_Headcount)+Integer.parseInt(jun_Headcount)+Integer.parseInt(jul_Headcount)+Integer.parseInt(aug_Headcount))/8;
    					  
    					  sep_Headcount = sep_average.toString();
    					  sep_totalJoiners = "0";
		    			  sep_totalLeavers = "0";
    				  }
    				  else if(a==lastRovMonthNumber+2)
    				  {
    					  sep_Headcount =  aug_Headcount;
    					  sep_totalJoiners = "0";
		    			  sep_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+3)
    				  {
    					  sep_Headcount =  jul_Headcount;
    					  sep_totalJoiners = "0";
		    			  sep_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+4)
    				  {
    					  sep_Headcount =  jun_Headcount;
    					  sep_totalJoiners = "0";
		    			  sep_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+5)
    				  {
    					  sep_Headcount =  may_Headcount;
    					  sep_totalJoiners = "0";
		    			  sep_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+6)
    				  {
    					  sep_Headcount =  apr_Headcount;
    					  sep_totalJoiners = "0";
		    			  sep_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+7)
    				  {
    					  sep_Headcount =  mar_Headcount;
    					  sep_totalJoiners = "0";
		    			  sep_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+8)
    				  {
    					  sep_Headcount =  feb_Headcount;
    					  sep_totalJoiners = "0";
		    			  sep_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+9)
    				  {
    					  sep_Headcount =  jan_Headcount;
    					  sep_totalJoiners = "0";
		    			  sep_totalLeavers = "0"; 
    				  }
    				  
    				  else
    				  {
    				  rovdate9= rovdate9.replaceAll("^,+", "");
		              rov_date= rovdate9.replaceAll(",+$", "");
    	    			 
		              

	    			   if(rov_date=="")
	    			   {
	    				   sep_Headcount = "0";
		    			   sep_totalJoiners = "0";
		    			   sep_totalLeavers = "0";
	    			   }
	    			   
	    			   
        			  if(rov_date!="")
        			  {
        				  if(!rov_date.contains(","))
            			  {
        			   query = "select * from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ rov_date+"'" ;
        			   headcount_joiners_leavers_resultset = st.executeQuery(query);
    	    	  	   
        			   
        			   
    	    		  while(headcount_joiners_leavers_resultset.next())
    	    		  {
    	    			  
    	    			   sep_Headcount = headcount_joiners_leavers_resultset.getString(3);
    	    			   sep_totalJoiners = headcount_joiners_leavers_resultset.getString(4);
    	    			   sep_totalLeavers = headcount_joiners_leavers_resultset.getString(5);
    	    			 
    	    			  
    	    		  }
        			  }
        				  
        				  else
        				  {
        					  
        					  //headcount
        					  String[] rovdates_array= rov_date.split(",");
        					  String headcountDate = rovdates_array[rovdates_array.length-1];
        					  query = "select summaryviewdata.\"HeadCount\" from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ headcountDate+"'" ;
        	    			   headcount_joiners_leavers_resultset = st.executeQuery(query);
        		    	  	   
        	    			   
        	    			   
        		    		  while(headcount_joiners_leavers_resultset.next())
        		    		  {
        		    			   sep_Headcount = headcount_joiners_leavers_resultset.getString(1);
        		    			  
        		    		  }
        		    		  
        		    		  //total joiners and leavers
        		    		  String headcountDatesForMultiples = "('";
        		    		  for(int c=0;c<rovdates_array.length;c++)
        		    		  {
        		    		   headcountDatesForMultiples = headcountDatesForMultiples+rovdates_array[c]+"','";
        		    		  }
        		    		  headcountDatesForMultiples = headcountDatesForMultiples.replaceAll(",'+$", ")");
        		    		  
        					  query = "select SUM(summaryviewdata.\"TotalJoiners\"::numeric), SUM(summaryviewdata.\"TotalLeavers\"::numeric) from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" in"+ headcountDatesForMultiples ;
        					  headcount_joiners_leavers_resultset = st.executeQuery(query);
       		    	  	   
       	    			   
       	    			   
       		    		  while(headcount_joiners_leavers_resultset.next())
       		    		  {
       		    			   sep_totalJoiners = headcount_joiners_leavers_resultset.getString(1);
       		    			   sep_totalLeavers = headcount_joiners_leavers_resultset.getString(2);
       		    			  
       		    		  
        				  }
        			  }
        			  }
    				  }
    			  break;
    			  
    			  case(10):
    				  
    				  if(a==lastRovMonthNumber+1)
    				  {  
    					  Integer oct_average= (Integer.parseInt(jan_Headcount)+Integer.parseInt(feb_Headcount)+Integer.parseInt(mar_Headcount)+Integer.parseInt(apr_Headcount)+Integer.parseInt(may_Headcount)+Integer.parseInt(jun_Headcount)+Integer.parseInt(jul_Headcount)+Integer.parseInt(sep_Headcount))/9;
    					  
    					  oct_Headcount = oct_average.toString();
    					  oct_totalJoiners = "0";
		    			  oct_totalLeavers = "0";
    				  }
    				  else if(a==lastRovMonthNumber+2)
    				  {
    					  oct_Headcount =  sep_Headcount;
    					  oct_totalJoiners = "0";
		    			  oct_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+3)
    				  {
    					  oct_Headcount =  aug_Headcount;
    					  oct_totalJoiners = "0";
		    			  oct_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+4)
    				  {
    					  oct_Headcount =  jul_Headcount;
    					  oct_totalJoiners = "0";
		    			  oct_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+5)
    				  {
    					  oct_Headcount =  jun_Headcount;
    					  oct_totalJoiners = "0";
		    			  oct_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+6)
    				  {
    					  oct_Headcount =  may_Headcount;
    					  oct_totalJoiners = "0";
		    			  oct_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+7)
    				  {
    					  oct_Headcount =  apr_Headcount;
    					  oct_totalJoiners = "0";
		    			  oct_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+8)
    				  {
    					  oct_Headcount =  mar_Headcount;
    					  oct_totalJoiners = "0";
		    			  oct_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+9)
    				  {
    					  oct_Headcount =  feb_Headcount;
    					  oct_totalJoiners = "0";
		    			  oct_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+10)
    				  {
    					  oct_Headcount =  jan_Headcount;
    					  oct_totalJoiners = "0";
		    			  oct_totalLeavers = "0"; 
    				  }
    				  else
    				  {
    				  rovdate10= rovdate10.replaceAll("^,+", "");
	                  rov_date= rovdate10.replaceAll(",+$", "");
    	    			 
	                  

	    			   if(rov_date=="")
	    			   {
	    				   oct_Headcount = "0";
		    			   oct_totalJoiners = "0";
		    			   oct_totalLeavers = "0";
	    			   }
	    			   
	    			   
        			  if(rov_date!="")
        			  {
        				  if(!rov_date.contains(","))
            			  {
        			   query = "select * from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ rov_date+"'" ;
        			   headcount_joiners_leavers_resultset = st.executeQuery(query);
    	    	  	   
        			   
        			   
    	    		  while(headcount_joiners_leavers_resultset.next())
    	    		  {
    	    			  
    	    			   oct_Headcount = headcount_joiners_leavers_resultset.getString(3);
    	    			   oct_totalJoiners = headcount_joiners_leavers_resultset.getString(4);
    	    			   oct_totalLeavers = headcount_joiners_leavers_resultset.getString(5);
    	    			 
    	    			  
    	    		  }
        			  }
        				  
        				  else
        				  {
        					  
        					  //headcount
        					  String[] rovdates_array= rov_date.split(",");
        					  String headcountDate = rovdates_array[rovdates_array.length-1];
        					  query = "select summaryviewdata.\"HeadCount\" from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ headcountDate+"'" ;
        	    			   headcount_joiners_leavers_resultset = st.executeQuery(query);
        		    	  	   
        	    			   
        	    			   
        		    		  while(headcount_joiners_leavers_resultset.next())
        		    		  {
        		    			   oct_Headcount = headcount_joiners_leavers_resultset.getString(1);
        		    			  
        		    		  }
        		    		  
        		    		  //total joiners and leavers
        		    		  String headcountDatesForMultiples = "('";
        		    		  for(int c=0;c<rovdates_array.length;c++)
        		    		  {
        		    		   headcountDatesForMultiples = headcountDatesForMultiples+rovdates_array[c]+"','";
        		    		  }
        		    		  headcountDatesForMultiples = headcountDatesForMultiples.replaceAll(",'+$", ")");
        		    		  
        					  query = "select SUM(summaryviewdata.\"TotalJoiners\"::numeric), SUM(summaryviewdata.\"TotalLeavers\"::numeric) from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" in"+ headcountDatesForMultiples ;
        					  headcount_joiners_leavers_resultset = st.executeQuery(query);
       		    	  	   
       	    			   
       	    			   
       		    		  while(headcount_joiners_leavers_resultset.next())
       		    		  {
       		    			   oct_totalJoiners = headcount_joiners_leavers_resultset.getString(1);
       		    			   oct_totalLeavers = headcount_joiners_leavers_resultset.getString(2);
       		    			  
       		    		  
        				  }
        			  }
        			  }
    				  }
    			  break;
    			  
    			  case(11):
    				  
    				  
    				  if(a==lastRovMonthNumber+1)
    				  {  
    					  Integer nov_average= (Integer.parseInt(jan_Headcount)+Integer.parseInt(feb_Headcount)+Integer.parseInt(mar_Headcount)+Integer.parseInt(apr_Headcount)+Integer.parseInt(may_Headcount)+Integer.parseInt(jun_Headcount)+Integer.parseInt(jul_Headcount)+Integer.parseInt(aug_Headcount)+Integer.parseInt(sep_Headcount)+Integer.parseInt(oct_Headcount))/10;
    					  
    					  nov_Headcount = nov_average.toString();
    					  nov_totalJoiners = "0";
		    			  nov_totalLeavers = "0";
    				  }
    				  else if(a==lastRovMonthNumber+2)
    				  {
    					  nov_Headcount =  oct_Headcount;
    					  nov_totalJoiners = "0";
		    			  nov_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+3)
    				  {
    					  nov_Headcount =  sep_Headcount;
    					  nov_totalJoiners = "0";
		    			  nov_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+4)
    				  {
    					  nov_Headcount =  aug_Headcount;
    					  nov_totalJoiners = "0";
		    			  nov_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+5)
    				  {
    					  nov_Headcount =  jul_Headcount;
    					  nov_totalJoiners = "0";
		    			  nov_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+6)
    				  {
    					  nov_Headcount =  jun_Headcount;
    					  nov_totalJoiners = "0";
		    			  nov_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+7)
    				  {
    					  nov_Headcount =  may_Headcount;
    					  nov_totalJoiners = "0";
		    			  nov_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+8)
    				  {
    					  nov_Headcount =  apr_Headcount;
    					  nov_totalJoiners = "0";
		    			  nov_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+9)
    				  {
    					  nov_Headcount =  mar_Headcount;
    					  nov_totalJoiners = "0";
		    			  nov_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+10)
    				  {
    					  nov_Headcount =  feb_Headcount;
    					  nov_totalJoiners = "0";
		    			  nov_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+11)
    				  {
    					  nov_Headcount =  jan_Headcount;
    					  nov_totalJoiners = "0";
		    			  nov_totalLeavers = "0"; 
    				  }
    				  else
    				  {
    				  rovdate11= rovdate11.replaceAll("^,+", "");
	              rov_date= rovdate11.replaceAll(",+$", "");
    	    			 
	              

   			   if(rov_date=="")
   			   {
   				       nov_Headcount = "0";
	    			   nov_totalJoiners = "0";
	    			   nov_totalLeavers = "0";
   			   }
        			  if(rov_date!="")
        			  {
        				  if(!rov_date.contains(","))
            			  {
        			   query = "select * from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ rov_date+"'" ;
        			   headcount_joiners_leavers_resultset = st.executeQuery(query);
    	    	  	   
        			   
        			   
    	    		  while(headcount_joiners_leavers_resultset.next())
    	    		  {
    	    			  
    	    			   nov_Headcount = headcount_joiners_leavers_resultset.getString(3);
    	    			   nov_totalJoiners = headcount_joiners_leavers_resultset.getString(4);
    	    			   nov_totalLeavers = headcount_joiners_leavers_resultset.getString(5);
    	    			 
    	    			  
    	    		  }
        			  }
        				  
        				  else
        				  {
        					  
        					  //headcount
        					  String[] rovdates_array= rov_date.split(",");
        					  String headcountDate = rovdates_array[rovdates_array.length-1];
        					  query = "select summaryviewdata.\"HeadCount\" from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ headcountDate+"'" ;
        	    			   headcount_joiners_leavers_resultset = st.executeQuery(query);
        		    	  	   
        	    			   
        	    			   
        		    		  while(headcount_joiners_leavers_resultset.next())
        		    		  {
        		    			   nov_Headcount = headcount_joiners_leavers_resultset.getString(1);
        		    			  
        		    		  }
        		    		  
        		    		  //total joiners and leavers
        		    		  String headcountDatesForMultiples = "('";
        		    		  for(int c=0;c<rovdates_array.length;c++)
        		    		  {
        		    		   headcountDatesForMultiples = headcountDatesForMultiples+rovdates_array[c]+"','";
        		    		  }
        		    		  headcountDatesForMultiples = headcountDatesForMultiples.replaceAll(",'+$", ")");
        		    		  
        					  query = "select SUM(summaryviewdata.\"TotalJoiners\"::numeric), SUM(summaryviewdata.\"TotalLeavers\"::numeric) from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" in"+ headcountDatesForMultiples ;
        					  headcount_joiners_leavers_resultset = st.executeQuery(query);
       		    	  	   
       	    			   
       	    			   
       		    		  while(headcount_joiners_leavers_resultset.next())
       		    		  {
       		    			   nov_totalJoiners = headcount_joiners_leavers_resultset.getString(1);
       		    			   nov_totalLeavers = headcount_joiners_leavers_resultset.getString(2);
       		    			  
       		    		  
        				  }
        			  }
        			  }
    				  }
    			  break;
    			  
    			  case(12):
    				  
    				  
    				  if(a==lastRovMonthNumber+1)
    				  {  
    					  Integer dec_average= (Integer.parseInt(jan_Headcount)+Integer.parseInt(feb_Headcount)+Integer.parseInt(mar_Headcount)+Integer.parseInt(apr_Headcount)+Integer.parseInt(may_Headcount)+Integer.parseInt(jun_Headcount)+Integer.parseInt(jul_Headcount)+Integer.parseInt(aug_Headcount)+Integer.parseInt(sep_Headcount)+Integer.parseInt(oct_Headcount)+Integer.parseInt(nov_Headcount))/11;
    					  
    					  dec_Headcount = dec_average.toString();
    					  dec_totalJoiners = "0";
		    			  dec_totalLeavers = "0";
    				  }
    				  else if(a==lastRovMonthNumber+2)
    				  {
    					  dec_Headcount =  nov_Headcount;
    					  dec_totalJoiners = "0";
		    			  dec_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+3)
    				  {
    					  dec_Headcount =  oct_Headcount;
    					  dec_totalJoiners = "0";
		    			  dec_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+4)
    				  {
    					  dec_Headcount =  sep_Headcount;
    					  dec_totalJoiners = "0";
		    			  dec_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+5)
    				  {
    					  dec_Headcount =  aug_Headcount;
    					  dec_totalJoiners = "0";
		    			  dec_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+6)
    				  {
    					  dec_Headcount =  jul_Headcount;
    					  dec_totalJoiners = "0";
		    			  dec_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+7)
    				  {
    					  dec_Headcount =  jun_Headcount;
    					  dec_totalJoiners = "0";
		    			  dec_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+8)
    				  {
    					  dec_Headcount =  may_Headcount;
    					  dec_totalJoiners = "0";
		    			  dec_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+9)
    				  {
    					  dec_Headcount =  apr_Headcount;
    					  dec_totalJoiners = "0";
		    			  dec_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+10)
    				  {
    					  dec_Headcount =  mar_Headcount;
    					  dec_totalJoiners = "0";
		    			  dec_totalLeavers = "0"; 
    				  }
    				  else if(a==lastRovMonthNumber+11)
    				  {
    					  dec_Headcount =  feb_Headcount;
    					  dec_totalJoiners = "0";
		    			  dec_totalLeavers = "0"; 
    				  }
    				  
    				  else
    				  {
    				  rovdate12= rovdate12.replaceAll("^,+", "");
	              rov_date= rovdate12.replaceAll(",+$", "");
    	    			 
	              
	              

   			   if(rov_date=="")
   			   {
   				       dec_Headcount = "0";
	    			   dec_totalJoiners = "0";
	    			   dec_totalLeavers = "0";
   			   }
   			   
        			  if(rov_date!="")
        			  {
        				  if(!rov_date.contains(","))
            			  {
        			   query = "select * from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ rov_date+"' and type = 'Contractor'" ;
        			   headcount_joiners_leavers_resultset = st.executeQuery(query);
    	    	  	   
        			   
        			   
    	    		  while(headcount_joiners_leavers_resultset.next())
    	    		  {
    	    			  
    	    			   dec_Headcount = headcount_joiners_leavers_resultset.getString(3);
    	    			   dec_totalJoiners = headcount_joiners_leavers_resultset.getString(4);
    	    			   dec_totalLeavers = headcount_joiners_leavers_resultset.getString(5);
    	    			 
    	    			  
    	    		  }
        			  }
        				  
        				  else
        				  {
        					  
        					  //headcount
        					  String[] rovdates_array= rov_date.split(",");
        					  String headcountDate = rovdates_array[rovdates_array.length-1];
        					  query = "select summaryviewdata.\"HeadCount\" from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and summaryviewdata.\"ROVReportDate\" = '"+ headcountDate+"' and type = 'Contractor'" ;
        	    			   headcount_joiners_leavers_resultset = st.executeQuery(query);
        		    	  	   
        	    			   
        	    			   
        		    		  while(headcount_joiners_leavers_resultset.next())
        		    		  {
        		    			   dec_Headcount = headcount_joiners_leavers_resultset.getString(1);
        		    			  
        		    		  }
        		    		  
        		    		  //total joiners and leavers
        		    		  String headcountDatesForMultiples = "('";
        		    		  for(int c=0;c<rovdates_array.length;c++)
        		    		  {
        		    		   headcountDatesForMultiples = headcountDatesForMultiples+rovdates_array[c]+"','";
        		    		  }
        		    		  headcountDatesForMultiples = headcountDatesForMultiples.replaceAll(",'+$", ")");
        		    		  
        					  query = "select SUM(summaryviewdata.\"TotalJoiners\"::numeric), SUM(summaryviewdata.\"TotalLeavers\"::numeric) from summaryviewdata where summaryviewdata.\"SVP\" = '"+svps_array[x] +"' and summaryviewdata.\"SeniorLeader\" = '"+rs_svp_senioleaders_arrayList.get(y)+ "' and type = 'Contractor' and summaryviewdata.\"ROVReportDate\" in"+ headcountDatesForMultiples ;
        					  headcount_joiners_leavers_resultset = st.executeQuery(query);
       		    	  	   
       	    			   
       	    			   
       		    		  while(headcount_joiners_leavers_resultset.next())
       		    		  {
       		    			   dec_totalJoiners = headcount_joiners_leavers_resultset.getString(1);
       		    			   dec_totalLeavers = headcount_joiners_leavers_resultset.getString(2);
       		    			  
       		    		  
        				  }
        			  }
        			  }
    				  }
    			  break;
    			  
    			  
    		  }
	    		  
	    		  
	    		 
	    	  }
	    	  String InsertQueryPerSVpPerSeniorLeader = "INSERT INTO public.finalSummaryViewContractorData (SVP, SeniorLeader, Jan_HeadCount, Jan_totalJoiners, Jan_TotalLeavers,Feb_HeadCount, Feb_TotalJoiners, Feb_TotalLeavers,Mar_HeadCount, Mar_TotalJoiners, Mar_TotalLeavers,Apr_HeadCount, Apr_TotalJoiners, Apr_TotalLeavers, May_HeadCount, May_TotalJoiners, May_TotalLeavers, Jun_HeadCount, Jun_TotalJoiners, Jun_TotalLeavers, Jul_HeadCount, Jul_TotalJoiners, Jul_TotalLeavers, Aug_HeadCount, Aug_TotalJoiners, Aug_TotalLeavers, Sep_HeadCount, Sep_TotalJoiners, Sep_TotalLeavers, Oct_HeadCount, Oct_TotalJoiners, Oct_TotalLeavers, Nov_HeadCount, Nov_TotalJoiners, Nov_TotalLeavers, Dec_HeadCount, Dec_TotalJoiners, Dec_TotalLeavers) Values ('"+ svps_array[x]+"','" + rs_svp_senioleaders_arrayList.get(y)+"','" + jan_Headcount+"','" + jan_totalJoiners+"','" + jan_totalLeavers+"','" + feb_Headcount+"','" + feb_totalJoiners+"','" + feb_totalLeavers+"','" + mar_Headcount+"','" + mar_totalJoiners+"','" + mar_totalLeavers+"','" + apr_Headcount+"','" + apr_totalJoiners+"','" + apr_totalLeavers+"','" + may_Headcount+"','" + may_totalJoiners+"','" + may_totalLeavers+"','" +jun_Headcount+"','" + jun_totalJoiners+"','" + jun_totalLeavers+"','" + jul_Headcount+"','" + jul_totalJoiners+"','" + jul_totalLeavers+"','" + aug_Headcount+"','" + aug_totalJoiners+"','" + aug_totalLeavers+"','" + sep_Headcount+"','" + sep_totalJoiners+"','" + sep_totalLeavers+"','" + oct_Headcount+"','" + oct_totalJoiners+"','" + oct_totalLeavers+"','" + nov_Headcount+"','" + nov_totalJoiners+"','" + nov_totalLeavers+"','" + dec_Headcount+"','" +  dec_totalJoiners+"','" +  dec_totalLeavers+"')";
    		  System.out.println(InsertQueryPerSVpPerSeniorLeader);
    		  try
    		  {
    		  st.execute(InsertQueryPerSVpPerSeniorLeader);
    		  }catch (Exception e) {

    				System.out.println("DriverManager.getConnection(dbURL) failed");
    				System.out.println();
    				e.printStackTrace();

    			}
    		  connection.commit();
    		  
    		  rovdates_arraylist.clear();
    		  rov_monthnumbers_arraylist.clear();
    		  rovdate1 = "";rovdate2 = "";rovdate3 = "";rovdate4 = "";rovdate5 = "";rovdate6 = "";rovdate7 = "";rovdate8 = "";rovdate9 = "";rovdate10 = "";rovdate11 = "";rovdate12="";
  			
   		   jan_Headcount=""; jan_totalJoiners=""; jan_totalLeavers=""; feb_Headcount="";feb_totalJoiners=""; feb_totalLeavers="";mar_Headcount=""; mar_totalJoiners=""; mar_totalLeavers=""; apr_Headcount=""; apr_totalJoiners=""; apr_totalLeavers=""; may_Headcount=""; may_totalJoiners=""; may_totalLeavers=""; jun_Headcount=""; jun_totalJoiners="";  jun_totalLeavers=""; jul_Headcount=""; jul_totalJoiners=""; jul_totalLeavers="";  aug_Headcount="";  aug_totalJoiners=""; aug_totalLeavers=""; sep_Headcount="";
   		   sep_totalJoiners=""; sep_totalLeavers=""; oct_Headcount=""; oct_totalJoiners=""; oct_totalLeavers="";  nov_Headcount="";  nov_totalJoiners="";  nov_totalLeavers="";  dec_Headcount="" ; dec_totalJoiners="";  dec_totalLeavers="";
   	  
   		
	    	  }
	    		  
	    		  rs_svp_senioleaders_arrayList.clear();
	    		  
	    		  }
	    	  
} catch (Exception ex) {

	System.out.println("DriverManager.getConnection(dbURL) failed");
	System.out.println();
	ex.printStackTrace();

}
		
		
		
		

	}

}
