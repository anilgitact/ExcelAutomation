package test.java.excel.tests;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;

import main.java.commonUtilityFunctions;





public class DriverScript {

	public static void main(String[] args) throws IOException, ParseException, SQLException {
		// TODO Auto-generated method stub
		
		String user = "postgres";
	    String password = "postgres";
		
		Connection connection = commonUtilityFunctions.connectToPostgresDB(user,password);
		

		
		connection.createStatement().execute("DROP TABLE if exists digitalrosterextract_06292022, digitalrosterextract_10262022, digitalrosterattrition_06292022, digitalrosterattrition_10262022, digitalrosterjoiners_06292022, digitalrosterjoiners_10262022, digitalrosterextract_07032022, digitalrosterattrition_07032022, digitalrosterjoiners_07032022, digitalrosterextract_08072022, digitalrosterextract_04282022, digitalrosterattrition_08072022, digitalrosterextract_05012022, digitalrosterjoiners_08072022, digitalrosterattrition_05012022, digitalrosterextract_09282022, digitalrosterjoiners_05012022, digitalrosterattrition_09282022, digitalrosterjoiners_09282022,digitalrosterjoiners_10262022,digitalrosterjoiners_11092022,  digitalrosterextract_11092022, digitalrosterattrition_11092022, digitalrosterjoiners_11092022;");

		connection.createStatement().execute("truncate cocoemployees, transferinoutsummary, loainoutsummary, summaryviewdata, summaryviewdatacolleagueids"); 
		CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","true");
		
		
		
		
		File directoryPath = new File("./resources/dump");
		String fileNames[] = directoryPath.list();
		ArrayList<String> arrayListOfFiles = new ArrayList<String>();
		for (int k = 0; k < fileNames.length; k++) {
             if(fileNames[k].contains(".xlsx"))
             {
			arrayListOfFiles.add(fileNames[k].split("_")[1]);
             }

			}
		Collections.sort(arrayListOfFiles);//, Collections.reverseOrder());
		
		for(int i=0;i<arrayListOfFiles.size();i++)
		{
		for(int x=0;x<fileNames.length;x++)
		{
		
			if(fileNames[x].contains(arrayListOfFiles.get(i)))
			{
				
				if(Files.exists(Paths.get("./resources/process/"+fileNames[x]))) { 
				    // do something
				}
				else
				{
					
					
					//delete all files in process folder and bring in file which needs to be processed
					
	        commonUtilityFunctions.cleanFolder("./resources/process/");
			commonUtilityFunctions.copyFile(new File("./resources/dump/"+fileNames[x]), new File("./resources/process/"+fileNames[x]));
				}
			CVSPushRosterToDBAndFindDiffAndAttrition.createRosterSheet();
			CVSPushRosterToDBAndFindDiffAndAttrition.PushRosterDataToDBAndFindDiff(connection);
			CVSPushRosterToDBAndFindDiffAndAttrition.compareAndFindAttritionAgainstExistingRosterTable(connection);
			CVSPushRosterToDBAndFindDiffAndAttrition.compareAndFindJoinersAgainstExistingRosterTable(connection);
			CVSPushSummayViewDataInDB.pushWeeklySummaryDataToDBForSVPWiseSummaryReport();
			
			//PrepareSummaryReport.prepareSVPWiseSummaryReportFromDBData();
			CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
			}
			
		}
			
		}
		CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","true");
		CVSPushSummayViewDataInDB.pushWeeklySummaryDataToDBForSVPWiseSummaryReportWithColleagueIds();
		CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","true");
		CVSPushSummayViewDataInDB.pushWeeklyTransferInOutDataToDBPerSVP(connection);
		CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","true");
		CVSPushSummayViewDataInDB.pushWeeklyLOAData(connection);
		//connect to DB
		
		
		/*// variables
		Connection connection = null;
		// Statement statement = null;
		ResultSet resultSet = null;

		// Step 1: Loading or registering Oracle JDBC driver class
		try {

			Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
		} catch (ClassNotFoundException cnfex) {

			System.out.println("Problem in loading or " + "registering MS Access JDBC driver");
			cnfex.printStackTrace();
		}

		// Step 2: Opening database connection
		try {

			String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
			String dbURL = "jdbc:ucanaccess://" + msAccDB;

			// Step 2.A: Create and get connection using DriverManager class
			connection = DriverManager.getConnection(dbURL);*/
		



   

	  //populate the internal final report table 
				
				
				
				
				/*String MonthWiseSummaryDataPerSVPInterimTableQuery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("MonthWiseSummaryDataPerSVPInterimTableQuery");
				CVSCompareDatabaseTablesTest.copyResultsetToTable(MonthWiseSummaryDataPerSVPInterimTableQuery, "interimfinalreporttable".trim(), connection, connection);		
		
				//create final report table
				
				String DigitalRosterExtractMonthwiseFinalReportQuery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("DigitalRosterExtractMonthwiseFinalReportQuery");
		        CVSPushRosterToDBAndFindDiffAndAttrition.PushRecordSetToExcel(DigitalRosterExtractMonthwiseFinalReportQuery,"FinalReport",connection,LocalDateTime.now().toString());*/
	}

}
