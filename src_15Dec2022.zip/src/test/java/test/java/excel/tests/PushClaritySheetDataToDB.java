package test.java.excel.tests;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.*;
import java.util.*;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.apache.poi.openxml4j.util.ZipSecureFile;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.monitorjbl.xlsx.StreamingReader;
//import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.extractor.XSSFBEventBasedExcelExtractor;
import org.apache.poi.xssf.extractor.XSSFEventBasedExcelExtractor;
import org.apache.poi.xssf.usermodel.*;

import main.java.commonUtilityFunctions;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;


/**
 *  code that imports data from an Excel file to MySQL database.
 *
 * @author Anil
 *
 */
public class PushClaritySheetDataToDB {
 
	
	//static String excelFilePath ="";
	static String createClarityTableQuery="";
	static String insertQuery ="";
	static int count = 0;

    public static void main() {
    	
    }
    	@SuppressWarnings("null")
		public static void pushClarityataToDB(String excelFilePath) throws IOException, ParseException
    	{
    		
    	int batchSize = 20;
    	// variables
    	Connection connection = null;
    			// Statement statement = null;
    			ResultSet resultSet = null;
    			  String user = "postgres";
    			    String password = "postgres";
    			
    			try {
    				
    				 connection = commonUtilityFunctions.connectToPostgresDB(user,password);
           
           long start = System.currentTimeMillis();
           File f = new File(excelFilePath); 
       	   Sheet firstSheet = null;
         
           if(f.exists() && f.isFile()) {
        	   
        	   System.out.println(excelFilePath + " -- file exists");
           }
           
          
          
            System.out.println("total rows in the sheet: "+firstSheet.getLastRowNum());
            Iterator<Row> rowIterator = firstSheet.iterator();
 
            connection.setAutoCommit(false);
            PreparedStatement statement = null; 
           
           if (connection != null) {
               Statement st3 = null;
               try {
                   st3 = (Statement) connection.createStatement();
               } catch (SQLException ex) {
                   Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
               }
               
               
               if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
		         {
             createClarityTableQuery =  "CREATE TABLE ClarityExtract( ID SERIAL PRIMARY KEY," + " PSEMPLOYEEID VARCHAR(255), " +  " EMPLOYEEFULLNAME VARCHAR(255), "  +  " EMPRESOURCEOBSL1 VARCHAR(255), " + " EMPMANAGERFULLNAME VARCHAR(255)," + " EMPTIMESHEETMONTH  VARCHAR(255)," +" EMPTIMESHEETSTOPWEEK   VARCHAR(255)," +" EMPACTUAL   VARCHAR(255),"+ " EMPRATE   VARCHAR(255),"+ " COSTPOOLNAME   VARCHAR(255),"+ " SEGMENT   VARCHAR(255)," +" FUNDINGSOURCE   VARCHAR(255) );";
		         }
            System.out.println(createClarityTableQuery);
               //   ResultSet rs3 = null;
               try { 
                    st3.execute(createClarityTableQuery);
               } catch (SQLException ex) {
                   Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
           
           
            //resultSet = statement1.execute(createTableQuery);
            connection.commit();
            
            
            
           
          if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
	         {
        	   insertQuery = "INSERT INTO ClarityExtract (PSEMPLOYEEID,EMPMANAGERFULLNAME, EMPRESOURCEOBSL1, EMPTIMESHEETMONTH ,EMPTIMESHEETSTOPWEEK , EMPACTUAL , EMPRATE , COSTPOOLNAME, SEGMENT ,FUNDINGSOURCE) VALUES (?, ?, ?,?, ?, ?,?, ?, ?)";
	         }
            
            
         //Digital roster extract
            
            
            //train roster extract
            
            
            statement = connection.prepareStatement(insertQuery);  
           
                	   if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
          	         {
                		   count = 0;
                           
                		   
                		   
                           rowIterator.next(); // skip the header row
                           while (rowIterator.hasNext()) {
                               Row nextRow = rowIterator.next();
                               Iterator<Cell> cellIterator = nextRow.cellIterator();
                               //for(int x=0;x<nextRow.getLastCellNum();x++) {
                               System.out.println(nextRow.getPhysicalNumberOfCells());
                               while (cellIterator.hasNext()) {
                                   Cell nextCell = cellIterator.next();
                                   
                                   int columnIndex = nextCell.getColumnIndex();
                
                                   switch (columnIndex) {
                                   
                                   case 4:
                                       String EMPLOYEEFULLNAME = nextCell.getStringCellValue();
                                       statement.setString(1, EMPLOYEEFULLNAME);
                                       break;
                                   case 8:
                                       String EMPRESOURCEOBSL1 = nextCell.getStringCellValue();
                                       statement.setString(2, EMPRESOURCEOBSL1);
                                       break;
                                   case 14:
                                       String EMPMANAGERFULLNAME = nextCell.getStringCellValue();
                                       statement.setString(3, EMPMANAGERFULLNAME);
                                       break;
                                   case 22:
                                   	nextCell.setCellType(CellType.STRING);
                                       String EMPTIMESHEETMONTH = nextCell.getStringCellValue();
                                       statement.setString(4, EMPTIMESHEETMONTH);
                                       break;
                                   case 24:
                                   	String EMPTIMESHEETSTOPWEEKSTRING =   nextCell.getStringCellValue();
                                   	
                                   	DateFormat df = new SimpleDateFormat("mm/dd/yyyy");
                  	  			    Date EMPTIMESHEETSTOPWEEK = df.parse(EMPTIMESHEETSTOPWEEKSTRING);
                                       statement.setString(5, EMPTIMESHEETSTOPWEEK.toString());
                                       break;
                                   case 27:
                                       String EMPACTUAL = nextCell.getStringCellValue();
                                       statement.setString(6, EMPACTUAL);
                                       break;
                                   case 29:
                                   	nextCell.setCellType(CellType.STRING);
                                       String EMPRATE = nextCell.getStringCellValue();
                                       statement.setString(7, EMPRATE);
                                       break;
                                   case 53:
                                       String PSEMPLOYEEID = nextCell.getStringCellValue();
                                       statement.setString(8, PSEMPLOYEEID);
                                       break;
                                   case 69:
                                       String COSTPOOLNAME = nextCell.getStringCellValue();
                                       statement.setString(9, COSTPOOLNAME);
                                       break;
                                   case 70:
                                   	nextCell.setCellType(CellType.STRING);
                                       String SEGMENT = nextCell.getStringCellValue();
                                       statement.setString(10, SEGMENT);
                                       break;
                                   case 71:
                                	   nextCell.setCellType(CellType.STRING);
                                       String FUNDINGSOURCE = nextCell.getStringCellValue();
                                       statement.setString(11, FUNDINGSOURCE);
                                       break;
                                                                         
                                   }
                
                               }  
                               statement.addBatch();
                               
                               if (count % batchSize == 0) {
                                   statement.executeBatch();
                               } 
          	         }
          	         }     
                            
 
            
 
            //wb.close();
             
            // execute the remaining queries
            statement.executeUpdate();
  
            connection.commit();
            //connection.close();
             
            long end = System.currentTimeMillis();
            System.out.printf("Import done in %d ms\n", (end - start));
             
        } catch (IOException ex1) {
            System.out.println("Error reading file");
            ex1.printStackTrace();
        } catch (SQLException ex2) {
            System.out.println("Database error");
            ex2.printStackTrace();
        }
 
    }
    
}