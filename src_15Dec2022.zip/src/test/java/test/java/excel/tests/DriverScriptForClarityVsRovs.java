package test.java.excel.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import main.java.commonUtilityFunctions;





public class DriverScriptForClarityVsRovs {

	public static void main(String[] args) throws IOException, ParseException, SQLException {
		// TODO Auto-generated method stub
		
		
		
		
		File directoryPath = new File("./resources/claritydump");
		String fileNames[] = directoryPath.list();
		ArrayList<String> arrayListOfFiles = new ArrayList<String>();
		arrayListOfFiles.clear();
		for (int k = 0; k < fileNames.length; k++) {
            
			if(fileNames[k].contains(".csv"))
			{
			arrayListOfFiles.add(fileNames[k]);
			}

			}
		
		csvfilesplit.csvfilesplitFiles("./resources/claritydump/");
		
		File splitFilesDirectoryPath = new File("./resources/claritydump/splitFiles");
		String splitFileNames[] = splitFilesDirectoryPath.list();
		ArrayList<String> arrayListOfSplitFiles = new ArrayList<String>();
		arrayListOfSplitFiles.clear();
		System.out.println("total split files count: "+splitFileNames.length);
		
     
		for (int k = 0; k < splitFileNames.length; k++) {
            
			System.out.println(splitFileNames[k]);	
			if(splitFileNames[k].contains(".csv"))
			{
			
			arrayListOfSplitFiles.add(splitFileNames[k]);
			}

			}
		
		
		 Statement st3 = null;
		 Statement st4 = null;
		 Statement st5 = null;
		 Statement st6 = null;
	 
	        int batchSize = 20;
	    	// variables
	    	Connection connection = null;
	  		// Statement statement = null;
  			ResultSet resultSet = null;
	    	String user = "postgres";
	    	String password = "postgres";
	        String createClarityTableQuery = "";
	        String createClarityVsROVsTableQuery = "";
	        int quaterForLastDateInClarity =0;
	        int quaterForCurrentDate =0;
	 
	       connection = commonUtilityFunctions.connectToPostgresDB(user,password);
	            
	       connection.setAutoCommit(false);
		
		//create clarity table
		
		 
        if (connection != null) {
           
            try {
                st3 = (Statement) connection.createStatement();
            } catch (SQLException ex) {
                Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
            }
            
           
           
			/*
			 * st3.execute("drop table  IF EXISTS  public.clarityextract CASCADE");
			 * 
			 * connection.commit(); if
			 * (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile(
			 * "RosterExtractName").contains("DigitalRosterExtract")) {
			 * createClarityTableQuery =
			 * "CREATE TABLE ClarityExtract( ID SERIAL PRIMARY KEY," +
			 * " PSEMPLOYEEID VARCHAR(255), " + "EMPLOYEEFULLNAME  VARCHAR(255), " +
			 * "EMPMANAGERFULLNAME VARCHAR(255), " + "EMPRESOURCEOBSL1 VARCHAR(255)," +
			 * "EMPTIMESHEETMONTH  VARCHAR(255)," +" EMPTIMESHEETSTOPWEEK   VARCHAR(255),"
			 * +" EMPACTUAL   VARCHAR(255),"+ " EMPRATE   VARCHAR(255),"+
			 * " COSTPOOLNAME   VARCHAR(255),"+ " SEGMENT   VARCHAR(255),"
			 * +" FUNDINGSOURCE   VARCHAR(255) );"; }
			 */
         //System.out.println(createClarityTableQuery);
            //   ResultSet rs3 = null;
            try { 
            	//st3.execute("drop table "+createClarityTableQuery.split("(")[0].split("TABLE")[1]);
                 //st3.execute("select count(*) from ClarityExtract");
                 st3.execute("truncate table  public.clarityextract");
                 st3.execute("truncate table  public.ClarityVsROVsExtract");
                 connection.commit();
                 //st3.execute(createClarityTableQuery);
            } catch (SQLException ex) {
                Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
		/*
		 * if (connection != null) {
		 * 
		 * 
		 * 
		 * 
		 * st3.execute("drop table  IF EXISTS  public.ClarityVsROVsExtract CASCADE");
		 * 
		 * if
		 * (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile(
		 * "RosterExtractName").contains("DigitalRosterExtract")) {
		 * createClarityVsROVsTableQuery =
		 * "CREATE TABLE ClarityVsROVsExtract( ID SERIAL PRIMARY KEY," +
		 * " PSEMPLOYEEID VARCHAR(255), " + " EMPLOYEENAMEINROV VARCHAR(255), " +
		 * " EMPLOYEENAMEINCLARITY VARCHAR(255), " + " EMPMANAGERINROV VARCHAR(255)," +
		 * " EMPMANAGERINCLARITY  VARCHAR(255)," +" ROVDATE   VARCHAR(255),"
		 * +" CLARITYLASTPAYMENTDATE   VARCHAR(255),"+
		 * " EMPLOYEESTATUS   VARCHAR(255) );"; }
		 * System.out.println(createClarityVsROVsTableQuery); // ResultSet rs3 = null;
		 * try {
		 * //st3.execute("drop table "+createClarityTableQuery.split("(")[0].split(
		 * "TABLE")[1]); st3.execute(createClarityVsROVsTableQuery);
		 * //st3.execute("select count(*) from ClarityVsROVsExtract"); } catch
		 * (SQLException ex) {
		 * Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.
		 * SEVERE, null, ex); } }
		 */
        //connection.commit();
		//Collections.sort(arrayListOfFiles);//, Collections.reverseOrder());
		
        
        
    	ArrayList<String>  listofDigitalRosterExtractTables = new ArrayList<String>();

			DatabaseMetaData dbmd = connection.getMetaData();
			try (ResultSet tables = dbmd.getTables(null, null, "%", new String[] { "TABLE" })) {
			    while (tables.next()) {
			    	if(tables.getString("TABLE_NAME").contains("digitalrosterextract_"))
			    	listofDigitalRosterExtractTables.add(tables.getString("TABLE_NAME"));
			        
			    }
			    
			 } catch (SQLException ex) {
             Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
         } 
			  Collections.sort(listofDigitalRosterExtractTables);
        
			
			  Collections.sort(arrayListOfSplitFiles);
		 for(int i=0;i<arrayListOfSplitFiles.size();i++) {
		  
			
			 
		  CVSPushClaritySheetDataToDB.pushClarityataToDB("./resources/claritydump/splitFiles/"+arrayListOfSplitFiles.get(i)); 
		  System.out.println("data from file "+arrayListOfSplitFiles.get(i)+" inserted into DB");
		  }
		 
		
		String clarityQueryPerEmployee = "select distinct(clarityextract.psemployeeid), clarityextract.employeefullname,clarityextract.empmanagerfullname from clarityextract";
		
		          // variables
    	 
    			
    			// Step 2: Opening database connection
    			try {

    		connection = commonUtilityFunctions.connectToPostgresDB(user,password);
            // Step 2.B: Creating JDBC Statement 
          
            connection.setAutoCommit(false);
            
           
           if (connection != null) {
               try {
                   st5 = connection.createStatement();
               } catch (SQLException ex) {
                   Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
               }
             
               try {
            	   ResultSet employeeResultset = st5.executeQuery(clarityQueryPerEmployee);
                    
 	    	  	   
     			   String lastDateInClarity ="";
     			   
  	    		  while(employeeResultset.next())
  	    		  {
  	    			st4 = connection.createStatement();
  	    			   String empid = employeeResultset.getString(1);
  	    			 String employeeFullNameInClarity = employeeResultset.getString(2);
  	    			String employeeManagerFullNameInClarity = employeeResultset.getString(3);
  	    			   
  	    			 String clarityQueryPerEmployeeWithMaxDate = "SELECT clarityextract.psemployeeid, max(clarityextract.emptimesheetstopweek) AS MAXDATE FROM clarityextract WHERE clarityextract.psemployeeid='"+empid+"'GROUP BY clarityextract.psemployeeid";
  	    					 
  	    			 ResultSet clarityEmployeeResultsetWithMaxDate = st4.executeQuery(clarityQueryPerEmployeeWithMaxDate);
  	                 
  	    			
  	  				 while(clarityEmployeeResultsetWithMaxDate.next())
  	  				 {
  	  					 lastDateInClarity = clarityEmployeeResultsetWithMaxDate.getString(2);
  	  				 System.out.println(lastDateInClarity);
  	  				 }
  	  			
  	  			     String monthName = lastDateInClarity.substring(4,7);
  	  			    
  	  			     switch(monthName)
  	  			     {
  	  			 
  	  			     case "Jan":
  	  			    	  quaterForLastDateInClarity = Integer.parseInt("1");
  	  			    	 break;
  	  			     case "Feb":
  	  			    	 quaterForLastDateInClarity = Integer.parseInt("1");
	  			    	 break;
  	  		        case "Mar":
  	  		         quaterForLastDateInClarity = Integer.parseInt("1");
			    	     break;
  	  		    case "Apr":
  	  		     quaterForLastDateInClarity = Integer.parseInt("2");
	  			    	break;
  	  		 case "May":
  	  			 quaterForLastDateInClarity = Integer.parseInt("2");
			    	 break;
  	  	 case "Jun":
  	  		 quaterForLastDateInClarity = Integer.parseInt("2");
		    	 break;
  	   case "Jul":
  		  quaterForLastDateInClarity = Integer.parseInt("3");
		    	 break;
  	 case "Aug":
  		 quaterForLastDateInClarity = Integer.parseInt("3");
	    	 break;
  	 case "Sep":
  		 quaterForLastDateInClarity = Integer.parseInt("3");
	    	 break;
  	 case "Oct":
  		 quaterForLastDateInClarity = Integer.parseInt("4");
	    	 break;
	    	 
	    	 
  	 case "Nov":
  		 quaterForLastDateInClarity = Integer.parseInt("4");
  	 case "Dec":
  		 quaterForLastDateInClarity = Integer.parseInt("4");
  	  			     }
  	  			
					try {
					 quaterForCurrentDate = commonUtilityFunctions.getQuaterForCurrentDate();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				 
  				  String empNameInRov = "";
    			  String managerNameInRov = "";
    			  String RovDate = "";
    			  String employeeStatus = "";
    			  boolean flag= false;
  				 for(int i=0;i<listofDigitalRosterExtractTables.size();i++)
  				 {
  					
  					 if(flag)
  					 {
  						 break;
  					 }
  					 
  					//String EmpToBeSearchedInRovsQuery = "select count(*) from "+listofDigitalRosterExtractTables.get(i)+" where colleagueid='"+empid+"'";
  					String EmpToBeSearchedInRovsQuery = "select count(*) from "+listofDigitalRosterExtractTables.get(i)+" where colleagueid='"+empid+"'";
  					ResultSet employeeInRovsResultset = st3.executeQuery(EmpToBeSearchedInRovsQuery);
                    
  					
  					while(employeeInRovsResultset.next())
  					{
  						 if(flag)
  	  					 {
  	  						 break;
  	  					 }
  	  					 
  	    	  	    if(Integer.parseInt(employeeInRovsResultset.getString(1)) ==1)
  	    	  	    {
  	    	  	    st6 = connection.createStatement();
  	    	  	    String foundEmployeeInRovsQuery = "select colleaguename,manager from "+listofDigitalRosterExtractTables.get(i)+" where colleagueid='"+empid+"'";
  					ResultSet foundEmployeeInRovsResultset = st6.executeQuery(foundEmployeeInRovsQuery);
  					
  					
  					while(foundEmployeeInRovsResultset.next())
  					{
  				
      			   
    	    			   empNameInRov = foundEmployeeInRovsResultset.getString(1);
    	    			   managerNameInRov = foundEmployeeInRovsResultset.getString(2);
    	    			   RovDate = listofDigitalRosterExtractTables.get(i).split("digitalrosterextract_")[1];
    	    			   if(quaterForLastDateInClarity == quaterForCurrentDate)
    	    			   {
    	    			   employeeStatus = "Active";
    	    			   }
    	    			   else
    	    			   {
    	    				   employeeStatus = "InActive";  
    	    			   }
    	    			   PushClartityAndRovDataIntoDiscrepancyReport.pushClarityVsROVsDataToDB(empid, empNameInRov, employeeFullNameInClarity, managerNameInRov, employeeManagerFullNameInClarity, RovDate, lastDateInClarity, employeeStatus, connection);
    	    			   flag= true;
  					}
  	    	  	    }
  	    	  	    
  	    	  	    else
  	    	  	    {
  	    	  	        empNameInRov = "Employee not found in all ROVs";
	    			    managerNameInRov = "Employee not found in all ROVs";
	    			    employeeStatus = "InActive";
  	    	  	        RovDate = "Employee not found in all ROVs";
  	    	  	    }
  	    	  	    
  	    	  	    
  	    	  	
  					}
  					
  					
  					
  				 }
  				 
  				 if(flag)
					 {
					 }
  				 else
  					 
  				 {
  				PushClartityAndRovDataIntoDiscrepancyReport.pushClarityVsROVsDataToDB(empid, empNameInRov, employeeFullNameInClarity, managerNameInRov, employeeManagerFullNameInClarity, RovDate, lastDateInClarity, employeeStatus, connection);
  				 }
  				 
  				
  	    		  }
               
  	    		  //connection.close();
               } catch (SQLException ex) {
                   Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
    			 } catch (SQLException ex) {
                     Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
                 }		
	}
}
    			



