package test.java.excel.tests;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;  
public class csvfilesplit
{
    
	public static void main(String[] args) throws IOException {
	}
	
	public static void csvfilesplitFiles(String folderPath) throws IOException
	{
		
		File directoryPath = new File(folderPath);
		String fileNames[] = directoryPath.list();
		ArrayList<String> arrayListOfFiles = new ArrayList<String>();
		arrayListOfFiles.clear();
		for (int k = 0; k < fileNames.length; k++) {
            
			if(fileNames[k].contains(".csv"))
			{
			arrayListOfFiles.add(fileNames[k]);
			}

			}
		int x=1;
		for(int i=0;i<arrayListOfFiles.size();i++)
		{
			
        //first read the file
        String inputfile = folderPath+arrayListOfFiles.get(i).toString();
        BufferedReader br = new BufferedReader(new FileReader(inputfile)); 
        
        
        //create thje first file which will have 1000 lines
        File file = new File("./resources/claritydump/FileNumber_"+x+".csv");
         FileWriter fstream1 = new FileWriter(file);
         BufferedWriter out = new BufferedWriter(fstream1);  
            String line="";
            //count the number of line
            int count=1;
            int file_Number=x+1;
            while ((line = br.readLine()) != null) 
            {
                //if the line is divided by 1000 then create a new file with file count
                if(count % 100000 == 0)
                {
                    File newFile = new File(folderPath+"/splitFiles/FileNumber_"+file_Number+".csv");
                    fstream1 = new FileWriter(newFile);
                    file_Number++;
                    out = new BufferedWriter(fstream1); 
                    x++;
                }
                 //if(line.indexOf(",")!=-1)
                 //line=line.substring(0, line.indexOf(","));
                 out.write(line);
                 out.newLine();
                count++;
            }

}
	}
	
}