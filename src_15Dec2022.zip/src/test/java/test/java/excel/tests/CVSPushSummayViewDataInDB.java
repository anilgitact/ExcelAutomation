package test.java.excel.tests;

import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.testng.annotations.Test;

import main.java.commonUtilityFunctions;

public class CVSPushSummayViewDataInDB {

	public static void main(String[] args) throws SQLException, IOException {
		// TODO Auto-generated method stub
	}
		
	@Test
		public static void pushWeeklySummaryDataToDBForSVPWiseSummaryReport() throws IOException, SQLException, ParseException
		{
			
			try
			{
		File directoryPath = new File("./resources/process/");
		// List of all files and directories
		String fileNames[] = directoryPath.list();
		String weeklyDigitalExtractHeadCountQuery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("WeeklySummaryViewDataCountJoinersLeaversQuery");
		String FirstSheetHeadCountJoinerLeaversQuery ="";
		String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
		if(firstReportWorkBook.contains("true"))
		{
			FirstSheetHeadCountJoinerLeaversQuery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("FirstSheetHeadCountJoinerLeaversQuery");
			FirstSheetHeadCountJoinerLeaversQuery = FirstSheetHeadCountJoinerLeaversQuery.replaceAll("ROVWeekDate", fileNames[0].split("_")[1].replaceAll("-", ""));
		}
		else
		{
		weeklyDigitalExtractHeadCountQuery = weeklyDigitalExtractHeadCountQuery.replaceAll("ROVWeekDate",fileNames[0].split("_")[1].replaceAll("-", ""));
		}
		/*// variables
				Connection connection = null;
				// Statement statement = null;
				ResultSet resultSet = null;

				// Step 1: Loading or registering Oracle JDBC driver class
				try {

					Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
				} catch (ClassNotFoundException cnfex) {

					System.out.println("Problem in loading or " + "registering MS Access JDBC driver");
					cnfex.printStackTrace();
				}

				// Step 2: Opening database connection
				try {

					String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
					String dbURL = "jdbc:ucanaccess://" + msAccDB;

					// Step 2.A: Create and get connection using DriverManager class
					connection = DriverManager.getConnection(dbURL);*/
		
		
		// variables
		Connection connection  = null;
				// Statement statement = null;
				ResultSet resultSet = null;
				  String user = "postgres";
				    String password = "postgres";
				/*
				 * // Step 1: Loading or registering Oracle JDBC driver class try {
				 * 
				 * Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); } catch
				 * (ClassNotFoundException cnfex) {
				 * 
				 * System.out.println("Problem in loading or " +
				 * "registering MS Access JDBC driver"); cnfex.printStackTrace(); }
				 */
				// Step 2: Opening database connection
				try {

					/*
					 * String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
					 * String dbURL = "jdbc:ucanaccess://" + msAccDB;
					 * 
					 * // Step 2.A: Create and get connection using DriverManager class connection =
					 * DriverManager.getConnection(dbURL);
					 */

					connection = commonUtilityFunctions.connectToPostgresDB(user,password);

				} catch (Exception ex) {

					System.out.println("DriverManager.getConnection(dbURL) failed");
					System.out.println();
					ex.printStackTrace();

				}
		//create the diff table
		   if (connection != null) {
	           Statement st3 = null;
	           try {
	               st3 = (Statement) connection.createStatement();
	           } catch (SQLException ex) {
	               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
	               //connection.close();
	           }
	           
	        
	           //String createDiffTableQuery= CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("createDigitalExtractDiffTableQuery");
	           //   ResultSet rs3 = null;
	           try { 
	        	   
	        	   if(firstReportWorkBook.contains("false"))
	        	   {
	                //st3.execute(weeklyDigitalExtractHeadCountQuery);
	                CVSCompareDatabaseTablesTest.copyResultsetToTable(weeklyDigitalExtractHeadCountQuery, "SummaryViewData".trim(), connection, connection);
	                System.out.println("Summary View Data for week "+fileNames[0].split("_")[1].replaceAll("-", "")+" pushed to DB");
	                //connection.close();
	        	   }
	        	   
	        	   } catch (Exception  ex) {
	        	   
	        	  if (ex.getMessage().contains("object not found:") || ex.getMessage().contains("does not exist"))
	        			  {
	        			  System.out.println("DIGITALROSTERATTRITION_mmddyyyy table not present in DB for  week "+fileNames[0].split("_")[1]+"-Hence DB-SummaryViewData table will have 0 values");
	        			  }
	        	  //connection.close();
	        	 
	               //Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
	           }
	           finally {
	        	   if(firstReportWorkBook.contains("true"))
	       		{
	        		   
	        	   CVSCompareDatabaseTablesTest.copyResultsetToTable(FirstSheetHeadCountJoinerLeaversQuery, "SummaryViewData".trim(), connection, connection);
	        	   //CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
	                System.out.println("Summary View Data for week "+fileNames[0].split("_")[1].replaceAll("-", "")+" pushed to DB");
	       		}
	        	   //connection.close();
	        	  }
	       }
	       
			 } catch (SQLException ex) {
	               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
	               System.out.println("some issues pushing the sumary view resultset to DB table: SummaryViewData");
	               
	           }
	}
	
	
	public static void pushWeeklySummaryDataToDBForSVPWiseSummaryReportWithColleagueIds() throws IOException, SQLException
	{
		
		String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
		
		
		             // variables
				       Connection connection  = null;
						// Statement statement = null;
						ResultSet resultSet = null;
						  String user = "postgres";
						    String password = "postgres";
						    ResultSet rs = null;
						
						// Step 2: Opening database connection
						try {

							

							connection = commonUtilityFunctions.connectToPostgresDB(user,password);

						} catch (Exception ex) {

							System.out.println("DriverManager.getConnection(dbURL) failed");
							System.out.println();
							ex.printStackTrace();

						}
				//create the diff table
				   if (connection != null) {
			           Statement st3 = null;
			           Statement st4 = null;
			           String summaryReportLinearFormatWithColleagueIdsQuery ="";
			           String FirstSheetHeadCountJoinerLeaversColleagueIdsQuery ="";
			           try {
			               st3 = (Statement) connection.createStatement();
			               st4 = (Statement) connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
			           } catch (SQLException ex) {
			               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
			               //connection.close();
			           }
			           
			        
			           //String createDiffTableQuery= CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("createDigitalExtractDiffTableQuery");
			           //   ResultSet rs3 = null;
			           try { 
			        	   
			        	   st3.execute("truncate summaryviewdatacolleagueids");
			        	    rs =  st4.executeQuery("select * from summaryviewdata order by summaryviewdata.\"ROVReportDate\" ASC");
			        	    
			        	   
			        	    while(rs.next())
			        	    {
			        	    	 summaryReportLinearFormatWithColleagueIdsQuery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("summaryReportLinearFormatWithColleagueIdsQuery");
					       		    FirstSheetHeadCountJoinerLeaversColleagueIdsQuery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("FirstSheetHeadCountJoinerLeaversColleagueIdsQuery");
					        	    
			        	    	System.out.println(rs.getString(1)+":"+rs.getString(2)+":"+rs.getString(3)+":"+rs.getString(4)+":"+rs.getString(8));
			        	    	if(rs.getString(8).contains("04282022"))
			        	    			{
			        	    		CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","true");
			        	    			}
			        	    	else
			        	    	{
			        	    		CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
			        	    	}
			        	    	
			        	    	firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
			        	    	 if(firstReportWorkBook.contains("false"))
			  	        	   {
			        	    	summaryReportLinearFormatWithColleagueIdsQuery = summaryReportLinearFormatWithColleagueIdsQuery.replaceAll("ROVDATE", rs.getString(8));
			        	    	summaryReportLinearFormatWithColleagueIdsQuery = summaryReportLinearFormatWithColleagueIdsQuery.replaceAll("SVPNAME", rs.getString(4));
			        	    	summaryReportLinearFormatWithColleagueIdsQuery = summaryReportLinearFormatWithColleagueIdsQuery.replaceAll("SENIORLEADERNAME", rs.getString(3));
			        	    	summaryReportLinearFormatWithColleagueIdsQuery = summaryReportLinearFormatWithColleagueIdsQuery.replaceAll("SUPERVISOR6NAME", rs.getString(2));
			        	    	summaryReportLinearFormatWithColleagueIdsQuery = summaryReportLinearFormatWithColleagueIdsQuery.replaceAll("EMPTYPE", rs.getString(1));
			        	    	
			        	    	
			        	    	
			        	    	
			                CVSCompareDatabaseTablesTest.copyResultsetToTable(summaryReportLinearFormatWithColleagueIdsQuery, "summaryviewdatacolleagueids".trim(), connection, connection);
			                summaryReportLinearFormatWithColleagueIdsQuery="";
			        	    }
			        	    	 
			        	    	 else
			        	    	 {
			        	    		 
			        	    		 FirstSheetHeadCountJoinerLeaversColleagueIdsQuery = FirstSheetHeadCountJoinerLeaversColleagueIdsQuery.replaceAll("ROVDATE", rs.getString(8));
			        	    		 FirstSheetHeadCountJoinerLeaversColleagueIdsQuery = FirstSheetHeadCountJoinerLeaversColleagueIdsQuery.replaceAll("SVPNAME", rs.getString(4));
			        	    		 FirstSheetHeadCountJoinerLeaversColleagueIdsQuery = FirstSheetHeadCountJoinerLeaversColleagueIdsQuery.replaceAll("SENIORLEADERNAME", rs.getString(3));
			        	    		 FirstSheetHeadCountJoinerLeaversColleagueIdsQuery = FirstSheetHeadCountJoinerLeaversColleagueIdsQuery.replaceAll("SUPERVISOR6NAME", rs.getString(2));
			        	    		 FirstSheetHeadCountJoinerLeaversColleagueIdsQuery = FirstSheetHeadCountJoinerLeaversColleagueIdsQuery.replaceAll("EMPTYPE", rs.getString(1));
						        		   
			  			        	   CVSCompareDatabaseTablesTest.copyResultsetToTable(FirstSheetHeadCountJoinerLeaversColleagueIdsQuery, "summaryviewdatacolleagueids".trim(), connection, connection);
			  			        	   //CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
			  			        	 FirstSheetHeadCountJoinerLeaversColleagueIdsQuery ="";
			  			       		
			        	    	 }
			              
			        	   
			        	    }
			        	    System.out.println("HeadCountColleagueIds for all records in SummaryViewData table  pushed to DB");
			                //connection.close();
			        	   } catch (Exception  ex) {
			        	   
			        	  if (ex.getMessage().contains("object not found:") || ex.getMessage().contains("does not exist"))
			        			  {
			        			  System.out.println("DIGITALROSTERATTRITION_mmddyyyy table not present in DB for  week "+rs.getString(8)+"-Hence DB-SummaryViewData table will have 0 values");
			        			  }
			        	  
			        	 
			               //Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
			           }
			           finally {
			        	   if(firstReportWorkBook.contains("true"))
			       		{
			        		   
			        	   CVSCompareDatabaseTablesTest.copyResultsetToTable(FirstSheetHeadCountJoinerLeaversColleagueIdsQuery, "summaryviewdatacolleagueids".trim(), connection, connection);
			        	   //CVSPushRosterToDBAndFindDiffAndAttrition.setPropertyValueInPropertyFile("firstReportWorkBook","false");
			                System.out.println("Summary View Data for week "+rs.getString(8)+" pushed to DB");
			       		}
			        	  
			        	  }
			           //connection.close();
			        	   
			        	  }
			       }
			       
	
	
	public static void pushWeeklyTransferInOutDataToDBPerSVP(Connection connection) throws IOException, SQLException, ParseException
	{
		
		
		  Statement st3 = null;
          Statement st4 = null;
          String transferinoutquery ="";
		String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
		
		
		ArrayList<String> listofTable = null;
		ArrayList<String> listofDigitalExtractTable = null;
		ArrayList<String> DigitalRosterExtractTableNameDates = new ArrayList<String>();
		
		listofTable = new ArrayList<String>();

	
		DatabaseMetaData dbmd = connection.getMetaData();
		try (ResultSet tables = dbmd.getTables(null, null, "%", new String[] { "TABLE" })) {
		    while (tables.next()) {
		    	listofTable.add(tables.getString("TABLE_NAME"));
		        System.out.println(tables.getString("TABLE_NAME"));
		    }
		}
		
		 if(CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
	        {
		for (int k = 0; k < listofTable.size(); k++) {

			if (listofTable.get(k).contains("digitalrosterextract_")) {
				DigitalRosterExtractTableNameDates.add(listofTable.get(k).split("_")[1]);

			}
		    }
	        } 
		 
		// sort the table names
         if(!DigitalRosterExtractTableNameDates.isEmpty())
         {
        	 
        	 
        	 
			Collections.sort(DigitalRosterExtractTableNameDates);
			
			
			for(int x=0;x<DigitalRosterExtractTableNameDates.size()-1;x++)
			{
				if (new SimpleDateFormat("MM/dd/yyyy").parse(DigitalRosterExtractTableNameDates.get(x+1).substring(0,2)+"/"+DigitalRosterExtractTableNameDates.get(x+1).substring(2,4)+"/"+DigitalRosterExtractTableNameDates.get(x+1).substring(4,8))
						.after(new SimpleDateFormat("MM/dd/yyyy").parse(DigitalRosterExtractTableNameDates.get(x).substring(0,2)+"/"+DigitalRosterExtractTableNameDates.get(x).substring(2,4)+"/"+DigitalRosterExtractTableNameDates.get(x).substring(4,8))))
				
				{
					
					
					
					
					 transferinoutquery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("transferinoutquery");
					 
					 transferinoutquery=  transferinoutquery.replaceAll("existingTable", "digitalrosterextract_"+DigitalRosterExtractTableNameDates.get(x));
					 transferinoutquery=  transferinoutquery.replaceAll("newtablename", "digitalrosterextract_"+DigitalRosterExtractTableNameDates.get(x+1));
					 transferinoutquery=  transferinoutquery.replaceAll("existingtablerovdate", DigitalRosterExtractTableNameDates.get(x));
					 transferinoutquery=  transferinoutquery.replaceAll("newtablerovdate", DigitalRosterExtractTableNameDates.get(x+1));
					 
			           try {
			        	   st4 = connection.createStatement();
			               st3 = (Statement) connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
			           } catch (SQLException ex) {
			               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
			               //connection.close();
			           }
			           
			           
			           
			         // ResultSet rs =  st3.executeQuery(transferinoutquery);
			          
			          CVSCompareDatabaseTablesTest.copyResultsetToTable(transferinoutquery, "transferinoutsummary".trim(), connection, connection);
			          transferinoutquery="";
			           
					
				}
				
			
			
         
			}
         }
	}
			       

	
	
	
	
	public static void pushWeeklyLOAData(Connection connection) throws IOException, SQLException, ParseException
	{
		
		
		  Statement st3 = null;
          Statement st4 = null;
          String LOAQuery ="";
		String firstReportWorkBook = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("firstReportWorkBook");
		
		String listoffoundcolleagueids = "";
		ArrayList<String> listofTable = null;
		ArrayList<String> listofDigitalExtractTable = null;
		ArrayList<String> DigitalRosterExtractTableNameDates = new ArrayList<String>();
		ArrayList<String> DigitalRosterAttritionTableNameDates = new ArrayList<String>();
		ResultSet rs = null;
		ResultSet rs1 = null;
		
		listofTable = new ArrayList<String>();

	
		DatabaseMetaData dbmd = connection.getMetaData();
		try (ResultSet tables = dbmd.getTables(null, null, "%", new String[] { "TABLE" })) {
		    while (tables.next()) {
		    	listofTable.add(tables.getString("TABLE_NAME"));
		        System.out.println(tables.getString("TABLE_NAME"));
		    }
		}
		
		 if(CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
	        {
		for (int k = 0; k < listofTable.size(); k++) {

			if (listofTable.get(k).contains("digitalrosterextract_")) {
				DigitalRosterExtractTableNameDates.add(listofTable.get(k).split("_")[1]);

			}
			else
				if (listofTable.get(k).contains("digitalrosterattrition_")) {
					DigitalRosterAttritionTableNameDates.add(listofTable.get(k).split("_")[1]);

				}
		    }
	        } 
		 
		// sort the table names
         if(!DigitalRosterAttritionTableNameDates.isEmpty())
         {
        	 
        	 
        	Collections.sort(DigitalRosterAttritionTableNameDates); //05012022,06292022,07032022
			Collections.sort(DigitalRosterExtractTableNameDates); //04282022,05012022,06292022,07032022
			
			
			for(int x=0;x<DigitalRosterAttritionTableNameDates.size()-1;x++)
			{
				for(int y=2;y<DigitalRosterExtractTableNameDates.size();y++)
				{
					
					
					System.out.println(new SimpleDateFormat("MM/dd/yyyy").parse(DigitalRosterExtractTableNameDates.get(y).substring(0,2)+"/"+DigitalRosterExtractTableNameDates.get(y).substring(2,4)+"/"+DigitalRosterExtractTableNameDates.get(y).substring(4,8)));
					System.out.println(new SimpleDateFormat("MM/dd/yyyy").parse(DigitalRosterAttritionTableNameDates.get(x).substring(0,2)+"/"+DigitalRosterAttritionTableNameDates.get(x).substring(2,4)+"/"+DigitalRosterAttritionTableNameDates.get(x).substring(4,8)));
				if (new SimpleDateFormat("MM/dd/yyyy").parse(DigitalRosterExtractTableNameDates.get(y).substring(0,2)+"/"+DigitalRosterExtractTableNameDates.get(y).substring(2,4)+"/"+DigitalRosterExtractTableNameDates.get(y).substring(4,8))
						.after(new SimpleDateFormat("MM/dd/yyyy").parse(DigitalRosterAttritionTableNameDates.get(x).substring(0,2)+"/"+DigitalRosterAttritionTableNameDates.get(x).substring(2,4)+"/"+DigitalRosterAttritionTableNameDates.get(x).substring(4,8))))
				
				{
					
					
					
					
					LOAQuery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("LOAQuery");
					 
					LOAQuery=  LOAQuery.replaceAll("attritionROVDate", DigitalRosterAttritionTableNameDates.get(x));
					LOAQuery=  LOAQuery.replaceAll("extractROVDate", DigitalRosterExtractTableNameDates.get(y));
					LOAQuery=  LOAQuery.replaceAll("listoffoundcolleagueids", listoffoundcolleagueids);
					System.out.println(LOAQuery);
					st4 = connection.createStatement();
					rs1 = st4.executeQuery("select colleagueid from digitalrosterextract_"+DigitalRosterExtractTableNameDates.get(y));
			          while(rs1.next())
			          {
			        	  if(rs1.getString(1).contains("2046719"))
			        			  {
			        		  System.out.println("hello");
			        			  }
			          }
					 
			           try {
			        	   st4 = connection.createStatement();
			               st3 = (Statement) connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE,ResultSet.CONCUR_READ_ONLY);
			           } catch (SQLException ex) {
			               Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
			               //connection.close();
			           }
			           
			           
			           
			         // ResultSet rs =  st3.executeQuery(transferinoutquery);
			           if(!LOAQuery.contains("('')"))
			           {
			        	   LOAQuery = LOAQuery.replaceAll("''", "'"); 
			           }
			          
			          CVSCompareDatabaseTablesTest.copyResultsetToTable(LOAQuery, "loainoutsummary".trim(), connection, connection);
			          rs = st4.executeQuery("select distinct colleagueid from loainoutsummary");
			          while(rs.next())
			          {
			        	  listoffoundcolleagueids = "'"+ rs.getString(1)+"',"+listoffoundcolleagueids;
			          }
			          listoffoundcolleagueids= listoffoundcolleagueids.replaceAll("^(,|\\s)*|(,|\\s)*$", "").replaceAll("(\\,\\s*)+", ",");
			          LOAQuery="";
			           
					
				}
				
			}
				listoffoundcolleagueids="";
         
			}
         }
	}
			 
	
	}

