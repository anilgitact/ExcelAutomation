package test.java.excel.tests;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

//import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;

import main.java.commonUtilityFunctions;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


/**
 * Sample Java program that imports data from an Excel file to MySQL database.
 *
 * @author Nam Ha Minh - https://www.codejava.net
 *
 */
public class CVSRosterExcel2DatabaseTest {
 
	
	static String excelFilePath ="";
	static String createTableQuery="";
	static String insertQuery ="";
	static int count = 0;
    public static void main() {
    	
    }
    	@SuppressWarnings("null")
		public static void pushDataToDB(String fileDate) throws IOException
    	{
    		if(CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("TrainRosterExtract"))
    		{
    	 excelFilePath = "./resources/TrainRosters/trainRoster_"+fileDate.replaceAll("-", "")+".xlsx";
    		}
    		else
    			if(CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
        		{
        	 excelFilePath = "./resources/digitalRosters/digitalRoster_"+fileDate.replaceAll("-", "")+".xlsx";
        		}
    	int batchSize = 20;
    	/*  // variables
        Connection connection = null;
        //Statement statement = null;
        boolean resultSet = false;
        Statement statement1 = null;

        // Step 1: Loading or registering Oracle JDBC driver class
        try {

            Class.forName("net.ucanaccess.jdbc.UcanaccessDriver");
        }
        catch(ClassNotFoundException cnfex) {

            System.out.println("Problem in loading or "
                    + "registering MS Access JDBC driver");
            cnfex.printStackTrace();
        }

        // Step 2: Opening database connection
        try {

            String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
            String dbURL = "jdbc:ucanaccess://" + msAccDB; 

            // Step 2.A: Create and get connection using DriverManager class
            connection = DriverManager.getConnection(dbURL); */
    	
    	// variables
    	Connection connection = null;
    			// Statement statement = null;
    			ResultSet resultSet = null;
    			  String user = "postgres";
    			    String password = "postgres";
    			/*
    			 * // Step 1: Loading or registering Oracle JDBC driver class try {
    			 * 
    			 * Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); } catch
    			 * (ClassNotFoundException cnfex) {
    			 * 
    			 * System.out.println("Problem in loading or " +
    			 * "registering MS Access JDBC driver"); cnfex.printStackTrace(); }
    			 */
    			// Step 2: Opening database connection
    			try {

    				/*
    				 * String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
    				 * String dbURL = "jdbc:ucanaccess://" + msAccDB;
    				 * 
    				 * // Step 2.A: Create and get connection using DriverManager class connection =
    				 * DriverManager.getConnection(dbURL);
    				 */

    				 connection = commonUtilityFunctions.connectToPostgresDB(user,password);


            // Step 2.B: Creating JDBC Statement 
            //statement = connection.createStatement();
           long start = System.currentTimeMillis();
           File f = new File(excelFilePath); 
           if(f.exists() && f.isFile()) {
        	   
        	   System.out.println("file exists");
           }
           
           
            FileInputStream inputStream = new FileInputStream(excelFilePath);
 
            Workbook workbook = new XSSFWorkbook(inputStream);
 
            Sheet firstSheet = workbook.getSheetAt(0);
            System.out.println("total rows in the sheet: "+firstSheet.getLastRowNum());
            Iterator<Row> rowIterator = firstSheet.iterator();
 
            //connection = DriverManager.getConnection(dbURL);
            //connection.setAutoCommit(false);
            
            //statement1 = connection.createStatement();
            //create new table in DB
            
          
            //String createTableQuery =  "CREATE TABLE TrainRosterExtract_"+fileDate.replaceAll("-", "") +"( QBSource CHAR (30), Solution CHAR (30), Train CHAR (30), ColleagueID CHAR (20), AllocationPercentage CHAR (20), JobCodeCategory CHAR (20))";
            
            
            
            //String createTableQuery = "Select Top 0 * into TrainRosterExtract_"+fileDate +" from TrainRosterExtract_07-20-2022";
           PreparedStatement statement = null; 
           String newFileDate = fileDate.replaceAll("-", "");
           
           if (connection != null) {
               Statement st3 = null;
               try {
                   st3 = (Statement) connection.createStatement();
               } catch (SQLException ex) {
                   Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
               }
               
               if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("TrainRosterExtract"))
		         {
               createTableQuery =  "CREATE TABLE TrainRosterExtract_"+newFileDate + " ( ID SERIAL PRIMARY KEY," + "QBSource VARCHAR(255), " + " Solution VARCHAR(255), " +  " Train VARCHAR(255), "  +  " Team VARCHAR(255), " + " ColleagueID VARCHAR(255)," + " AllocationPercentage  VARCHAR(255)," +" JobCodeCategory   VARCHAR(255), );";
		         }
               else
               if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
		         {
             createTableQuery =  "CREATE TABLE digitalrosterextract_"+newFileDate + " ( ID SERIAL PRIMARY KEY," + "Type VARCHAR(255), " + " ColleagueID VARCHAR(255), " +  " ColleagueName VARCHAR(255), "  +  " EmailAddress VARCHAR(255), " + " HireDate VARCHAR(255)," + " JobCode  VARCHAR(255)," +" JobTitle   VARCHAR(255)," +" JobGrade   VARCHAR(255),"+ " EmployeeGradeRollup   VARCHAR(255),"+ " DeptIDCC   VARCHAR(255),"+ " Location   VARCHAR(255)," +" Manager   VARCHAR(255)," +" Supervisor2   VARCHAR(255)," +" Supervisor3   VARCHAR(255)," +" Supervisor4   VARCHAR(255)," +" Supervisor5   VARCHAR(255)," +" Supervisor6   VARCHAR(255)," +" SeniorLeader   VARCHAR(255)," +" SVP   VARCHAR(255),"+" CapexOpex   VARCHAR(255),"+" RoleFunction   VARCHAR(255),"+" OnshoreOffshoreSGIC   VARCHAR(255),"+" Company   VARCHAR(255),"+" ManagerEmailAddress   VARCHAR(255),"+" ROLEGROUP   VARCHAR(255),"+" QBSource   VARCHAR(255) );";
		         }
            System.out.println(createTableQuery);
               //   ResultSet rs3 = null;
               try { 
                    st3.execute(createTableQuery);
               } catch (SQLException ex) {
                   Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
           
           
            //resultSet = statement1.execute(createTableQuery);
            //connection.commit();
            
            
            
            if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("TrainRosterExtract"))
	         {
            	insertQuery = "INSERT INTO TrainRosterExtract_"+fileDate.replaceAll("-", "")+" (QBSource,Solution,Train,Team,ColleagueID,AllocationPercentage,JobCodeCategory) VALUES  (?, ?, ?,?, ?, ?,?)";
	         }
          else
          if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
	         {
        	   insertQuery = "INSERT INTO digitalrosterextract_"+fileDate.replaceAll("-", "")+" (Type, ColleagueID,ColleagueName,EmailAddress,HireDate,JobCode,JobTitle,JobGrade,EmployeeGradeRollup,DeptIDCC,Location,Manager,Supervisor2,Supervisor3,Supervisor4,Supervisor5,Supervisor6,SeniorLeader,SVP,CapexOpex,RoleFunction,OnshoreOffshoreSGIC,Company,ManagerEmailAddress,ROLEGROUP,QBSource) VALUES (?, ?, ?,?, ?, ?,?, ?, ?,?, ?, ?,?, ?, ?,?, ?, ?,?, ?, ?,?, ?, ?,?, ?)";
	         }
            
            
         //Digital roster extract
            
            
            //train roster extract
            
            
            statement = connection.prepareStatement(insertQuery);  
            if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("TrainRosterExtract"))
  	         {
            count = 0;
          
            rowIterator.next(); // skip the header row
            while (rowIterator.hasNext()) {
                Row nextRow = rowIterator.next();
                Iterator<Cell> cellIterator = nextRow.cellIterator();
 
                
             
                while (cellIterator.hasNext()) {
                    Cell nextCell = cellIterator.next();
 
                    int columnIndex = nextCell.getColumnIndex();
 
                    switch (columnIndex) {
                    
                    case 0:
                    	String QBSource = nextCell.getStringCellValue();
                        statement.setString(1, QBSource);
                        break;
                    case 1:
                        String solution = nextCell.getStringCellValue();
                        statement.setString(2, solution);
                        break;
                    case 2:
                        String train = nextCell.getStringCellValue();
                        statement.setString(3, train);
                        break;
                    case 3:
                        String team = nextCell.getStringCellValue();
                        statement.setString(4, team);
                        break;
                    case 4:
                    	String ColleagueID =   nextCell.getStringCellValue();
                        statement.setString(5, ColleagueID);
                        break;
                    case 10:
                        String allocationPercentage = nextCell.getStringCellValue();
                        statement.setString(6, allocationPercentage);
                        break;
                    case 22:
                        String jobCodeCategory = nextCell.getStringCellValue();
                        statement.setString(7, jobCodeCategory);
                        break;
                   
                                       
                    }
 
                }
                
                statement.addBatch();
                
                if (count % batchSize == 0) {
                    statement.executeBatch();
                } 
            }
  	         }
                else
                	   if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
          	         {
                		   count = 0;
                           
                		   
                		   
                           rowIterator.next(); // skip the header row
                           while (rowIterator.hasNext()) {
                               Row nextRow = rowIterator.next();
                               Iterator<Cell> cellIterator = nextRow.cellIterator();
                               //for(int x=0;x<nextRow.getLastCellNum();x++) {
                               //System.out.println(nextRow.getPhysicalNumberOfCells());
                               while (cellIterator.hasNext()) {
                                   Cell nextCell = cellIterator.next();
                                   
                                   int columnIndex = nextCell.getColumnIndex();
                
                                   switch (columnIndex) {
                                   
                                   case 0:
                                       String empType = nextCell.getStringCellValue();
                                       statement.setString(1, empType);
                                       break;
                                   case 1:
                                       String ColleagueID = nextCell.getStringCellValue();
                                       statement.setString(2, ColleagueID);
                                       break;
                                   case 2:
                                       String ColleagueName = nextCell.getStringCellValue();
                                       statement.setString(3, ColleagueName);
                                       break;
                                   case 3:
                                   	nextCell.setCellType(CellType.STRING);
                                       String EmailAddress = nextCell.getStringCellValue();
                                       statement.setString(4, EmailAddress);
                                       break;
                                   case 4:
                                   	System.out.println(nextCell.getCellType());
                                   	System.out.println(nextCell.getStringCellValue());
                                   	//String HireDate =formatter.formatCellValue(nextCell);
                                   	String HireDate =   nextCell.getStringCellValue();
                                       statement.setString(5, HireDate);
                                       break;
                                   case 5:
                                       String JobCode = nextCell.getStringCellValue();
                                       statement.setString(6, JobCode);
                                       break;
                                   case 6:
                                   	nextCell.setCellType(CellType.STRING);
                                       String JobTitle = nextCell.getStringCellValue();
                                       statement.setString(7, JobTitle);
                                       break;
                                   case 7:
                                       String JobGrade = nextCell.getStringCellValue();
                                       statement.setString(8, JobGrade);
                                       break;
                                   case 8:
                                       String EmployeeGradeRollup = nextCell.getStringCellValue();
                                       statement.setString(9, EmployeeGradeRollup);
                                       break;
                                   case 9:
                                   	nextCell.setCellType(CellType.STRING);
                                       String DeptIDCC = nextCell.getStringCellValue();
                                       statement.setString(10, DeptIDCC);
                                       break;
                                   case 10:
                                	   nextCell.setCellType(CellType.STRING);
                                       String Location = nextCell.getStringCellValue();
                                       statement.setString(11, Location);
                                       break;
                                   case 11:
                                	   nextCell.setCellType(CellType.STRING);
                                       String Manager = nextCell.getStringCellValue();
                                       statement.setString(12, Manager);
                                       break;
                                   case 12:
                                   	nextCell.setCellType(CellType.STRING);
                                       String Supervisor2 = nextCell.getStringCellValue();
                                       statement.setString(13, Supervisor2);
                                       break;
                                   case 13:
                                	   nextCell.setCellType(CellType.STRING);
                                       String Supervisor3 = nextCell.getStringCellValue();
                                       statement.setString(14, Supervisor3);
                                       break;
                                   case 14:
                                	   nextCell.setCellType(CellType.STRING);
                                       String Supervisor4 = nextCell.getStringCellValue();
                                       statement.setString(15, Supervisor4);
                                       break;
                                   case 15:
                                   	nextCell.setCellType(CellType.STRING);
                                       String Supervisor5 = nextCell.getStringCellValue();
                                       statement.setString(16, Supervisor5);
                                       break;
                                   case 16:
                                	   nextCell.setCellType(CellType.STRING);
                                       String Supervisor6 = nextCell.getStringCellValue();
                                       statement.setString(17, Supervisor6);
                                       break;
                                   case 17:
                                	   nextCell.setCellType(CellType.STRING);
                                       String SeniorLeader = nextCell.getStringCellValue();
                                       statement.setString(18, SeniorLeader);
                                       break;
                                   case 18:
                                   	nextCell.setCellType(CellType.STRING);
                                       String SVP = nextCell.getStringCellValue();
                                       statement.setString(19, SVP);
                                       break;
                                   case 19:
                                	   nextCell.setCellType(CellType.STRING);
                                       String CapexOpex = nextCell.getStringCellValue();
                                       statement.setString(20, CapexOpex);
                                       break;
                                   case 20:
                                	   nextCell.setCellType(CellType.STRING);
                                       String RoleFunction = nextCell.getStringCellValue();
                                       statement.setString(21, RoleFunction);
                                       break;
                                   case 21:
                                   	nextCell.setCellType(CellType.STRING);
                                       String OnshoreOffshoreSGIC = nextCell.getStringCellValue();
                                       statement.setString(22, OnshoreOffshoreSGIC);
                                       break;
                                   case 22:
                                	   nextCell.setCellType(CellType.STRING);
                                       String Company = nextCell.getStringCellValue();
                                       statement.setString(23, Company);
                                       break;
                                   case 23:
                                	   System.out.println(nextCell.getCellType());
                                	   if(nextCell.getCellType() == CellType.BLANK)
                                	   {
                                		   nextCell.setCellType(CellType.STRING);
                                		   statement.setString(24, "");
                                	   }
                                	   else
                                	   {
                                	   nextCell.setCellType(CellType.STRING);
                                       String ManagerEmailAddress = nextCell.getStringCellValue();
                                       statement.setString(24, ManagerEmailAddress);
                                	   }
                                       break;
                                   case 24:
                                   	nextCell.setCellType(CellType.STRING);
                                       String ROLEGROUP = nextCell.getStringCellValue();
                                       statement.setString(25, ROLEGROUP);
                                       break;
                                   case 25:
                                	   nextCell.setCellType(CellType.STRING);
                                       String QBSource = nextCell.getStringCellValue();
                                       statement.setString(26, QBSource);
                                       break;
                                                      
                                   }
                
                               }  
                               statement.addBatch();
                               
                               if (count % batchSize == 0) {
                                   statement.executeBatch();
                               } 
          	         }
          	         }     
                            
 
            
 
            workbook.close();
             
            // execute the remaining queries
            //statement.executeUpdate();
  
            //connection.commit();
            //connection.close();
             
            long end = System.currentTimeMillis();
            System.out.printf("Import done in %d ms\n", (end - start));
             
        } catch (IOException ex1) {
            System.out.println("Error reading file");
            ex1.printStackTrace();
        } catch (SQLException ex2) {
            System.out.println("Database error");
            ex2.printStackTrace();
        }
 
    }
    
}