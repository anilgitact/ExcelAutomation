package test.java.excel.tests;


import java.util.Date;

public class Employee {
    private String name;
    private String email;
    private Date dateOfBirth;
    private double salary;
    private double bonus;

    public Employee( String name, String email,Date dateOfBirth  , Double salary,  Double bonus) {
        this.name = name;
        this.email = email;
        this.dateOfBirth = dateOfBirth;
        this.salary = salary ;
        this.bonus = bonus ;
    }

  

	public String getname () {
        return name;
    }
    public String getemail ( ) {
        return email;
    }
    public Date getdateOfBirth ( ) {
        return dateOfBirth;
    }
    public double getsalary ( ) {
        return salary;
    }
    
    public double getBonus ( ) {
        return bonus;
    }

    public void setName ( String name ) {
        // … add your data validation checks here. Example: Strings that are too short or too long.
        this.name = name;
    }

     public void setSalary ( double salary ) {
        this.salary = salary;
    }
     
     public void setBonus( double bonus ) {
         this.bonus = bonus;
     }
}