package test.java.excel.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CaptureSpecificColumnDataFromASheet {
public static void main(String[] args) throws IOException {

    ArrayList<String> columndata = null;
    try {
        File f = new File("./resources/test_data.xlsx");
        FileInputStream ios = new FileInputStream(f);
        XSSFWorkbook workbook = new XSSFWorkbook(ios);
        XSSFSheet sheet = workbook.getSheetAt(0);
        Iterator<Row> rowIterator = sheet.iterator();
        columndata = new ArrayList<>();
         int columnIndex =0;
        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            Iterator<Cell> cellIterator = row.cellIterator();
            while (cellIterator.hasNext()) {
                Cell cell = cellIterator.next();

                if(row.getRowNum() > 0){ //To filter column headings
                    if(cell.getColumnIndex() == columnIndex){// To match column index
                        switch (cell.getCellType()) {
                        case NUMERIC:
                            columndata.add(cell.getNumericCellValue()+"");
                            break;
                            
                        case STRING: 
                            columndata.add(cell.getStringCellValue());
                            break;
                            
                        case FORMULA:
                        	columndata.add(cell.getNumericCellValue()+"");
                             break;
                        }
                    }
                }
            }
        }
        ios.close();
        
            int index = workbook.getSheetIndex("SortedData");
            if(index!=-1)
            {
            workbook.removeSheetAt(index);
            }
        XSSFSheet s = workbook.createSheet("SortedData");
        
        //sort the data in arraylist
        Collections.sort(columndata);  
        
        
   
        for (String element : columndata) {
            System.out.println(element);
            
             
            for (int i=0; i<columndata.size(); i++) {
               Row r = s.createRow(i);
               r.createCell(0).setCellValue(columndata.get(i) );
               
            }
            // Write the output to a file
            FileOutputStream fileOut = new FileOutputStream("./resource/test_data.xlsx");
            workbook.write(fileOut);
            
            
            fileOut.close();
            
        }
        System.out.println("Processing is complete");
    } catch (Exception e) {
        e.printStackTrace();
    }
    //return columndata;
}
}