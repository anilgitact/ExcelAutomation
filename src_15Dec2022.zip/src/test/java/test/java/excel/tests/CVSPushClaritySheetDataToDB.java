package test.java.excel.tests;


/**
 *  code that imports data from an Excel file to MySQL database.
 *
 * @author Anil
 *
 */

import java.io.*;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.poi.ss.usermodel.CellType;

import main.java.commonUtilityFunctions;

public class CVSPushClaritySheetDataToDB {
 
	
	
	static String createClarityTableQuery="";
	static String insertQuery ="";
	static int count = 0;
	
    public static void main(String[] args) {
    	
    }
    @SuppressWarnings("null")
	public static void pushClarityataToDB(String excelFilePath) throws IOException, ParseException
	{
		
    	 Statement st3 = null;
        String csvFilePath = excelFilePath;
 
       
    	// variables
    	Connection connection = null;
    	 int batchSize = 20;
    			// Statement statement = null;
    			ResultSet resultSet = null;
    			  String user = "postgres";
    			    String password = "postgres";
 
 
        try {
 
        	connection = commonUtilityFunctions.connectToPostgresDB(user,password);
            
            connection.setAutoCommit(false);
 
            try {
                st3 = (Statement) connection.createStatement();
            } catch (SQLException ex) {
                Logger.getLogger(CVSRosterExcel2DatabaseTest.class.getName()).log(Level.SEVERE, null, ex);
            }
          
           
            
            st3.execute("truncate public.ClarityExtract");
            if (CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("RosterExtractName").contains("DigitalRosterExtract"))
	         {
       	   insertQuery = "INSERT INTO ClarityExtract (PSEMPLOYEEID,EMPLOYEEFULLNAME, EMPMANAGERFULLNAME, EMPRESOURCEOBSL1, EMPTIMESHEETMONTH ,EMPTIMESHEETSTOPWEEK , EMPACTUAL , EMPRATE , COSTPOOLNAME, SEGMENT ,FUNDINGSOURCE) VALUES (?, ?, ?,?, ?, ?,?, ?, ?,?, ?)";
	         }
           

            PreparedStatement statement = connection.prepareStatement(insertQuery);
 
            BufferedReader lineReader = new BufferedReader(new FileReader(csvFilePath));
            String lineText = null;
 
            int count = 0;
 
            
            
            lineReader.readLine(); // skip header line
 
            while ((lineText = lineReader.readLine()) != null) {
                String[] data = lineText.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)", -1);
                
                System.out.println(count);
               
                count++;
                
              
           
               /*if(data[4]==null || data[8]==null || data[14]==null||data[23]==null||data[25]==null||data[26]==null||data[31]==null||data[63]==null||data[84]==null||data[85]==null||data[86]==null)
               {
            	   
            	   data[4]="" ; data[8]="" ; data[14]=""; data[23]=""; data[25]=""; data[26]="";
            	   data[31]=""; data[63]=""; data[84]=""; data[85]=""; data[86]="";
               }*/
               
              
            	   
               //System.out.println(data[4] +"|"+ data[8] +"|"+data[14]+"|"+data[23]+"|"+data[25]+"|"+data[26]+"|"+data[31]+"|"+data[63]+"|"+data[84]+"|"+data[85]+"|"+data[86]);;
               
               /*System.out.println(data[4]);
               System.out.println(data[8]);
               System.out.println(data[25]);
               System.out.println(data[26]);
               System.out.println(data[31]);
               System.out.println(data[63]);
               System.out.println(data[84]);
               System.out.println(data[85]);*/
               //System.out.println(data[86]);
               
               
               
                for(int j=0;j<data.length;j++)
                {
                
                
                switch (j) {
                
                case 3:
                	 if (data[3] == null || data[3].isEmpty() || data[3] == "") {
                		 statement.setString(2, "");
                     }
                     
                     else
                     {
                    String EMPLOYEEFULLNAME = data[3];
                    statement.setString(2, EMPLOYEEFULLNAME);
                     }
                    break;
                case 7:
                	 if (data[7] == null || data[7].isEmpty() || data[7] == "") {
                		 statement.setString(4, "");
                     }
                     
                     else
                     {
                    String EMPRESOURCEOBSL1 = data[7];
                    statement.setString(4, EMPRESOURCEOBSL1);
                     }
                    break;
                case 13:
                	if (data[13] == null || data[13].isEmpty() || data[13] == "") {
               		 statement.setString(3, "");
                    }
                    
                    else
                    {
                    String EMPMANAGERFULLNAME = data[13];
                    statement.setString(3, EMPMANAGERFULLNAME);
                    }
                    break;
                case 21:
                	if (data[21] == null || data[21].isEmpty() || data[21] == "") {
               		 statement.setString(5, "");
                    }
                    
                    else
                    {
                    String EMPTIMESHEETMONTH = data[21];
                    statement.setString(5, EMPTIMESHEETMONTH);
                    }
                    break;
                case 23:
                	if (data[23] == null || data[23].isEmpty() || data[23] == "") {
               		 statement.setString(6, "");
                    }
                    
                    else
                    {
                      	
                      	String EMPTIMESHEETSTOPWEEKSTRING =   data[23];
                      	SimpleDateFormat df1 = new SimpleDateFormat("MM/dd/yy");
                       	Date EMPTIMESHEETSTOPWEEK = df1.parse(EMPTIMESHEETSTOPWEEKSTRING); 
                       	
                       	SimpleDateFormat df2 = new SimpleDateFormat("MM/dd/yyyy");
                       	String finalvalue = df2.format(EMPTIMESHEETSTOPWEEK);
                       	
                        statement.setString(6, finalvalue.toString());
                        break;
                    	
                	
                    }
                    break;
                case 24:
                	if (data[24] == null || data[24].isEmpty() || data[24] == "") {
               		 statement.setString(7, "");
                    }
                    
                    else
                    {
                    String EMPACTUAL = data[24];
                    statement.setString(7, EMPACTUAL);
                    }
                    break;
                case 28:
                	if (data[28] == null || data[28].isEmpty() || data[28] == "") {
               		 statement.setString(8, "");
                    }
                    
                    else
                    {
                    String EMPRATE = data[28];
                    statement.setString(8, EMPRATE);
                    }
                    break;
                case 52:
                	if (data[52] == null || data[52].isEmpty() || data[52] == "") {
               		 statement.setString(1, "");
                    }
                    
                    else
                    {
                    String PSEMPLOYEEID = data[52];
                    statement.setString(1, PSEMPLOYEEID);
                    }
                    break;
                case 68:
                	if (data[68] == null || data[58].isEmpty() || data[68] == "") {
               		 statement.setString(9, "");
                    }
                    
                    else
                    {
                    String COSTPOOLNAME = data[68];
                    statement.setString(9, COSTPOOLNAME);
                    }
                    break;
                case 69:
                	if (data[69] == null || data[69].isEmpty() || data[69] == "") {
               		 statement.setString(10, "");
                    }
                    
                    else
                    {
                    String SEGMENT = data[69];
                    statement.setString(10, SEGMENT);
                    }
                    break;
                case 70:
                	
                	if (data[70] == null || data[70].isEmpty() || data[70] == "") {
               		 statement.setString(11, "");
                    }
                    
                    else
                    {
                	String FUNDINGSOURCE="";
                	if(data.length==86) 
                    {
                		 FUNDINGSOURCE="";
                    }
                	else
                	{
                     FUNDINGSOURCE = data[70];
                	}
                    statement.setString(11, FUNDINGSOURCE);
                    }
                    break;
                                                      
                }
                
                }
                statement.addBatch();
 
                if (count % batchSize == 0) {
                    statement.executeBatch();
                }
            }
 
            System.out.println("data from csv/excel ingested into database");
            lineReader.close();
 
            // execute the remaining queries
            statement.executeBatch();
            System.out.println("total no of records inserted into DB from file :"+csvFilePath +"is: "+ count);
            connection.commit();
          
 
        } catch (IOException ex) {
            System.err.println(ex);
        } catch (SQLException ex) {
            ex.printStackTrace();
 
            try {
                connection.rollback();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
 
 
}
 }

