package test.java.excel.tests;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class datedate {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub
		
		
		String receivedROVFileNameDate ="07272022";
		 SimpleDateFormat inputFormat = new SimpleDateFormat("MMddyyyy");
		    SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MMM-YYYY");
		    Date theDate = inputFormat.parse(receivedROVFileNameDate);
		    System.out.println(outputFormat.format(theDate).substring(0,6));

	}

}
