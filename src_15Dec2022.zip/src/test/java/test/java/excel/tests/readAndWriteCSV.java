package test.java.excel.tests;

import com.opencsv.*;
import java.io.*;

public class readAndWriteCSV {
	String filePath;
	static CSVWriter file;

	readAndWriteCSV(String filePath) {
		this.filePath = filePath;
	}

	public static void main(String[] args) throws IOException {
		
		String filePath =".\\resources\\test_dataCSVNew.csv";
		writingCSVFile(filePath);
		readingCSVFile(filePath);
		
	}
	
	
	
// writing csv file function
	public static void writingCSVFile(String filePath) {
		try {
			file = new CSVWriter(new FileWriter(new File(filePath)));
			String[] colName = { "Student ID", "Student Name", "Student Email" };
			file.writeNext(colName);
			String[] data = { "001", "Anil", "abc@emids.com" };
			String[] data1 = { "002", "Koushalya", "Koushalya@emids.com" };
			String[] data2 = { "003", "Vishal", "Vishal@emids.com" };
			file.writeNext(data);
			file.writeNext(data1);
			file.writeNext(data2);
			file.close();
			System.out.println("Writing to the CSV File is complete");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

// reading csv file
	public static void readingCSVFile(String filePath) {
		try {
			BufferedReader readFile = new BufferedReader(new FileReader(filePath));
			String readFilerow;
			while ((readFilerow = readFile.readLine()) != null) {
				String[] data = readFilerow.split(",");
				System.out.println(data[0] + "|" + data[1] + "|" + data[2]);
			}
			readFile.close();
			System.out.println("Reading from the CSV File is complete");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
