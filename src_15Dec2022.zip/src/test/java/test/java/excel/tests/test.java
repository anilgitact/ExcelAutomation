package test.java.excel.tests;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;

import main.java.commonUtilityFunctions;

public class test {

	public static void main(String[] args) throws IOException, SQLException {
		// TODO Auto-generated method stub

		
		  String user = "postgres";
		    String password = "postgres";
	    
Connection conn = null;
try {
	conn = commonUtilityFunctions.connectToPostgresDB(user,password);
} catch (Exception e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}


   //display table names

ResultSet rs =conn.createStatement().executeQuery("SELECT table_name FROM information_schema.tables WHERE table_schema='public' AND table_type='BASE TABLE'");
while(rs.next()) {
	System.out.println(rs.getString(1));
}
	  //generate the final report
		 String datetime ="";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
		Calendar calendar = Calendar.getInstance();
		try {
		     //calendar.setTime(simpleDateFormat.parse("11/20/2014 8:10:00 AM"));

		     String str3 = String.valueOf(calendar.get(Calendar.DAY_OF_MONTH));
		     datetime = String.valueOf(calendar.get(Calendar.DAY_OF_MONTH))+String.valueOf(calendar.get(Calendar.MONTH))+String.valueOf(calendar.get(Calendar.YEAR))+String.valueOf(calendar.get(Calendar.HOUR))+String.valueOf(calendar.get(Calendar.MINUTE));

		} catch (Exception e) {
		   e.printStackTrace();
		}
		String DigitalRosterExtractMonthwiseFinalReportQuery = CVSPushRosterToDBAndFindDiffAndAttrition.getPropertyValueFromPropertyFile("DigitalRosterExtractMonthwiseFinalReportQuery");
		CVSPushRosterToDBAndFindDiffAndAttrition.PushRecordSetToExcel(DigitalRosterExtractMonthwiseFinalReportQuery,"FinalReport",conn,datetime);
	}

}
