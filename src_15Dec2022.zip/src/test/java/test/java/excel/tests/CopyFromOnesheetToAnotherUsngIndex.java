package test.java.excel.tests;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CopyFromOnesheetToAnotherUsngIndex {
	public static void main(String[] args) throws IOException {
		FileInputStream file = new FileInputStream(new File("./resources/test_data.xlsx"));
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet_copy = workbook.cloneSheet(0);
		int num = workbook.getSheetIndex(sheet_copy);
		workbook.setSheetName(num, "copied_sheet");
		file.close();

		FileOutputStream outputStream = new FileOutputStream("./resources/test_data.xlsx");
		workbook.write(outputStream);
		System.out.println("Processing is complete");
		workbook.close();
		outputStream.close();
	}
}