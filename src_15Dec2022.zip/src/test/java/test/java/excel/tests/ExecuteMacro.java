package test.java.excel.tests;

import java.io.IOException;

public class ExecuteMacro {

	public static void main(String[] args) {
		
		try {
			Runtime.getRuntime().exec("wscript .\\resources\\sheet2pdf.vbs");
			} catch (IOException e) {
			System.out.println(e);
			System.exit(0);
}

}
}