package test.java.excel.tests;

public class ReadUsingLightCellsApi
{
    public static void Run()
    {
        // The path to the documents directory.
        String dataDir = RunExamples.GetDataDir(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        LoadOptions opts = new LoadOptions();
        LightCellsDataHandlerVisitCells v = new LightCellsDataHandlerVisitCells();
        opts.LightCellsDataHandler = v;
        Workbook wb = new Workbook(dataDir + "LargeBook1.xlsx", opts);
        int sheetCount = wb.Worksheets.Count;
        Console.WriteLine("Total sheets: " + sheetCount + ", cells: " + v.CellCount
            + ", strings: " + v.StringCount + ", formulas: " + v.FormulaCount);
    }
}