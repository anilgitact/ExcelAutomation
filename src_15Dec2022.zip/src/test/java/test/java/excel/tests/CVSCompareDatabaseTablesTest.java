package test.java.excel.tests;

import java.io.*;
import java.sql.*;
import java.util.*;
import java.util.Date;
import java.util.stream.Collectors;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

//import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;

import main.java.commonUtilityFunctions;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;


/**
 * Sample Java program that imports data from an Excel file to MySQL database.
 *
 * @author anil- 
 *
 */
public class CVSCompareDatabaseTablesTest {
 
    public static void main(String[] args) throws IOException {
    	
    	
    }
    	public static void CompareTablesAndFindDiff(String sqlQuery, String diffTableName, String existingDBTable, String newTableName, String rosterExtractName) throws IOException
    	{
    	//String excelFilePath = ".\\resources\\"+fileName+".xlsx";
    	int batchSize = 20;
		/*
		 * // variables Connection connection = null; //Statement statement = null;
		 * ResultSet resultSet = null;
		 * 
		 * // Step 1: Loading or registering Oracle JDBC driver class try {
		 * 
		 * Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); }
		 * catch(ClassNotFoundException cnfex) {
		 * 
		 * System.out.println("Problem in loading or " +
		 * "registering MS Access JDBC driver"); cnfex.printStackTrace(); }
		 * 
		 * // Step 2: Opening database connection try {
		 * 
		 * String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
		 * String dbURL = "jdbc:ucanaccess://" + msAccDB;
		 * 
		 * // Step 2.A: Create and get connection using DriverManager class connection =
		 * DriverManager.getConnection(dbURL);
		 */
            
    	// variables
    	       Connection connection = null;
    			// Statement statement = null;
    			ResultSet resultSet = null;
    			  String user = "postgres";
    			    String password = "postgres";
    			/*
    			 * // Step 1: Loading or registering Oracle JDBC driver class try {
    			 * 
    			 * Class.forName("net.ucanaccess.jdbc.UcanaccessDriver"); } catch
    			 * (ClassNotFoundException cnfex) {
    			 * 
    			 * System.out.println("Problem in loading or " +
    			 * "registering MS Access JDBC driver"); cnfex.printStackTrace(); }
    			 */
    			// Step 2: Opening database connection
    			try {

    				/*
    				 * String msAccDB = "D:\\Users\\XP.Anil.Sharma\\Documents\\Database1.accdb";
    				 * String dbURL = "jdbc:ucanaccess://" + msAccDB;
    				 * 
    				 * // Step 2.A: Create and get connection using DriverManager class connection =
    				 * DriverManager.getConnection(dbURL);
    				 */

    				 connection = commonUtilityFunctions.connectToPostgresDB(user,password);

    	
    	    long start = System.currentTimeMillis();
            //connection = DriverManager.getConnection(dbURL);
            connection.setAutoCommit(false);
  

            
            //String sql = "SELECT DigitalRosterExtract.id FROM DigitalRosterExtract  LEFT OUTER JOIN DigitalRosterExtractCopy ON DigitalRosterExtract.id = DigitalRosterExtractCopy.id WHERE DigitalRosterExtractCopy.id IS NULL";
            //to find any new or missing record
            //String sql = "SELECT DigitalRosterExtract.id FROM DigitalRosterExtract  LEFT OUTER JOIN DigitalRosterExtractCopy ON DigitalRosterExtract.id = DigitalRosterExtractCopy.id WHERE DigitalRosterExtractCopy.id IS NULL UNION SELECT DigitalRosterExtractCopy.id FROM DigitalRosterExtractCopy  LEFT OUTER JOIN DigitalRosterExtract ON DigitalRosterExtractCopy.id = DigitalRosterExtract.id WHERE DigitalRosterExtract.id IS NULL";
            
            //HireDate,JobCode,JobTitle,JobGrade,EmployeeGradeRollup,DeptIDCC,Location,Manager,Supervisor2,Supervisor3,Supervisor4,Supervisor5,Supervisor6,SeniorLeader,SVP,CapexOpex,RoleFunction,OnshoreOffshoreSGIC,Company,ManagerEmailAddress,ROLEGROUP,QBSource
            //to find if any column data is not matching 
            String sql = sqlQuery;
            		       
            sql = sql.replaceAll("existingTable",rosterExtractName+"_"+existingDBTable);		       
            sql = sql.replaceAll("newlyCreatedTable",rosterExtractName+"_"+newTableName);
            Statement statement = connection.createStatement();  
             
            resultSet = statement.executeQuery(sql);
            ResultSetMetaData rsmd = resultSet.getMetaData();
            int columnsNumber = rsmd.getColumnCount();
            copyResultsetToTable(sql, diffTableName, connection, connection);
            while (resultSet.next()) {
                for (int i = 1; i <= columnsNumber; i++) {
                    if (i > 1) System.out.print(",  ");
                    String columnValue = resultSet.getString(i);
                    System.out.print(columnValue + "<< " + rsmd.getColumnName(i));
                    
                }
                System.out.println("\n");
            }
            connection.commit();
            //connection.close();
             
            long end = System.currentTimeMillis();
            System.out.printf("Import done in %d ms\n", (end - start));
             
       
        } catch (SQLException ex2) {
            System.out.println("Database error");
            ex2.printStackTrace();
        }
 
    }


    	
    	
    	public static void copyResultsetToTable(String sqlQuery, String table, Connection from, Connection to) throws SQLException, IOException {
    		
    		try {
    			from.setAutoCommit(false);
    		Statement st = from.createStatement();
    		
    		String actualQuery = "insert into public."+table + " " + sqlQuery;
    				
    	    st.execute(actualQuery);
    	    from.commit();
    	    //from.close();
    		 
    		 } catch (SQLException ex2) {
    	            System.out.println("Database error - method copyResultsetToTable not able to insert data in table: "+ table);
    	            ex2.printStackTrace();
    	        }
    	}

	/*
	public static void copyResultsetToTable(String sqlQuery, String table, Connection from, Connection to) throws SQLException, IOException {
	    try  (PreparedStatement s1 = from.prepareStatement(sqlQuery);
	    		 ResultSet rs = s1.executeQuery()) {
	        ResultSetMetaData meta = rs.getMetaData();

	        int count=0;
	        while(rs.next())
	        {
	        	count++;
	        	
	        }
	        System.out.println(count);
	        List<String> columns = new ArrayList<>();
	        for (int i = 1; i <= meta.getColumnCount(); i++)
	            columns.add(meta.getColumnName(i));

	        try (PreparedStatement s2 = to.prepareStatement(
	                "INSERT INTO " + table + " ("
	              + columns.stream().collect(Collectors.joining(", "))
	              + ") VALUES ("
	              + columns.stream().map(c -> "?").collect(Collectors.joining(", "))
	              + ")"
	        )) {

	            while (rs.next()) {
	                for (int i = 1; i <= meta.getColumnCount(); i++)
	                    s2.setObject(i, rs.getObject(i));

	                s2.addBatch();
	            }

	            s2.executeBatch();
	        } finally {
	            
	        }
	    } finally {
	        
	    }
	} */
}

	    
           
        
 
	
	
    
